-- =====================================================================
-- V9 — Module bureau d'études électriques, étapes E14 à E17 :
--   E14 référentiel des domaines de tension et installations,
--   E15 bibliothèque technique des câbles,
--   E16/E17 pièces (dimensions) ; surface, périmètre et volume calculés par la base.
-- Migration NON destructive. Les valeurs de référence sont des valeurs PAR DÉFAUT,
-- configurables par organisation ; elles doivent être confirmées pour chaque projet.
-- =====================================================================

-- ---------------------------------------------------------------- E14 Domaines de tension
create table public.elec_voltage_domains (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade, -- null = référentiel par défaut
  code text not null check (length(trim(code)) > 0),
  label text not null,
  description text,
  min_ac_v numeric(12,2) check (min_ac_v is null or min_ac_v >= 0),
  max_ac_v numeric(12,2),
  min_dc_v numeric(12,2) check (min_dc_v is null or min_dc_v >= 0),
  max_dc_v numeric(12,2),
  reference_standard text,
  is_confirmed boolean not null default false,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (max_ac_v is null or min_ac_v is null or max_ac_v > min_ac_v),
  check (max_dc_v is null or min_dc_v is null or max_dc_v > min_dc_v)
);
create unique index uq_elec_voltage_domains
  on public.elec_voltage_domains (coalesce(organization_id, '00000000-0000-0000-0000-000000000000'::uuid), upper(code));
create trigger elec_voltage_domains_touch before update on public.elec_voltage_domains
  for each row execute function public.touch_updated_at();

insert into public.elec_voltage_domains
  (code,label,description,min_ac_v,max_ac_v,min_dc_v,max_dc_v,reference_standard,is_confirmed,sort_order)
values
 ('TBT','Très Basse Tension','Valeurs usuelles du référentiel français ; à confirmer pour le projet.',0,50,0,120,'À confirmer (réglementation nationale)',false,10),
 ('BT','Basse Tension','Valeurs usuelles du référentiel français ; à confirmer pour le projet.',50,1000,120,1500,'À confirmer (réglementation nationale)',false,20),
 ('MTA','Moyenne Tension A','Limites à définir selon le référentiel du projet, le distributeur et le contrat.',null,null,null,null,'À définir',false,30),
 ('MTB','Moyenne Tension B','Limites à définir selon le référentiel du projet, le distributeur et le contrat.',null,null,null,null,'À définir',false,40),
 ('HTA','Haute Tension A','À utiliser uniquement si le référentiel applicable emploie cette appellation.',1000,50000,1500,75000,'À confirmer (réglementation nationale)',false,50),
 ('HTB','Haute Tension B','À utiliser uniquement si le référentiel applicable emploie cette appellation.',50000,null,75000,null,'À confirmer (réglementation nationale)',false,60);

-- ---------------------------------------------------------------- E14 Installations
create table public.elec_installations (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  voltage_domain_id uuid not null references public.elec_voltage_domains(id),
  name text not null check (length(trim(name)) > 0),
  installation_type text not null default 'installation' check (installation_type in
    ('installation','transformer','substation','protection_cell','distribution_network','link','protection_device')),
  current_type text not null default 'ac' check (current_type in ('ac','dc')),
  nominal_voltage_v numeric(12,2) check (nominal_voltage_v is null or nominal_voltage_v > 0),
  max_voltage_v numeric(12,2) check (max_voltage_v is null or max_voltage_v > 0),
  phase_to_phase_v numeric(12,2) check (phase_to_phase_v is null or phase_to_phase_v > 0),
  phase_to_neutral_v numeric(12,2) check (phase_to_neutral_v is null or phase_to_neutral_v > 0),
  frequency_hz numeric(6,2) check (frequency_hz is null or frequency_hz > 0),
  phases_count smallint check (phases_count is null or phases_count in (1,2,3)),
  neutral_regime text check (neutral_regime is null or neutral_regime in ('TT','TN-C','TN-S','TN-C-S','IT')),
  supply_type text,
  applicable_standard text,
  design_reference text,
  verification_reference text,
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_elec_installations_project on public.elec_installations(project_id);
create trigger elec_installations_touch before update on public.elec_installations
  for each row execute function public.touch_updated_at();

-- Le domaine doit appartenir au référentiel par défaut ou à l'organisation du projet.
create or replace function public.elec_installations_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_org uuid; v_dom_org uuid; v_found boolean;
begin
  select organization_id into v_org from public.projects where id = new.project_id;
  select organization_id, true into v_dom_org, v_found from public.elec_voltage_domains where id = new.voltage_domain_id;
  if not coalesce(v_found, false) then raise exception 'Domaine de tension introuvable'; end if;
  if v_dom_org is not null and v_dom_org <> v_org then
    raise exception 'Ce domaine de tension appartient à une autre organisation';
  end if;
  return new;
end $$;
create trigger elec_installations_guard_trigger before insert or update of voltage_domain_id, project_id on public.elec_installations
  for each row execute function public.elec_installations_guard();

-- ---------------------------------------------------------------- E15 Bibliothèque des câbles
create table public.elec_cable_types (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade, -- null = bibliothèque par défaut
  code text not null check (length(trim(code)) > 0),
  label text not null,
  category text not null check (category in
    ('power','control','shielded','armoured','fire_resistant','halogen_free','photovoltaic','communication','earth','industrial')),
  core_type text not null check (core_type in ('unipolar','multipolar')),
  rigidity text not null check (rigidity in ('rigid','flexible')),
  conductor_materials text[] not null check (conductor_materials <@ array['cu','al']::text[] and cardinality(conductor_materials) > 0),
  insulation text not null check (insulation in ('PVC','XLPE','EPR','LSZH','XLPO','other')),
  rated_u0_v numeric(10,1) check (rated_u0_v is null or rated_u0_v > 0),
  rated_u_v numeric(10,1) not null check (rated_u_v > 0),
  current_type text not null default 'ac' check (current_type in ('ac','dc','ac_dc')),
  allowed_laying text[] not null default '{}',
  allowed_environments text[] not null default '{}',
  available_sections_mm2 numeric(8,2)[] not null default '{}',
  available_cores smallint[] not null default '{}',
  fire_class text,                       -- classement CPR / Euroclasse, si exigé par le référentiel
  is_fire_resistant boolean not null default false,
  is_halogen_free boolean not null default false,
  is_shielded boolean not null default false,
  is_armoured boolean not null default false,
  standard_ref text,
  data_status text not null default 'to_confirm' check (data_status in ('to_confirm','confirmed')),
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index uq_elec_cable_types
  on public.elec_cable_types (coalesce(organization_id, '00000000-0000-0000-0000-000000000000'::uuid), upper(code));
create trigger elec_cable_types_touch before update on public.elec_cable_types
  for each row execute function public.touch_updated_at();

-- Valeurs typiques de catalogue, À CONFIRMER avec la fiche du fabricant (data_status = to_confirm).
insert into public.elec_cable_types
 (code,label,category,core_type,rigidity,conductor_materials,insulation,rated_u0_v,rated_u_v,current_type,
  allowed_laying,allowed_environments,available_sections_mm2,available_cores,is_fire_resistant,is_halogen_free,is_shielded,is_armoured,standard_ref,notes)
values
 ('H07V-U','Conducteur rigide monobrin PVC','power','unipolar','rigid',array['cu'],'PVC',450,750,'ac',
   array['conduit','sheath','flush','duct'],array['dry'],array[1.5,2.5,4,6,10]::numeric[],array[1]::smallint[],false,false,false,false,'NF C 32-201 / HD 21.3','Câblage sous conduit ; non destiné à la pose directe, enterrée ou extérieure.'),
 ('H07V-R','Conducteur rigide câblé PVC','power','unipolar','rigid',array['cu'],'PVC',450,750,'ac',
   array['conduit','sheath','flush','duct'],array['dry'],array[6,10,16,25,35,50,70,95,120,150,185,240]::numeric[],array[1]::smallint[],false,false,false,false,'NF C 32-201 / HD 21.3','Câblage sous conduit ; non destiné à la pose directe, enterrée ou extérieure.'),
 ('H07V-K','Conducteur souple PVC','power','unipolar','flexible',array['cu'],'PVC',450,750,'ac',
   array['conduit','sheath','flush','duct'],array['dry'],array[1.5,2.5,4,6,10,16,25,35,50,70,95,120,150,185,240]::numeric[],array[1]::smallint[],false,false,false,false,'NF C 32-201 / HD 21.3','Utilisable aussi comme conducteur de protection ou de terre (repérage vert/jaune).'),
 ('U-1000 R2V','Câble rigide cuivre XLPE, gaine PVC','power','multipolar','rigid',array['cu'],'XLPE',600,1000,'ac',
   array['conduit','sheath','apparent','tray','false_ceiling','trench','buried','support','flush'],array['dry','humid','outdoor','buried','mechanical'],
   array[1.5,2.5,4,6,10,16,25,35,50,70,95,120,150,185,240,300]::numeric[],array[1,2,3,4,5]::smallint[],false,false,false,false,'NF C 32-321','Câble d''énergie de distribution ; conditions d''usage à confirmer selon le référentiel du projet.'),
 ('U-1000 AR2V','Câble rigide aluminium XLPE, gaine PVC','power','multipolar','rigid',array['al'],'XLPE',600,1000,'ac',
   array['conduit','apparent','tray','trench','buried','support'],array['dry','humid','outdoor','buried','mechanical'],
   array[16,25,35,50,70,95,120,150,185,240,300]::numeric[],array[1,2,3,4]::smallint[],false,false,false,false,'NF C 33-210','Section minimale aluminium à contrôler selon le référentiel applicable.'),
 ('CR1-C1','Câble résistant au feu CR1-C1','fire_resistant','multipolar','rigid',array['cu'],'XLPE',600,1000,'ac',
   array['apparent','tray','support','false_ceiling'],array['dry','humid','fire_risk'],
   array[1.5,2.5,4,6,10,16,25,35]::numeric[],array[2,3,4,5]::smallint[],true,false,false,false,'NF C 32-070','Alimentation des installations de sécurité ; à confirmer avec la fiche fabricant.'),
 ('H07Z1-K','Conducteur souple sans halogène','halogen_free','unipolar','flexible',array['cu'],'LSZH',450,750,'ac',
   array['conduit','sheath','duct','flush'],array['dry','fire_risk'],array[1.5,2.5,4,6,10,16,25,35,50,70,95,120]::numeric[],array[1]::smallint[],false,true,false,false,'EN 50525-3-41','Faible émission de fumée, sans halogène ; locaux recevant du public selon le référentiel.'),
 ('CTRL-SH','Câble de commande blindé','shielded','multipolar','flexible',array['cu'],'PVC',300,500,'ac',
   array['tray','support','conduit','false_ceiling'],array['dry','humid'],array[0.5,0.75,1,1.5,2.5]::numeric[],array[2,3,4,5,7,12]::smallint[],false,false,true,false,null,'Câble de commande industriel type LiYCY ; caractéristiques à confirmer.'),
 ('IND-ARM','Câble industriel armé','armoured','multipolar','rigid',array['cu','al'],'XLPE',600,1000,'ac',
   array['tray','trench','buried','support'],array['dry','humid','outdoor','buried','mechanical','industrial'],array[4,6,10,16,25,35,50,70,95,120,150,185,240]::numeric[],array[3,4,5]::smallint[],false,false,false,true,null,'Armure acier ; caractéristiques à confirmer avec la fiche fabricant.'),
 ('H1Z2Z2-K','Câble photovoltaïque','photovoltaic','unipolar','flexible',array['cu'],'XLPO',null,1500,'dc',
   array['apparent','tray','support','conduit'],array['dry','humid','outdoor','uv'],array[1.5,2.5,4,6,10,16]::numeric[],array[1]::smallint[],false,true,false,false,'EN 50618','Tension assignée 1,5 kV continu ; cuivre étamé.'),
 ('COM-UTP6','Câble de communication U/UTP cat. 6','communication','multipolar','flexible',array['cu'],'other',null,50,'ac',
   array['conduit','tray','false_ceiling','flush'],array['dry'],array[0.2]::numeric[],array[8]::smallint[],false,false,false,false,'ISO/IEC 11801','Courant faible ; à séparer des câbles d''énergie.');

-- ---------------------------------------------------------------- E16 Types de pièces
create table public.elec_room_types (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade,
  code text not null check (length(trim(code)) > 0),
  label text not null,
  category text not null check (category in ('residential','tertiary','industrial','technical','outdoor','custom')),
  default_ceiling_height_m numeric(5,2),
  default_socket_height_m numeric(5,2),
  default_switch_height_m numeric(5,2),
  default_luminaire_height_m numeric(5,2),
  is_wet_room boolean not null default false,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create unique index uq_elec_room_types
  on public.elec_room_types (coalesce(organization_id, '00000000-0000-0000-0000-000000000000'::uuid), upper(code));

insert into public.elec_room_types (code,label,category,default_ceiling_height_m,default_socket_height_m,default_switch_height_m,default_luminaire_height_m,is_wet_room,sort_order) values
 ('SALON','Salon','residential',2.5,0.3,1.1,2.5,false,10),
 ('SEJOUR','Séjour','residential',2.5,0.3,1.1,2.5,false,20),
 ('CHAMBRE','Chambre','residential',2.5,0.3,1.1,2.5,false,30),
 ('CUISINE','Cuisine','residential',2.5,1.1,1.1,2.5,true,40),
 ('SDB','Salle de bains','residential',2.5,1.1,1.1,2.5,true,50),
 ('DOUCHE','Douche','residential',2.5,1.1,1.1,2.5,true,60),
 ('WC','WC','residential',2.5,0.3,1.1,2.5,true,70),
 ('COULOIR','Couloir','residential',2.5,0.3,1.1,2.5,false,80),
 ('HALL','Hall','residential',2.5,0.3,1.1,2.5,false,90),
 ('ESCALIER','Escalier','residential',2.5,0.3,1.1,2.5,false,100),
 ('GARAGE','Garage','residential',2.5,1.1,1.1,2.5,false,110),
 ('BUREAU','Bureau','tertiary',2.5,0.3,1.1,2.5,false,120),
 ('REUNION','Salle de réunion','tertiary',2.5,0.3,1.1,2.5,false,130),
 ('MAGASIN','Magasin','tertiary',3,0.3,1.1,3,false,140),
 ('ENTREPOT','Entrepôt','industrial',6,1.1,1.1,6,false,150),
 ('ATELIER','Atelier','industrial',4,1.1,1.1,4,false,160),
 ('LOC_TECH','Local technique','technical',2.5,1.1,1.1,2.5,false,170),
 ('LOC_INFO','Local informatique','technical',2.5,0.3,1.1,2.5,false,180),
 ('LOC_ELEC','Local électrique','technical',2.5,1.1,1.1,2.5,false,190),
 ('TERRASSE','Terrasse','outdoor',null,1.1,1.1,null,true,200),
 ('BALCON','Balcon','outdoor',null,1.1,1.1,null,true,210),
 ('COUR','Cour extérieure','outdoor',null,1.1,1.1,null,true,220),
 ('PARKING','Parking','outdoor',2.5,1.1,1.1,2.5,false,230),
 ('AUTRE','Autre local (personnalisable)','custom',2.5,0.3,1.1,2.5,false,999);

-- ---------------------------------------------------------------- E16/E17 Pièces
create table public.elec_rooms (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  room_type_id uuid references public.elec_room_types(id),
  building text,
  floor_label text,
  name text not null check (length(trim(name)) > 0),
  length_m numeric(8,3) not null check (length_m > 0),
  width_m numeric(8,3) not null check (width_m > 0),
  height_m numeric(8,3) not null check (height_m > 0),
  ceiling_height_m numeric(8,3) check (ceiling_height_m is null or ceiling_height_m > 0),
  doors_count integer not null default 0 check (doors_count >= 0),
  windows_count integer not null default 0 check (windows_count >= 0),
  socket_height_m numeric(5,2) check (socket_height_m is null or socket_height_m >= 0),
  switch_height_m numeric(5,2) check (switch_height_m is null or switch_height_m >= 0),
  luminaire_height_m numeric(5,2) check (luminaire_height_m is null or luminaire_height_m >= 0),
  panel_x_m numeric(8,3),
  panel_y_m numeric(8,3),
  area_m2 numeric(14,4) generated always as (length_m * width_m) stored,
  perimeter_m numeric(14,4) generated always as (2 * (length_m + width_m)) stored,
  volume_m3 numeric(16,4) generated always as (length_m * width_m * height_m) stored,
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (panel_x_m is null or (panel_x_m >= 0 and panel_x_m <= length_m)),
  check (panel_y_m is null or (panel_y_m >= 0 and panel_y_m <= width_m))
);
create index idx_elec_rooms_project on public.elec_rooms(project_id, building, floor_label);
create trigger elec_rooms_touch before update on public.elec_rooms
  for each row execute function public.touch_updated_at();

create table public.elec_room_openings (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.elec_rooms(id) on delete cascade,
  kind text not null check (kind in ('door','window')),
  wall text not null check (wall in ('north','south','east','west')),
  offset_m numeric(8,3) not null check (offset_m >= 0),
  width_m numeric(8,3) not null check (width_m > 0),
  height_m numeric(8,3) check (height_m is null or height_m > 0),
  label text,
  created_at timestamptz not null default now()
);
create index idx_elec_room_openings_room on public.elec_room_openings(room_id);

-- Contrôle de l'ouverture (elle doit tenir dans le mur) et synchronisation des compteurs.
create or replace function public.elec_room_openings_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_len numeric;
begin
  select case when new.wall in ('north','south') then length_m else width_m end
    into v_len from public.elec_rooms where id = new.room_id;
  if v_len is null then raise exception 'Pièce introuvable'; end if;
  if new.offset_m + new.width_m > v_len then
    raise exception 'L''ouverture dépasse la longueur du mur (% m)', v_len;
  end if;
  return new;
end $$;
create trigger elec_room_openings_guard_trigger before insert or update on public.elec_room_openings
  for each row execute function public.elec_room_openings_guard();

create or replace function public.elec_room_openings_sync()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_room uuid;
begin
  v_room := coalesce(new.room_id, old.room_id);
  update public.elec_rooms r set
    doors_count = (select count(*) from public.elec_room_openings o where o.room_id = v_room and o.kind = 'door'),
    windows_count = (select count(*) from public.elec_room_openings o where o.room_id = v_room and o.kind = 'window')
  where r.id = v_room;
  return null;
end $$;
create trigger elec_room_openings_sync_trigger after insert or update or delete on public.elec_room_openings
  for each row execute function public.elec_room_openings_sync();

-- ---------------------------------------------------------------- Sécurité
create or replace function public.can_manage_project_electrical(p_project uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.can_manage_project(p_project) or public.can_manage_project_study(p_project)
$$;
revoke all on function public.can_manage_project_electrical(uuid) from public;
grant execute on function public.can_manage_project_electrical(uuid) to authenticated;

alter table public.elec_voltage_domains enable row level security;
alter table public.elec_installations enable row level security;
alter table public.elec_cable_types enable row level security;
alter table public.elec_room_types enable row level security;
alter table public.elec_rooms enable row level security;
alter table public.elec_room_openings enable row level security;

-- Référentiels : lecture du défaut + de son organisation ; écriture réservée à l'organisation.
create policy elec_voltage_domains_read on public.elec_voltage_domains for select to authenticated
  using (organization_id is null or public.is_org_member(organization_id));
create policy elec_voltage_domains_write on public.elec_voltage_domains for all to authenticated
  using (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'))
  with check (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'));
create policy elec_cable_types_read on public.elec_cable_types for select to authenticated
  using (organization_id is null or public.is_org_member(organization_id));
create policy elec_cable_types_write on public.elec_cable_types for all to authenticated
  using (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'))
  with check (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'));
create policy elec_room_types_read on public.elec_room_types for select to authenticated
  using (organization_id is null or public.is_org_member(organization_id));
create policy elec_room_types_write on public.elec_room_types for all to authenticated
  using (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'))
  with check (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'));

-- Données de projet.
create policy elec_installations_read on public.elec_installations for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_installations_write on public.elec_installations for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));
create policy elec_rooms_read on public.elec_rooms for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_rooms_write on public.elec_rooms for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));
create policy elec_room_openings_read on public.elec_room_openings for select to authenticated
  using (exists (select 1 from public.elec_rooms r where r.id = room_id and public.can_access_project(r.project_id)));
create policy elec_room_openings_write on public.elec_room_openings for all to authenticated
  using (exists (select 1 from public.elec_rooms r where r.id = room_id and public.can_manage_project_electrical(r.project_id)))
  with check (exists (select 1 from public.elec_rooms r where r.id = room_id and public.can_manage_project_electrical(r.project_id)));
