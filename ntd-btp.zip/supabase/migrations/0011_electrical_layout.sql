-- =====================================================================
-- V10 — Module électrique, étape E18 : implantation des équipements sur plan.
--   Équipements positionnés dans une pièce (coordonnées en mètres),
--   cheminements dessinés (polylignes) dont la longueur horizontale est
--   calculée par la base à partir du tracé réel, jamais saisie.
-- Les longueurs verticales, traversées et réserves relèvent de E24.
-- Migration NON destructive.
-- =====================================================================

create table public.elec_equipment_types (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade,
  code text not null check (length(trim(code)) > 0),
  label text not null,
  category text not null check (category in
    ('lighting','switch','socket','junction_box','panel','hvac','specialized','detector','security','communication')),
  symbol text not null default '?',
  height_source text not null default 'none' check (height_source in ('none','luminaire','switch','socket')),
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create unique index uq_elec_equipment_types
  on public.elec_equipment_types (coalesce(organization_id, '00000000-0000-0000-0000-000000000000'::uuid), upper(code));

-- Aucune puissance par défaut : elle est saisie par l'utilisateur.
insert into public.elec_equipment_types (code,label,category,symbol,height_source,sort_order) values
 ('LUM','Luminaire','lighting','L','luminaire',10),
 ('INT','Interrupteur','switch','S','switch',20),
 ('PC','Prise de courant','socket','P','socket',30),
 ('PC_SPEC','Prise spécialisée','socket','PS','socket',40),
 ('BD','Boîte de dérivation','junction_box','BD','none',50),
 ('TAB','Tableau électrique','panel','TD','none',60),
 ('CLIM','Climatisation','hvac','AC','none',70),
 ('EQ_SPEC','Équipement spécialisé','specialized','EQ','none',80),
 ('DET_PRES','Détecteur de présence','detector','DP','none',90),
 ('DET_FUM','Détecteur de fumée','detector','DF','none',100),
 ('SEC','Équipement de sécurité','security','SE','none',110),
 ('COM','Prise de communication','communication','RJ','socket',120);

create table public.elec_equipment (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  room_id uuid not null references public.elec_rooms(id) on delete cascade,
  equipment_type_id uuid not null references public.elec_equipment_types(id),
  label text,
  x_m numeric(8,3) not null check (x_m >= 0),
  y_m numeric(8,3) not null check (y_m >= 0),
  z_m numeric(8,3) check (z_m is null or z_m >= 0),
  power_w numeric(12,2) check (power_w is null or power_w >= 0),
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_elec_equipment_room on public.elec_equipment(room_id);
create index idx_elec_equipment_project on public.elec_equipment(project_id);
create trigger elec_equipment_touch before update on public.elec_equipment
  for each row execute function public.touch_updated_at();

create or replace function public.elec_equipment_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_room record; v_type_org uuid; v_org uuid; v_found boolean;
begin
  select project_id, length_m, width_m, height_m into v_room from public.elec_rooms where id = new.room_id;
  if not found then raise exception 'Pièce introuvable'; end if;
  if v_room.project_id <> new.project_id then raise exception 'La pièce n''appartient pas à ce projet'; end if;
  if new.x_m > v_room.length_m or new.y_m > v_room.width_m then
    raise exception 'Position hors de la pièce (%, % m pour % × % m)', new.x_m, new.y_m, v_room.length_m, v_room.width_m;
  end if;
  if new.z_m is not null and new.z_m > v_room.height_m then
    raise exception 'La hauteur de pose dépasse la hauteur de la pièce';
  end if;
  select organization_id into v_org from public.projects where id = new.project_id;
  select organization_id, true into v_type_org, v_found from public.elec_equipment_types where id = new.equipment_type_id;
  if not coalesce(v_found, false) then raise exception 'Type d''équipement introuvable'; end if;
  if v_type_org is not null and v_type_org <> v_org then raise exception 'Ce type d''équipement appartient à une autre organisation'; end if;
  return new;
end $$;
create trigger elec_equipment_guard_trigger before insert or update on public.elec_equipment
  for each row execute function public.elec_equipment_guard();

-- ---------------------------------------------------------------- Cheminements
create table public.elec_routes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  room_id uuid not null references public.elec_rooms(id) on delete cascade,
  kind text not null default 'cable' check (kind in ('cable','cable_tray','duct','conduit')),
  label text,
  from_equipment_id uuid references public.elec_equipment(id) on delete set null,
  to_equipment_id uuid references public.elec_equipment(id) on delete set null,
  points jsonb not null,                                   -- [{"x":m,"y":m}, ...]
  horizontal_length_m numeric(12,3) not null default 0,    -- calculée par le trigger
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_elec_routes_room on public.elec_routes(room_id);
create index idx_elec_routes_project on public.elec_routes(project_id);
create trigger elec_routes_touch before update on public.elec_routes
  for each row execute function public.touch_updated_at();

create or replace function public.elec_routes_before()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_room record; n integer; i integer;
  x numeric; y numeric; px numeric; py numeric; total numeric := 0;
begin
  select project_id, length_m, width_m into v_room from public.elec_rooms where id = new.room_id;
  if not found then raise exception 'Pièce introuvable'; end if;
  if v_room.project_id <> new.project_id then raise exception 'La pièce n''appartient pas à ce projet'; end if;
  if jsonb_typeof(new.points) <> 'array' then raise exception 'Le tracé doit être une liste de points'; end if;
  n := jsonb_array_length(new.points);
  if n < 2 then raise exception 'Un cheminement comporte au moins 2 points'; end if;
  for i in 0 .. n - 1 loop
    x := (new.points -> i ->> 'x')::numeric;
    y := (new.points -> i ->> 'y')::numeric;
    if x is null or y is null then raise exception 'Point % invalide', i + 1; end if;
    if x < 0 or x > v_room.length_m or y < 0 or y > v_room.width_m then
      raise exception 'Le point % est hors de la pièce', i + 1;
    end if;
    if i > 0 then total := total + sqrt((x - px) ^ 2 + (y - py) ^ 2); end if;
    px := x; py := y;
  end loop;
  if total <= 0 then raise exception 'Le cheminement a une longueur nulle'; end if;
  new.horizontal_length_m := round(total, 3);
  return new;
end $$;
create trigger elec_routes_before_trigger before insert or update of points, room_id, project_id on public.elec_routes
  for each row execute function public.elec_routes_before();

-- ---------------------------------------------------------------- Sécurité
alter table public.elec_equipment_types enable row level security;
alter table public.elec_equipment enable row level security;
alter table public.elec_routes enable row level security;

create policy elec_equipment_types_read on public.elec_equipment_types for select to authenticated
  using (organization_id is null or public.is_org_member(organization_id));
create policy elec_equipment_types_write on public.elec_equipment_types for all to authenticated
  using (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'))
  with check (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'));

create policy elec_equipment_read on public.elec_equipment for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_equipment_write on public.elec_equipment for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));
create policy elec_routes_read on public.elec_routes for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_routes_write on public.elec_routes for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));
