-- =====================================================================
-- V13 — Module électrique, étape E21 : calcul des courants.
--   Chaque équipement peut être rattaché à une installation (alimentation), avoir un
--   mode de raccordement (monophasé / triphasé) et un rendement. Le facteur de puissance
--   existe déjà (0013). Aucune valeur n'est supposée : les données manquantes sont demandées.
-- Migration NON destructive.
-- =====================================================================

alter table public.elec_equipment
  add column installation_id uuid references public.elec_installations(id) on delete set null,
  add column connection text check (connection is null or connection in ('single','three')),
  add column efficiency numeric(4,3) check (efficiency is null or (efficiency > 0 and efficiency <= 1));

create index idx_elec_equipment_installation on public.elec_equipment(installation_id);

-- Garde mise à jour : l'installation doit appartenir au même projet.
create or replace function public.elec_equipment_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_room record; v_type_org uuid; v_org uuid; v_found boolean;
begin
  select project_id, length_m, width_m, height_m into v_room from public.elec_rooms where id = new.room_id;
  if not found then raise exception 'Pièce introuvable'; end if;
  if v_room.project_id <> new.project_id then raise exception 'La pièce n''appartient pas à ce projet'; end if;
  if new.x_m > v_room.length_m or new.y_m > v_room.width_m then
    raise exception 'Position hors de la pièce (%, % m pour % × % m)', new.x_m, new.y_m, v_room.length_m, v_room.width_m;
  end if;
  if new.z_m is not null and new.z_m > v_room.height_m then
    raise exception 'La hauteur de pose dépasse la hauteur de la pièce';
  end if;
  select organization_id into v_org from public.projects where id = new.project_id;
  select organization_id, true into v_type_org, v_found from public.elec_equipment_types where id = new.equipment_type_id;
  if not coalesce(v_found, false) then raise exception 'Type d''équipement introuvable'; end if;
  if v_type_org is not null and v_type_org <> v_org then raise exception 'Ce type d''équipement appartient à une autre organisation'; end if;
  if new.installation_id is not null then
    perform 1 from public.elec_installations where id = new.installation_id and project_id = new.project_id;
    if not found then raise exception 'Installation introuvable ou appartenant à un autre projet'; end if;
  end if;
  return new;
end $$;
