-- =====================================================================
-- V14 — Module électrique, préparation de E22 : modèle de circuits.
--   Un circuit regroupe des équipements alimentés par une même installation, avec les données
--   nécessaires au dimensionnement (matériau, pose, environnement, température, regroupement,
--   longueur, chute de tension admissible, courant de court-circuit, protection).
--   Aucune de ces données n'a de valeur par défaut, sauf le coefficient de simultanéité (1 = aucune diversité).
-- Migration NON destructive.
-- =====================================================================

create table public.elec_circuits (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  installation_id uuid references public.elec_installations(id) on delete set null,
  number text not null check (length(trim(number)) > 0),
  name text,
  circuit_type text not null default 'other' check (circuit_type in
    ('lighting','socket','specialized','hvac','power','control','communication','other')),
  origin_label text,                                   -- tableau / départ
  connection text check (connection is null or connection in ('single','three')),
  conductor_material text check (conductor_material is null or conductor_material in ('cu','al')),
  laying_mode text check (laying_mode is null or laying_mode in
    ('flush','conduit','sheath','apparent','tray','false_ceiling','trench','buried','support','duct','industrial')),
  environments text[] not null default '{}',
  ambient_temp_c numeric(5,1) check (ambient_temp_c is null or (ambient_temp_c >= -60 and ambient_temp_c <= 150)),
  grouped_circuits integer check (grouped_circuits is null or grouped_circuits >= 1),
  length_m numeric(10,2) check (length_m is null or length_m > 0),   -- saisie ; sera calculée depuis les tracés en E24
  demand_coefficient numeric(4,3) not null default 1 check (demand_coefficient > 0 and demand_coefficient <= 1),
  max_voltage_drop_pct numeric(5,2) check (max_voltage_drop_pct is null or (max_voltage_drop_pct > 0 and max_voltage_drop_pct <= 100)),
  icc_ka numeric(8,2) check (icc_ka is null or icc_ka > 0),
  protection_type text,
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id, number)
);
create index idx_elec_circuits_project on public.elec_circuits(project_id);
create trigger elec_circuits_touch before update on public.elec_circuits
  for each row execute function public.touch_updated_at();

create or replace function public.elec_circuits_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.installation_id is not null then
    perform 1 from public.elec_installations where id = new.installation_id and project_id = new.project_id;
    if not found then raise exception 'Installation introuvable ou appartenant à un autre projet'; end if;
  end if;
  return new;
end $$;
create trigger elec_circuits_guard_trigger before insert or update of installation_id, project_id on public.elec_circuits
  for each row execute function public.elec_circuits_guard();

-- Les équipements d'un circuit suivent l'installation du circuit.
create or replace function public.elec_circuits_sync_equipment()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.installation_id is distinct from old.installation_id then
    update public.elec_equipment set installation_id = new.installation_id where circuit_id = new.id;
  end if;
  return null;
end $$;
create trigger elec_circuits_sync_equipment_trigger after update of installation_id on public.elec_circuits
  for each row execute function public.elec_circuits_sync_equipment();

alter table public.elec_equipment
  add column circuit_id uuid references public.elec_circuits(id) on delete set null;
create index idx_elec_equipment_circuit on public.elec_equipment(circuit_id);

create or replace function public.elec_equipment_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_room record; v_type_org uuid; v_org uuid; v_found boolean; v_circuit record;
begin
  select project_id, length_m, width_m, height_m into v_room from public.elec_rooms where id = new.room_id;
  if not found then raise exception 'Pièce introuvable'; end if;
  if v_room.project_id <> new.project_id then raise exception 'La pièce n''appartient pas à ce projet'; end if;
  if new.x_m > v_room.length_m or new.y_m > v_room.width_m then
    raise exception 'Position hors de la pièce (%, % m pour % × % m)', new.x_m, new.y_m, v_room.length_m, v_room.width_m;
  end if;
  if new.z_m is not null and new.z_m > v_room.height_m then
    raise exception 'La hauteur de pose dépasse la hauteur de la pièce';
  end if;
  select organization_id into v_org from public.projects where id = new.project_id;
  select organization_id, true into v_type_org, v_found from public.elec_equipment_types where id = new.equipment_type_id;
  if not coalesce(v_found, false) then raise exception 'Type d''équipement introuvable'; end if;
  if v_type_org is not null and v_type_org <> v_org then raise exception 'Ce type d''équipement appartient à une autre organisation'; end if;
  if new.installation_id is not null then
    perform 1 from public.elec_installations where id = new.installation_id and project_id = new.project_id;
    if not found then raise exception 'Installation introuvable ou appartenant à un autre projet'; end if;
  end if;
  if new.circuit_id is not null then
    select project_id, installation_id into v_circuit from public.elec_circuits where id = new.circuit_id;
    if not found then raise exception 'Circuit introuvable'; end if;
    if v_circuit.project_id <> new.project_id then raise exception 'Le circuit appartient à un autre projet'; end if;
    if v_circuit.installation_id is not null then new.installation_id := v_circuit.installation_id; end if;
  end if;
  return new;
end $$;

alter table public.elec_circuits enable row level security;
create policy elec_circuits_read on public.elec_circuits for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_circuits_write on public.elec_circuits for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));
