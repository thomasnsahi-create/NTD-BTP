-- BTP MANAGER V4 — Gestion complète des projets (migration additive)
-- À exécuter après 0001, 0002 et 0003. Ne supprime aucune donnée existante.

alter table public.projects
  add column if not exists responsible_user_id uuid references auth.users(id) on delete set null,
  add column if not exists progress_percent numeric(5,2) not null default 0 check (progress_percent between 0 and 100),
  add column if not exists priority text not null default 'normal' check (priority in ('low','normal','high','critical')),
  add column if not exists updated_by uuid references auth.users(id);

alter table public.project_members
  add column if not exists is_responsible boolean not null default false,
  add column if not exists allocation_percent numeric(5,2) not null default 100 check (allocation_percent between 0 and 100);

alter table public.work_packages
  add column if not exists progress_percent numeric(5,2) not null default 0 check (progress_percent between 0 and 100),
  add column if not exists sort_order integer not null default 0,
  add column if not exists responsible_user_id uuid references auth.users(id) on delete set null;

-- Un projet peut relever de plusieurs secteurs, sans perdre le secteur principal historique.
create table if not exists public.project_sectors (
  project_id uuid not null references public.projects(id) on delete cascade,
  sector_id uuid not null references public.sectors(id) on delete restrict,
  is_primary boolean not null default false,
  created_at timestamptz not null default now(),
  primary key(project_id, sector_id)
);
insert into public.project_sectors(project_id, sector_id, is_primary)
select id, sector_id, true from public.projects where sector_id is not null
on conflict (project_id, sector_id) do nothing;

create table if not exists public.project_phases (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  name text not null,
  description text,
  phase_order integer not null default 0,
  status text not null default 'not_started' check (status in ('not_started','in_progress','on_hold','completed','cancelled')),
  planned_start date,
  planned_end date,
  actual_start date,
  actual_end date,
  progress_percent numeric(5,2) not null default 0 check (progress_percent between 0 and 100),
  responsible_user_id uuid references auth.users(id) on delete set null,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (planned_end is null or planned_start is null or planned_end >= planned_start)
);

create table if not exists public.project_tasks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  phase_id uuid references public.project_phases(id) on delete set null,
  work_package_id uuid references public.work_packages(id) on delete set null,
  parent_task_id uuid references public.project_tasks(id) on delete set null,
  code text,
  name text not null,
  description text,
  status text not null default 'not_started' check (status in ('not_started','in_progress','blocked','on_hold','completed','cancelled')),
  priority text not null default 'normal' check (priority in ('low','normal','high','critical')),
  planned_start date,
  planned_end date,
  actual_start date,
  actual_end date,
  progress_percent numeric(5,2) not null default 0 check (progress_percent between 0 and 100),
  weight numeric(10,2) not null default 1 check (weight > 0),
  responsible_user_id uuid references auth.users(id) on delete set null,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (planned_end is null or planned_start is null or planned_end >= planned_start)
);

create table if not exists public.project_task_dependencies (
  task_id uuid not null references public.project_tasks(id) on delete cascade,
  depends_on_task_id uuid not null references public.project_tasks(id) on delete cascade,
  dependency_type text not null default 'finish_to_start' check (dependency_type in ('finish_to_start','start_to_start','finish_to_finish','start_to_finish')),
  created_at timestamptz not null default now(),
  primary key(task_id, depends_on_task_id),
  check(task_id <> depends_on_task_id)
);

create table if not exists public.project_budget_lines (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  phase_id uuid references public.project_phases(id) on delete set null,
  work_package_id uuid references public.work_packages(id) on delete set null,
  code text,
  category text not null default 'other',
  designation text not null,
  unit text,
  quantity numeric(18,3) not null default 1 check (quantity >= 0),
  unit_price numeric(18,2) not null default 0 check (unit_price >= 0),
  estimated_amount numeric(18,2) generated always as (round(quantity * unit_price, 2)) stored,
  actual_amount numeric(18,2) not null default 0 check (actual_amount >= 0),
  currency char(3) not null default 'XAF',
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.project_progress_updates (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  phase_id uuid references public.project_phases(id) on delete set null,
  task_id uuid references public.project_tasks(id) on delete set null,
  progress_percent numeric(5,2) not null check (progress_percent between 0 and 100),
  report text,
  blockers text,
  reported_by uuid not null default auth.uid() references auth.users(id),
  reported_at timestamptz not null default now()
);

-- Indexes pour les listes et tableaux de bord.
create index if not exists idx_project_sectors_sector on public.project_sectors(sector_id);
create index if not exists idx_project_phases_project on public.project_phases(project_id, phase_order);
create index if not exists idx_project_tasks_project on public.project_tasks(project_id, planned_start, planned_end);
create index if not exists idx_project_tasks_phase on public.project_tasks(phase_id);
create index if not exists idx_project_budget_project on public.project_budget_lines(project_id);
create index if not exists idx_project_progress_project on public.project_progress_updates(project_id, reported_at desc);

-- Accès aux membres actifs de l'organisation; écriture pilotée par les permissions.
create or replace function public.project_org_id(p_project uuid)
returns uuid language sql stable security definer set search_path=public
as $$ select organization_id from public.projects where id=p_project $$;
revoke all on function public.project_org_id(uuid) from public;

create or replace function public.can_manage_project(p_project uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.projects p where p.id=p_project and public.has_org_permission(p.organization_id,'projects.manage')) $$;

create or replace function public.can_manage_project_schedule(p_project uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.projects p where p.id=p_project and (public.has_org_permission(p.organization_id,'projects.schedule.manage') or public.has_org_permission(p.organization_id,'projects.manage'))) $$;

create or replace function public.can_manage_project_finance(p_project uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.projects p where p.id=p_project and (public.has_org_permission(p.organization_id,'finance.manage') or public.has_org_permission(p.organization_id,'projects.budget.manage') or public.has_org_permission(p.organization_id,'projects.manage'))) $$;

alter table public.project_sectors enable row level security;
alter table public.project_phases enable row level security;
alter table public.project_tasks enable row level security;
alter table public.project_task_dependencies enable row level security;
alter table public.project_budget_lines enable row level security;
alter table public.project_progress_updates enable row level security;

-- RLS : lecture réservée aux membres actifs de l'organisation du projet.
drop policy if exists project_sectors_read on public.project_sectors;
create policy project_sectors_read on public.project_sectors for select to authenticated using (public.can_access_project(project_id));
create policy project_sectors_manage on public.project_sectors for all to authenticated using (public.can_manage_project_schedule(project_id)) with check (public.can_manage_project_schedule(project_id));

drop policy if exists project_phases_read on public.project_phases;
create policy project_phases_read on public.project_phases for select to authenticated using (public.can_access_project(project_id));
create policy project_phases_manage on public.project_phases for all to authenticated using (public.can_manage_project_schedule(project_id)) with check (public.can_manage_project_schedule(project_id));

create policy project_tasks_read on public.project_tasks for select to authenticated using (public.can_access_project(project_id));
create policy project_tasks_manage on public.project_tasks for all to authenticated using (public.can_manage_project_schedule(project_id)) with check (public.can_manage_project_schedule(project_id));

create policy project_task_dependencies_read on public.project_task_dependencies for select to authenticated using (
  exists(select 1 from public.project_tasks t where t.id=task_id and public.can_access_project(t.project_id))
);
create policy project_task_dependencies_manage on public.project_task_dependencies for all to authenticated using (
  exists(select 1 from public.project_tasks t where t.id=task_id and public.can_manage_project_schedule(t.project_id))
) with check (
  exists(select 1 from public.project_tasks t join public.project_tasks d on d.id=depends_on_task_id where t.id=task_id and t.project_id=d.project_id and public.can_manage_project_schedule(t.project_id))
);

create policy project_budget_lines_read on public.project_budget_lines for select to authenticated using (
  exists(select 1 from public.projects p where p.id=project_id and (public.has_org_permission(p.organization_id,'finance.view') or public.has_org_permission(p.organization_id,'projects.budget.view') or public.has_org_permission(p.organization_id,'finance.manage') or public.has_org_permission(p.organization_id,'projects.budget.manage') or public.has_org_permission(p.organization_id,'projects.manage')))
);
create policy project_budget_lines_manage on public.project_budget_lines for all to authenticated using (public.can_manage_project_finance(project_id)) with check (public.can_manage_project_finance(project_id));

create policy project_progress_updates_read on public.project_progress_updates for select to authenticated using (public.can_access_project(project_id));
create policy project_progress_updates_insert on public.project_progress_updates for insert to authenticated with check (public.can_access_project(project_id) and reported_by=auth.uid() and exists(select 1 from public.projects p where p.id=project_id and (public.has_org_permission(p.organization_id,'projects.progress.report') or public.has_org_permission(p.organization_id,'projects.manage'))));
create policy project_progress_updates_manage on public.project_progress_updates for update to authenticated using (public.can_manage_project(project_id)) with check (public.can_manage_project(project_id));

-- Garde-fous : les références d'une tâche/phase/lot doivent appartenir au même projet.
create or replace function public.validate_project_task_links()
returns trigger language plpgsql set search_path=public
as $$
begin
  if new.phase_id is not null and not exists(select 1 from public.project_phases where id=new.phase_id and project_id=new.project_id) then raise exception 'La phase sélectionnée appartient à un autre projet'; end if;
  if new.work_package_id is not null and not exists(select 1 from public.work_packages where id=new.work_package_id and project_id=new.project_id) then raise exception 'Le lot sélectionné appartient à un autre projet'; end if;
  if new.parent_task_id is not null and not exists(select 1 from public.project_tasks where id=new.parent_task_id and project_id=new.project_id) then raise exception 'La tâche parente appartient à un autre projet'; end if;
  return new;
end $$;
drop trigger if exists validate_project_task_links_trigger on public.project_tasks;
create trigger validate_project_task_links_trigger before insert or update on public.project_tasks for each row execute function public.validate_project_task_links();

create or replace function public.validate_project_dependency_links()
returns trigger language plpgsql set search_path=public
as $$
begin
  if not exists(select 1 from public.project_tasks a join public.project_tasks b on b.id=new.depends_on_task_id where a.id=new.task_id and a.project_id=b.project_id) then raise exception 'Les tâches liées doivent appartenir au même projet'; end if;
  return new;
end $$;
drop trigger if exists validate_project_dependency_links_trigger on public.project_task_dependencies;
create trigger validate_project_dependency_links_trigger before insert or update on public.project_task_dependencies for each row execute function public.validate_project_dependency_links();

-- Calcul pondéré de l'avancement global à partir des tâches. Si aucune tâche, moyenne des phases.
create or replace function public.refresh_project_progress(p_project uuid)
returns void language plpgsql security definer set search_path=public
as $$
declare v_progress numeric(5,2);
begin
  select case when sum(weight)>0 then round(sum(progress_percent*weight)/sum(weight),2) else null end
    into v_progress from public.project_tasks where project_id=p_project and status <> 'cancelled';
  if v_progress is null then
    select round(avg(progress_percent),2) into v_progress from public.project_phases where project_id=p_project and status <> 'cancelled';
  end if;
  update public.projects set progress_percent=coalesce(v_progress,0), updated_at=now() where id=p_project;
end $$;
revoke all on function public.refresh_project_progress(uuid) from public;

create or replace function public.refresh_project_progress_from_task()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_project uuid;
begin
  if tg_op='DELETE' then v_project := old.project_id; else v_project := new.project_id; end if;
  perform public.refresh_project_progress(v_project);
  if tg_op='UPDATE' and old.project_id is distinct from new.project_id then perform public.refresh_project_progress(old.project_id); end if;
  if tg_op='DELETE' then return old; else return new; end if;
end $$;
drop trigger if exists refresh_progress_after_task on public.project_tasks;
create trigger refresh_progress_after_task after insert or update or delete on public.project_tasks for each row execute function public.refresh_project_progress_from_task();

create or replace function public.refresh_project_progress_from_phase()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if tg_op='DELETE' then perform public.refresh_project_progress(old.project_id); return old; end if;
  perform public.refresh_project_progress(new.project_id); return new;
end $$;
drop trigger if exists refresh_progress_after_phase on public.project_phases;
create trigger refresh_progress_after_phase after insert or update or delete on public.project_phases for each row execute function public.refresh_project_progress_from_phase();

-- Vérifie les responsables des lots, phases et tâches au niveau de la base.
create or replace function public.validate_project_assignee()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if new.responsible_user_id is not null and not exists(
    select 1 from public.projects p join public.organization_memberships m on m.organization_id=p.organization_id and m.user_id=new.responsible_user_id and m.status='active'
    where p.id=new.project_id
  ) then raise exception 'Le responsable affecté doit être un membre actif de l’organisation'; end if;
  return new;
end $$;
drop trigger if exists validate_lot_assignee on public.work_packages;
create trigger validate_lot_assignee before insert or update on public.work_packages for each row execute function public.validate_project_assignee();
drop trigger if exists validate_phase_assignee on public.project_phases;
create trigger validate_phase_assignee before insert or update on public.project_phases for each row execute function public.validate_project_assignee();
drop trigger if exists validate_task_assignee on public.project_tasks;
create trigger validate_task_assignee before insert or update on public.project_tasks for each row execute function public.validate_project_assignee();

-- Vérifie que les membres et responsables affectés appartiennent bien à l'organisation du projet.
create or replace function public.validate_project_member_org()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if not exists(select 1 from public.projects p join public.organization_memberships m on m.organization_id=p.organization_id and m.user_id=new.user_id and m.status='active' where p.id=new.project_id) then
    raise exception 'Le membre doit appartenir à l’organisation et être actif';
  end if;
  return new;
end $$;
drop trigger if exists validate_project_member_org_trigger on public.project_members;
create trigger validate_project_member_org_trigger before insert or update on public.project_members for each row execute function public.validate_project_member_org();

create or replace function public.prevent_project_task_dependency_cycle()
returns trigger language plpgsql set search_path=public
as $$
begin
  if exists(
    with recursive chain(task_id) as (
      select new.depends_on_task_id
      union
      select d.depends_on_task_id from public.project_task_dependencies d join chain c on d.task_id=c.task_id
    ) select 1 from chain where task_id=new.task_id
  ) then raise exception 'Cette dépendance créerait un cycle entre les tâches'; end if;
  return new;
end $$;
drop trigger if exists prevent_project_task_dependency_cycle_trigger on public.project_task_dependencies;
create trigger prevent_project_task_dependency_cycle_trigger before insert or update on public.project_task_dependencies for each row execute function public.prevent_project_task_dependency_cycle();

-- Déclaration d'avancement contrôlée côté serveur : un déclarant ne peut modifier que les champs d'avancement.
create or replace function public.report_project_task_progress(p_task_id uuid, p_progress numeric, p_status text, p_report text default null)
returns void language plpgsql security definer set search_path=public
as $$
declare v_project uuid; v_org uuid;
begin
  if auth.uid() is null then raise exception 'Authentification requise'; end if;
  if p_progress < 0 or p_progress > 100 then raise exception 'Pourcentage invalide'; end if;
  if p_status not in ('not_started','in_progress','blocked','on_hold','completed','cancelled') then raise exception 'Statut invalide'; end if;
  select project_id into v_project from public.project_tasks where id=p_task_id;
  if v_project is null then raise exception 'Tâche introuvable'; end if;
  select organization_id into v_org from public.projects where id=v_project;
  if not (public.has_org_permission(v_org,'projects.progress.report') or public.has_org_permission(v_org,'projects.schedule.manage') or public.has_org_permission(v_org,'projects.manage')) then raise exception 'Droit de déclaration d’avancement requis'; end if;
  update public.project_tasks set progress_percent=p_progress,status=p_status,
    actual_start=case when p_progress>0 then coalesce(actual_start,current_date) else actual_start end,
    actual_end=case when p_progress>=100 then current_date else actual_end end
    where id=p_task_id;
  insert into public.project_progress_updates(project_id,task_id,progress_percent,report,reported_by)
  values(v_project,p_task_id,p_progress,nullif(trim(p_report),''),auth.uid());
end $$;
revoke all on function public.report_project_task_progress(uuid,numeric,text,text) from public;
grant execute on function public.report_project_task_progress(uuid,numeric,text,text) to authenticated;

create or replace function public.validate_project_budget_links()
returns trigger language plpgsql set search_path=public
as $$
begin
  if new.phase_id is not null and not exists(select 1 from public.project_phases where id=new.phase_id and project_id=new.project_id) then raise exception 'La phase budgétaire appartient à un autre projet'; end if;
  if new.work_package_id is not null and not exists(select 1 from public.work_packages where id=new.work_package_id and project_id=new.project_id) then raise exception 'Le lot budgétaire appartient à un autre projet'; end if;
  return new;
end $$;
drop trigger if exists validate_project_budget_links_trigger on public.project_budget_lines;
create trigger validate_project_budget_links_trigger before insert or update on public.project_budget_lines for each row execute function public.validate_project_budget_links();

-- Journal d'activité serveur sur les principales entités du projet.
create or replace function public.audit_project_record()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_project uuid; v_org uuid; v_record text; v_action text;
begin
  if tg_op='DELETE' then v_project:=old.project_id; v_record:=old.id::text;
  else v_project:=new.project_id; v_record:=new.id::text; end if;
  select organization_id into v_org from public.projects where id=v_project;
  v_action := lower(tg_table_name)||'.'||lower(tg_op);
  insert into public.audit_logs(organization_id,actor_user_id,action,table_name,record_id,details)
  values(v_org,auth.uid(),v_action,tg_table_name,v_record,jsonb_build_object('project_id',v_project));
  if tg_op='DELETE' then return old; else return new; end if;
end $$;

create or replace function public.audit_project_header()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_org uuid; v_id uuid; v_code text; v_name text;
begin
  if tg_op='DELETE' then v_org:=old.organization_id; v_id:=old.id; v_code:=old.code; v_name:=old.name;
  else v_org:=new.organization_id; v_id:=new.id; v_code:=new.code; v_name:=new.name; end if;
  insert into public.audit_logs(organization_id,actor_user_id,action,table_name,record_id,details)
  values(v_org,auth.uid(),'projects.'||lower(tg_op),'projects',v_id::text,jsonb_build_object('project_code',v_code,'project_name',v_name));
  if tg_op='DELETE' then return old; else return new; end if;
end $$;
drop trigger if exists audit_project_headers on public.projects;
create trigger audit_project_headers after insert or update or delete on public.projects for each row execute function public.audit_project_header();
drop trigger if exists audit_project_members on public.project_members;
create trigger audit_project_members after insert or update or delete on public.project_members for each row execute function public.audit_project_record();

drop trigger if exists audit_project_phases on public.project_phases;
create trigger audit_project_phases after insert or update or delete on public.project_phases for each row execute function public.audit_project_record();
drop trigger if exists audit_project_tasks on public.project_tasks;
create trigger audit_project_tasks after insert or update or delete on public.project_tasks for each row execute function public.audit_project_record();
drop trigger if exists audit_project_budget_lines on public.project_budget_lines;
create trigger audit_project_budget_lines after insert or update or delete on public.project_budget_lines for each row execute function public.audit_project_record();
drop trigger if exists audit_project_work_packages on public.work_packages;
create trigger audit_project_work_packages after insert or update or delete on public.work_packages for each row execute function public.audit_project_record();

-- Ajoute les permissions spécifiques au pilotage des projets.
insert into public.permission_catalog(code,label,description,module) values
 ('projects.team.manage','Gérer les membres et responsables des projets','Affecter les membres et responsables aux projets','Projets'),
 ('projects.schedule.manage','Gérer les lots, phases et tâches','Créer et modifier la structure et le planning du projet','Projets'),
 ('projects.progress.report','Déclarer un avancement','Enregistrer les rapports d’avancement du projet','Projets'),
 ('projects.budget.view','Consulter les budgets des projets','Voir les budgets et dépenses','Finance'),
 ('projects.budget.manage','Gérer les budgets des projets','Créer et modifier les lignes budgétaires','Finance')
on conflict (code) do nothing;

insert into public.role_permissions(role,permission_code)
select r.role,p.code from (values ('owner'),('admin'),('project_manager')) r(role)
cross join (values ('projects.team.manage'),('projects.schedule.manage'),('projects.progress.report'),('projects.budget.view'),('projects.budget.manage')) p(code)
on conflict do nothing;
insert into public.role_permissions(role,permission_code)
select r.role,p.code from (values ('engineer'),('site_manager')) r(role)
cross join (values ('projects.schedule.manage'),('projects.progress.report'),('projects.budget.view')) p(code)
on conflict do nothing;
insert into public.role_permissions(role,permission_code) values ('accountant','projects.budget.view'),('accountant','projects.budget.manage') on conflict do nothing;
insert into public.organization_role_permissions(organization_id,role,permission_code,enabled)
select o.id,rp.role,rp.permission_code,true from public.organizations o cross join public.role_permissions rp
where rp.permission_code in ('projects.team.manage','projects.schedule.manage','projects.progress.report','projects.budget.view','projects.budget.manage')
on conflict do nothing;

-- Complète les droits de lecture/écriture sur les membres de projet via permission catalogue.
drop policy if exists project_members_manage on public.project_members;
create policy project_members_manage_by_permission on public.project_members for all to authenticated
using (exists(select 1 from public.projects p where p.id=project_id and public.has_org_permission(p.organization_id,'projects.team.manage')))
with check (exists(select 1 from public.projects p where p.id=project_id and public.has_org_permission(p.organization_id,'projects.team.manage')));

-- Sécurise les mises à jour des projets : affectation responsable et dates restent dans l'organisation.
create or replace function public.validate_project_responsible()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if new.responsible_user_id is not null and not exists(
    select 1 from public.organization_memberships m where m.organization_id=new.organization_id and m.user_id=new.responsible_user_id and m.status='active'
  ) then raise exception 'Le responsable doit être un membre actif de l’organisation'; end if;
  return new;
end $$;
drop trigger if exists validate_project_responsible_trigger on public.projects;
create trigger validate_project_responsible_trigger before insert or update on public.projects for each row execute function public.validate_project_responsible();


-- Les lots suivent les permissions de planning configurées par organisation.
drop policy if exists work_packages_manage on public.work_packages;
create policy work_packages_manage_by_permission on public.work_packages for all to authenticated
using (public.can_manage_project_schedule(project_id)) with check (public.can_manage_project_schedule(project_id));

-- Résumé budgétaire accessible uniquement aux rôles disposant d'un droit financier.
create or replace function public.get_project_budget_summary(p_project uuid)
returns table(estimated_total numeric, actual_total numeric, currency char(3))
language plpgsql stable security definer set search_path=public
as $$
declare v_org uuid; v_currency char(3);
begin
  select organization_id, projects.currency into v_org, v_currency from public.projects where id=p_project;
  if v_org is null then raise exception 'Projet introuvable'; end if;
  if not (public.has_org_permission(v_org,'finance.view') or public.has_org_permission(v_org,'projects.budget.view') or public.has_org_permission(v_org,'finance.manage') or public.has_org_permission(v_org,'projects.budget.manage') or public.has_org_permission(v_org,'projects.manage')) then raise exception 'Accès au budget non autorisé'; end if;
  return query select coalesce(sum(b.estimated_amount),0), coalesce(sum(b.actual_amount),0), v_currency from public.project_budget_lines b where b.project_id=p_project;
end $$;
revoke all on function public.get_project_budget_summary(uuid) from public;
grant execute on function public.get_project_budget_summary(uuid) to authenticated;

create or replace function public.can_view_project_budget(p_project uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.projects p where p.id=p_project and (public.has_org_permission(p.organization_id,'finance.view') or public.has_org_permission(p.organization_id,'projects.budget.view') or public.has_org_permission(p.organization_id,'finance.manage') or public.has_org_permission(p.organization_id,'projects.budget.manage') or public.has_org_permission(p.organization_id,'projects.manage'))) $$;
create or replace function public.can_edit_project_budget(p_project uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select public.can_manage_project_finance(p_project) $$;
revoke all on function public.can_view_project_budget(uuid) from public;
revoke all on function public.can_edit_project_budget(uuid) from public;
grant execute on function public.can_view_project_budget(uuid) to authenticated;
grant execute on function public.can_edit_project_budget(uuid) to authenticated;

-- Les dépendances et les mises à jour budgétaires sont également tracées.
drop trigger if exists audit_project_progress_updates on public.project_progress_updates;
create trigger audit_project_progress_updates after insert or update or delete on public.project_progress_updates for each row execute function public.audit_project_record();

create or replace function public.touch_project_updated_at()
returns trigger language plpgsql set search_path=public
as $$ begin new.updated_at=now(); return new; end $$;
drop trigger if exists touch_projects_updated_at on public.projects;
create trigger touch_projects_updated_at before update on public.projects for each row execute function public.touch_project_updated_at();
drop trigger if exists touch_project_phases_updated_at on public.project_phases;
create trigger touch_project_phases_updated_at before update on public.project_phases for each row execute function public.touch_project_updated_at();
drop trigger if exists touch_project_tasks_updated_at on public.project_tasks;
create trigger touch_project_tasks_updated_at before update on public.project_tasks for each row execute function public.touch_project_updated_at();
drop trigger if exists touch_project_budget_updated_at on public.project_budget_lines;
create trigger touch_project_budget_updated_at before update on public.project_budget_lines for each row execute function public.touch_project_updated_at();

do $$
begin
  if not exists(select 1 from pg_constraint where conname='projects_planned_dates_valid' and conrelid='public.projects'::regclass) then
    alter table public.projects add constraint projects_planned_dates_valid
      check (planned_end is null or planned_start is null or planned_end >= planned_start);
  end if;
end $$;

-- Contrôle d'accès projet : les responsables globaux voient tous les projets de leur organisation;
-- les autres utilisateurs doivent être explicitement membres du projet.
create or replace function public.can_access_project(p_project uuid)
returns boolean language sql stable security definer set search_path=public
as $$
  select exists(
    select 1 from public.projects p
    join public.organization_memberships m on m.organization_id=p.organization_id
    where p.id=p_project and m.user_id=auth.uid() and m.status='active'
      and public.has_org_permission(p.organization_id,'projects.view')
      and (
        public.has_org_permission(p.organization_id,'projects.manage')
        or exists(select 1 from public.project_members pm where pm.project_id=p.id and pm.user_id=auth.uid())
      )
  );
$$;
revoke all on function public.can_access_project(uuid) from public;
grant execute on function public.can_access_project(uuid) to authenticated;

drop policy if exists projects_select_org_members on public.projects;
drop policy if exists projects_select_authorized on public.projects;
create policy projects_select_authorized on public.projects for select to authenticated using (public.can_access_project(id));

-- Ajoute automatiquement le créateur et le responsable au registre des membres du projet.
create or replace function public.sync_project_team_members()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if tg_op='INSERT' then
    insert into public.project_members(project_id,user_id,project_role,is_responsible)
    values(new.id,new.created_by,'Créateur du projet',false)
    on conflict(project_id,user_id) do nothing;
    if new.responsible_user_id is not null then
      insert into public.project_members(project_id,user_id,project_role,is_responsible)
      values(new.id,new.responsible_user_id,'Responsable du projet',true)
      on conflict(project_id,user_id) do update set is_responsible=true, project_role='Responsable du projet';
    end if;
  elsif tg_op='UPDATE' and old.responsible_user_id is distinct from new.responsible_user_id then
    update public.project_members set is_responsible=false where project_id=new.id;
    if new.responsible_user_id is not null then
      insert into public.project_members(project_id,user_id,project_role,is_responsible)
      values(new.id,new.responsible_user_id,'Responsable du projet',true)
      on conflict(project_id,user_id) do update set is_responsible=true, project_role='Responsable du projet';
    end if;
  end if;
  return new;
end $$;
revoke all on function public.sync_project_team_members() from public;
drop trigger if exists sync_project_team_members_trigger on public.projects;
create trigger sync_project_team_members_trigger after insert or update on public.projects
for each row execute function public.sync_project_team_members();

-- Les lignes budgétaires sont visibles uniquement aux utilisateurs ayant accès au projet ET un droit financier.
drop policy if exists project_budget_lines_read on public.project_budget_lines;
create policy project_budget_lines_read on public.project_budget_lines for select to authenticated using (
  public.can_access_project(project_id) and exists(select 1 from public.projects p where p.id=project_id and
    (public.has_org_permission(p.organization_id,'finance.view') or public.has_org_permission(p.organization_id,'projects.budget.view') or public.has_org_permission(p.organization_id,'finance.manage') or public.has_org_permission(p.organization_id,'projects.budget.manage') or public.has_org_permission(p.organization_id,'projects.manage')))
);

-- Rattache les projets historiques à leur créateur et à leur responsable pour conserver l'accès.
insert into public.project_members(project_id,user_id,project_role,is_responsible)
select p.id,p.created_by,'Créateur du projet',false
from public.projects p
join public.organization_memberships m on m.organization_id=p.organization_id and m.user_id=p.created_by and m.status='active'
on conflict(project_id,user_id) do nothing;
insert into public.project_members(project_id,user_id,project_role,is_responsible)
select p.id,p.responsible_user_id,'Responsable du projet',true
from public.projects p
join public.organization_memberships m on m.organization_id=p.organization_id and m.user_id=p.responsible_user_id and m.status='active'
where p.responsible_user_id is not null
on conflict(project_id,user_id) do update set is_responsible=true, project_role='Responsable du projet';
