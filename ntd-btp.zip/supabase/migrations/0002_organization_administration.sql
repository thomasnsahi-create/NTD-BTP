-- BTP MANAGER — Administration des organisations et permissions
-- Migration additive : ne modifie ni ne supprime les données de la migration 0001.

create table if not exists public.permission_catalog (
  code text primary key,
  label text not null,
  description text,
  module text not null,
  is_active boolean not null default true
);

create table if not exists public.role_permissions (
  role text not null check (role in ('owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member')),
  permission_code text not null references public.permission_catalog(code) on delete cascade,
  primary key (role, permission_code)
);

insert into public.permission_catalog(code,label,description,module) values
 ('organization.view','Consulter l’organisation','Voir les informations de l’organisation','Administration'),
 ('organization.update','Modifier l’organisation','Modifier les paramètres généraux','Administration'),
 ('members.view','Consulter les membres','Voir les membres de l’organisation','Administration'),
 ('members.manage','Gérer les membres','Modifier les rôles et statuts des membres','Administration'),
 ('trades.manage','Gérer le catalogue métiers','Ajouter et modifier les métiers','Référentiels'),
 ('projects.view','Consulter les projets','Voir les projets autorisés','Projets'),
 ('projects.manage','Gérer les projets','Créer et modifier les projets','Projets'),
 ('finance.view','Consulter les finances','Accéder aux données financières','Finance'),
 ('finance.manage','Gérer les finances','Modifier les données financières','Finance'),
 ('stock.manage','Gérer les stocks','Gérer les articles et mouvements','Stocks'),
 ('qse.manage','Gérer QHSE','Gérer les contrôles qualité et sécurité','QHSE')
on conflict (code) do nothing;

-- Attribution initiale des permissions par rôle. Les permissions sont modifiables
-- ensuite depuis l'administration (la gestion d'écran sera ajoutée dans l'incrément suivant).
insert into public.role_permissions(role,permission_code)
select 'owner', code from public.permission_catalog
on conflict do nothing;
insert into public.role_permissions(role,permission_code)
select 'admin', code from public.permission_catalog where code <> 'organization.update'
on conflict do nothing;
insert into public.role_permissions(role,permission_code) values
 ('project_manager','organization.view'),('project_manager','members.view'),('project_manager','projects.view'),('project_manager','projects.manage'),('project_manager','trades.manage'),
 ('engineer','organization.view'),('engineer','projects.view'),('engineer','trades.manage'),
 ('site_manager','organization.view'),('site_manager','projects.view'),('site_manager','stock.manage'),('site_manager','qse.manage'),
 ('accountant','organization.view'),('accountant','projects.view'),('accountant','finance.view'),('accountant','finance.manage'),
 ('storekeeper','organization.view'),('storekeeper','projects.view'),('storekeeper','stock.manage'),
 ('qse_manager','organization.view'),('qse_manager','projects.view'),('qse_manager','qse.manage'),
 ('client','organization.view'),('client','projects.view'),
 ('subcontractor','organization.view'),('subcontractor','projects.view'),
 ('member','organization.view'),('member','projects.view')
on conflict do nothing;

alter table public.permission_catalog enable row level security;
alter table public.role_permissions enable row level security;
create policy "permission_catalog_read" on public.permission_catalog
for select to authenticated using (is_active = true);
create policy "role_permissions_read" on public.role_permissions
for select to authenticated using (true);

-- Permet de créer l'organisation et son propriétaire dans une seule transaction.
create or replace function public.create_organization(
  p_name text,
  p_legal_name text default null,
  p_country_code text default 'CM',
  p_default_currency text default 'XAF'
) returns uuid
language plpgsql security definer
set search_path = public
as $$
declare v_org_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentification requise'; end if;
  if nullif(trim(p_name),'') is null then raise exception 'Le nom de l’organisation est obligatoire'; end if;
  insert into public.organizations(name,legal_name,country_code,default_currency)
  values(trim(p_name),nullif(trim(p_legal_name),''),upper(p_country_code),upper(p_default_currency))
  returning id into v_org_id;
  insert into public.organization_memberships(organization_id,user_id,role,status)
  values(v_org_id,auth.uid(),'owner','active');
  return v_org_id;
end;
$$;
revoke all on function public.create_organization(text,text,text,text) from public;
grant execute on function public.create_organization(text,text,text,text) to authenticated;

-- Le propriétaire peut gérer les administrateurs. Un administrateur ne peut pas
-- promouvoir un autre propriétaire, se promouvoir propriétaire ou modifier un owner.
create or replace function public.set_organization_member(
  p_membership_id uuid,
  p_role text,
  p_status public.membership_status
) returns void
language plpgsql security definer
set search_path = public
as $$
declare v_org uuid; v_old_role text;
begin
  if p_role not in ('owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member') then
    raise exception 'Rôle invalide';
  end if;
  select organization_id, role into v_org, v_old_role
  from public.organization_memberships where id = p_membership_id;
  if v_org is null then raise exception 'Membre introuvable'; end if;
  if not public.has_org_permission(v_org,'members.manage') then raise exception 'Droits insuffisants'; end if;
  if v_old_role = 'owner' and not public.has_org_role(v_org,array['owner']) then raise exception 'Seul le propriétaire peut modifier un propriétaire'; end if;
  if p_role = 'owner' and not public.has_org_role(v_org,array['owner']) then raise exception 'Seul le propriétaire peut attribuer ce rôle'; end if;
  update public.organization_memberships set role=p_role,status=p_status where id=p_membership_id;
end;
$$;
revoke all on function public.set_organization_member(uuid,text,public.membership_status) from public;
grant execute on function public.set_organization_member(uuid,text,public.membership_status) to authenticated;

-- Afficher le nom des collègues uniquement lorsqu'un lien d'organisation existe.
create or replace function public.is_org_colleague(p_user uuid)
returns boolean language sql stable security definer set search_path=public
as $$
 select exists (
   select 1 from public.organization_memberships mine
   join public.organization_memberships theirs on theirs.organization_id=mine.organization_id
   where mine.user_id=auth.uid() and mine.status='active'
     and theirs.user_id=p_user and theirs.status='active'
 );
$$;
create policy "profiles_select_org_colleagues" on public.profiles
for select to authenticated using (public.is_org_colleague(id));

-- Autorisations d'administration des organisations : les rôles sont contrôlés
-- côté base, et non uniquement par l'interface Flutter.

create or replace function public.set_role_permission(p_role text,p_permission_code text,p_enabled boolean)
returns void language plpgsql security definer set search_path=public
as $$
declare v_org uuid;
begin
  if p_role not in ('owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member') then raise exception 'Rôle invalide'; end if;
  if not exists(select 1 from public.permission_catalog where code=p_permission_code and is_active=true) then raise exception 'Permission inconnue'; end if;
  if p_role in ('owner','admin') and not exists(select 1 from public.organization_memberships where user_id=auth.uid() and role='owner' and status='active') then
    raise exception 'Seul un propriétaire peut modifier les permissions owner/admin';
  end if;
  if not exists(select 1 from public.organization_memberships where user_id=auth.uid() and role in ('owner','admin') and status='active') then raise exception 'Droits insuffisants'; end if;
  if p_enabled then
    insert into public.role_permissions(role,permission_code) values(p_role,p_permission_code) on conflict do nothing;
  else
    delete from public.role_permissions where role=p_role and permission_code=p_permission_code;
  end if;
end;
$$;
revoke all on function public.set_role_permission(text,text,boolean) from public;
grant execute on function public.set_role_permission(text,text,boolean) to authenticated;

-- Les personnalisations sont propres à chaque organisation (pas de fuite entre clients).
create table if not exists public.organization_role_permissions (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  role text not null check (role in ('owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member')),
  permission_code text not null references public.permission_catalog(code) on delete cascade,
  enabled boolean not null default true,
  primary key (organization_id,role,permission_code)
);
alter table public.organization_role_permissions enable row level security;
create policy "org_role_permissions_read_members" on public.organization_role_permissions
for select to authenticated using (public.is_org_member(organization_id));

-- Remplace la fonction de création pour initialiser les droits locaux depuis les modèles.
create or replace function public.create_organization(
  p_name text, p_legal_name text default null,
  p_country_code text default 'CM', p_default_currency text default 'XAF'
) returns uuid language plpgsql security definer set search_path=public
as $$
declare v_org_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentification requise'; end if;
  if nullif(trim(p_name),'') is null then raise exception 'Le nom de l’organisation est obligatoire'; end if;
  insert into public.organizations(name,legal_name,country_code,default_currency)
  values(trim(p_name),nullif(trim(p_legal_name),''),upper(p_country_code),upper(p_default_currency)) returning id into v_org_id;
  insert into public.organization_memberships(organization_id,user_id,role,status) values(v_org_id,auth.uid(),'owner','active');
  insert into public.organization_role_permissions(organization_id,role,permission_code,enabled)
    select v_org_id,role,permission_code,true from public.role_permissions;
  return v_org_id;
end;
$$;

-- Supprime l'ancienne fonction globale, qui n'était pas adaptée à un modèle multi-organisation.
drop function if exists public.set_role_permission(text,text,boolean);
create or replace function public.set_role_permission(
  p_organization_id uuid,p_role text,p_permission_code text,p_enabled boolean
) returns void language plpgsql security definer set search_path=public
as $$
begin
  if p_role not in ('owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member') then raise exception 'Rôle invalide'; end if;
  if not public.has_org_role(p_organization_id,array['owner','admin']) then raise exception 'Droits insuffisants pour cette organisation'; end if;
  if p_role in ('owner','admin') and not public.has_org_role(p_organization_id,array['owner']) then raise exception 'Seul le propriétaire peut modifier les droits owner/admin'; end if;
  if not exists(select 1 from public.permission_catalog where code=p_permission_code and is_active=true) then raise exception 'Permission inconnue'; end if;
  insert into public.organization_role_permissions(organization_id,role,permission_code,enabled)
  values(p_organization_id,p_role,p_permission_code,p_enabled)
  on conflict (organization_id,role,permission_code) do update set enabled=excluded.enabled;
end;
$$;
revoke all on function public.set_role_permission(uuid,text,text,boolean) from public;
grant execute on function public.set_role_permission(uuid,text,text,boolean) to authenticated;

insert into public.organization_role_permissions(organization_id,role,permission_code,enabled)
select o.id,rp.role,rp.permission_code,true
from public.organizations o cross join public.role_permissions rp
on conflict do nothing;

-- Fonction centrale utilisée par les politiques RLS pour appliquer les droits personnalisés.
create or replace function public.has_org_permission(p_org uuid,p_permission text)
returns boolean language sql stable security definer set search_path=public
as $$
  select exists (
    select 1 from public.organization_memberships m
    join public.organization_role_permissions rp on rp.organization_id=m.organization_id and rp.role=m.role
    where m.organization_id=p_org and m.user_id=auth.uid() and m.status='active'
      and rp.permission_code=p_permission and rp.enabled=true
  );
$$;

-- Les permissions personnalisées pilotent désormais les opérations principales.
drop policy if exists "org_update_admins" on public.organizations;
create policy "org_update_by_permission" on public.organizations
for update to authenticated using (public.has_org_permission(id,'organization.update'))
with check (public.has_org_permission(id,'organization.update'));

drop policy if exists "memberships_insert_admins" on public.organization_memberships;
create policy "memberships_insert_by_permission" on public.organization_memberships
for insert to authenticated with check (public.has_org_permission(organization_id,'members.manage'));
drop policy if exists "memberships_update_admins" on public.organization_memberships;
create policy "memberships_update_by_permission" on public.organization_memberships
for update to authenticated using (public.has_org_permission(organization_id,'members.manage'))
with check (public.has_org_permission(organization_id,'members.manage'));

drop policy if exists "projects_insert_org_managers" on public.projects;
create policy "projects_insert_by_permission" on public.projects
for insert to authenticated with check (public.has_org_permission(organization_id,'projects.manage') and created_by=auth.uid());
drop policy if exists "projects_update_org_managers" on public.projects;
create policy "projects_update_by_permission" on public.projects
for update to authenticated using (public.has_org_permission(organization_id,'projects.manage'))
with check (public.has_org_permission(organization_id,'projects.manage'));

-- Garde-fou : un administrateur ne peut pas créer, promouvoir ou modifier un propriétaire.
create or replace function public.guard_membership_owner_role()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if tg_op='INSERT' then
    if new.role='owner' and not public.has_org_role(new.organization_id,array['owner'])
       and not (new.user_id=auth.uid() and not exists(select 1 from public.organization_memberships where organization_id=new.organization_id)) then
      raise exception 'Seul le propriétaire peut attribuer le rôle owner';
    end if;
  elsif tg_op='UPDATE' then
    if old.role='owner' and not public.has_org_role(old.organization_id,array['owner']) then
      raise exception 'Seul le propriétaire peut modifier le compte owner';
    end if;
    if new.role='owner' and not public.has_org_role(new.organization_id,array['owner']) then
      raise exception 'Seul le propriétaire peut attribuer le rôle owner';
    end if;
  end if;
  return new;
end;
$$;
drop trigger if exists protect_owner_membership on public.organization_memberships;
create trigger protect_owner_membership before insert or update on public.organization_memberships
for each row execute function public.guard_membership_owner_role();

-- Un propriétaire ne peut pas se retirer ni se suspendre s'il est le dernier propriétaire actif.
create or replace function public.guard_membership_owner_role()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if tg_op='INSERT' then
    if new.role='owner' and not public.has_org_role(new.organization_id,array['owner'])
       and not (new.user_id=auth.uid() and not exists(select 1 from public.organization_memberships where organization_id=new.organization_id)) then
      raise exception 'Seul le propriétaire peut attribuer le rôle owner';
    end if;
  elsif tg_op='UPDATE' then
    if old.role='owner' and not public.has_org_role(old.organization_id,array['owner']) then
      raise exception 'Seul le propriétaire peut modifier le compte owner';
    end if;
    if new.role='owner' and not public.has_org_role(new.organization_id,array['owner']) then
      raise exception 'Seul le propriétaire peut attribuer le rôle owner';
    end if;
    if old.role='owner' and (new.role <> 'owner' or new.status <> 'active')
       and not exists(select 1 from public.organization_memberships m where m.organization_id=old.organization_id and m.id<>old.id and m.role='owner' and m.status='active') then
      raise exception 'Transférez la propriété avant de retirer ou suspendre le dernier propriétaire';
    end if;
  end if;
  return new;
end;
$$;
