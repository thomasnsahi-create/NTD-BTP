-- V7 : calendriers de travail, jours fériés, équipes, engins et réservation des ressources.
-- Migration additive, aucune donnée existante n'est supprimée.

create table if not exists public.project_work_calendars (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null unique references public.projects(id) on delete cascade,
  name text not null default 'Calendrier chantier',
  working_days smallint[] not null default array[1,2,3,4,5,6]::smallint[],
  hours_per_day numeric(4,2) not null default 8 check (hours_per_day > 0 and hours_per_day <= 24),
  start_time time not null default '08:00',
  end_time time not null default '17:00',
  exclude_public_holidays boolean not null default true,
  country_code char(2) not null default 'CM',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (cardinality(working_days) > 0),
  check (working_days <@ array[1,2,3,4,5,6,7]::smallint[]),
  check (end_time > start_time)
);

alter table public.projects add column if not exists work_calendar_id uuid references public.project_work_calendars(id) on delete set null;

create table if not exists public.project_calendar_holidays (
  id uuid primary key default gen_random_uuid(),
  calendar_id uuid not null references public.project_work_calendars(id) on delete cascade,
  holiday_date date not null,
  name text not null,
  holiday_type text not null default 'public' check (holiday_type in ('public','regional','company','exceptional')),
  is_working_day_override boolean not null default false,
  created_at timestamptz not null default now(),
  unique(calendar_id, holiday_date)
);

create table if not exists public.project_resources (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  resource_type text not null check (resource_type in ('team','equipment')),
  name text not null,
  description text,
  capacity numeric(10,2) not null default 1 check (capacity > 0),
  capacity_unit text not null default 'unité',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(project_id, name, resource_type)
);

create table if not exists public.project_resource_unavailability (
  id uuid primary key default gen_random_uuid(),
  resource_id uuid not null references public.project_resources(id) on delete cascade,
  unavailable_start date not null,
  unavailable_end date not null,
  reason text not null,
  unavailability_type text not null default 'maintenance' check (unavailability_type in ('maintenance','repair','leave','other')),
  created_at timestamptz not null default now(),
  check (unavailable_end >= unavailable_start)
);

create table if not exists public.project_task_resource_allocations (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  task_id uuid not null references public.project_tasks(id) on delete cascade,
  resource_id uuid not null references public.project_resources(id) on delete cascade,
  allocated_capacity numeric(10,2) not null default 1 check (allocated_capacity > 0),
  allocation_start date not null,
  allocation_end date not null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (allocation_end >= allocation_start),
  unique(task_id, resource_id)
);

create index if not exists idx_resource_allocations_resource_dates on public.project_task_resource_allocations(resource_id, allocation_start, allocation_end);
create index if not exists idx_resource_allocations_project on public.project_task_resource_allocations(project_id, task_id);
create index if not exists idx_resource_unavailability_dates on public.project_resource_unavailability(resource_id, unavailable_start, unavailable_end);

create or replace function public.validate_project_resource_allocation()
returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare v_capacity numeric; v_project uuid; v_used numeric;
begin
  select capacity, project_id into v_capacity, v_project from public.project_resources where id=new.resource_id and is_active for update;
  if v_capacity is null then raise exception 'Ressource inexistante ou inactive'; end if;
  if v_project <> new.project_id then raise exception 'La ressource et la tâche doivent appartenir au même projet'; end if;
  if not exists(select 1 from public.project_tasks where id=new.task_id and project_id=new.project_id) then raise exception 'La tâche ne correspond pas au projet'; end if;
  if exists(select 1 from public.project_resource_unavailability u where u.resource_id=new.resource_id and daterange(u.unavailable_start,u.unavailable_end,'[]') && daterange(new.allocation_start,new.allocation_end,'[]')) then
    raise exception 'La ressource est indisponible sur une partie de cette période';
  end if;
  select coalesce(sum(a.allocated_capacity),0) into v_used
  from public.project_task_resource_allocations a
  where a.resource_id=new.resource_id and a.id <> coalesce(new.id,'00000000-0000-0000-0000-000000000000'::uuid)
    and daterange(a.allocation_start,a.allocation_end,'[]') && daterange(new.allocation_start,new.allocation_end,'[]');
  if v_used + new.allocated_capacity > v_capacity then
    raise exception 'Capacité dépassée : % déjà réservé(s), capacité disponible %', v_used, v_capacity;
  end if;
  return new;
end; $$;
drop trigger if exists validate_project_resource_allocation_trigger on public.project_task_resource_allocations;
create trigger validate_project_resource_allocation_trigger before insert or update on public.project_task_resource_allocations for each row execute function public.validate_project_resource_allocation();

create or replace function public.validate_resource_unavailability()
returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  if exists(select 1 from public.project_task_resource_allocations a where a.resource_id=new.resource_id and daterange(a.allocation_start,a.allocation_end,'[]') && daterange(new.unavailable_start,new.unavailable_end,'[]')) then
    raise exception 'Une affectation existe déjà pendant cette indisponibilité. Reprogrammez-la avant d''enregistrer.';
  end if;
  return new;
end; $$;
drop trigger if exists validate_resource_unavailability_trigger on public.project_resource_unavailability;
create trigger validate_resource_unavailability_trigger before insert or update on public.project_resource_unavailability for each row execute function public.validate_resource_unavailability();

alter table public.project_work_calendars enable row level security;
alter table public.project_calendar_holidays enable row level security;
alter table public.project_resources enable row level security;
alter table public.project_resource_unavailability enable row level security;
alter table public.project_task_resource_allocations enable row level security;

drop policy if exists project_work_calendars_access on public.project_work_calendars;
create policy project_work_calendars_access on public.project_work_calendars for all to authenticated
using (public.can_access_project(project_id)) with check (public.can_manage_project_schedule(project_id));
drop policy if exists project_calendar_holidays_access on public.project_calendar_holidays;
create policy project_calendar_holidays_access on public.project_calendar_holidays for all to authenticated
using (exists(select 1 from public.project_work_calendars c where c.id=calendar_id and public.can_access_project(c.project_id)))
with check (exists(select 1 from public.project_work_calendars c where c.id=calendar_id and public.can_manage_project_schedule(c.project_id)));
drop policy if exists project_resources_access on public.project_resources;
create policy project_resources_access on public.project_resources for all to authenticated
using (public.can_access_project(project_id)) with check (public.can_manage_project_schedule(project_id));
drop policy if exists project_resource_unavailability_access on public.project_resource_unavailability;
create policy project_resource_unavailability_access on public.project_resource_unavailability for all to authenticated
using (exists(select 1 from public.project_resources r where r.id=resource_id and public.can_access_project(r.project_id)))
with check (exists(select 1 from public.project_resources r where r.id=resource_id and public.can_manage_project_schedule(r.project_id)));
drop policy if exists project_task_resource_allocations_access on public.project_task_resource_allocations;
create policy project_task_resource_allocations_access on public.project_task_resource_allocations for all to authenticated
using (public.can_access_project(project_id)) with check (public.can_manage_project_schedule(project_id));

-- Crée un calendrier standard camerounais (lundi-samedi, 8 h/jour) pour chaque projet existant.
insert into public.project_work_calendars(project_id,name,country_code)
select p.id, 'Calendrier chantier', coalesce(p.country_code,'CM') from public.projects p
on conflict(project_id) do nothing;
update public.projects p set work_calendar_id=c.id from public.project_work_calendars c where c.project_id=p.id and p.work_calendar_id is null;

comment on table public.project_work_calendars is 'Calendrier du chantier : jours ouvrés ISO (1=lundi...7=dimanche), durée journalière et jours fériés.';
comment on table public.project_resources is 'Équipes et engins disponibles pour un projet. Pour une équipe, capacity peut représenter le nombre de personnes.';
comment on table public.project_task_resource_allocations is 'Réservation d''une capacité de ressource sur une tâche et une période; les conflits de capacité sont refusés.';

-- Remplace la RPC V6 : mise à jour atomique des dates des tâches ET de leurs réservations.
create or replace function public.apply_project_schedule_proposal(
  p_project uuid, p_updates jsonb, p_forecast_end date, p_delay_days integer
) returns integer language plpgsql security definer set search_path=public,pg_temp as $$
declare v_expected integer; v_updated integer;
begin
  if auth.uid() is null then raise exception 'Authentification requise'; end if;
  if not public.can_manage_project_schedule(p_project) then raise exception 'Permission de gestion du planning requise'; end if;
  if p_updates is null or jsonb_typeof(p_updates)<>'array' then raise exception 'La proposition de planning doit être une liste'; end if;
  v_expected:=jsonb_array_length(p_updates);
  if exists(select 1 from jsonb_to_recordset(p_updates) as x(task_id uuid,planned_start date,planned_end date) where task_id is null or planned_start is null or planned_end is null or planned_end<planned_start) then raise exception 'Dates de tâche invalides'; end if;
  if exists(select 1 from jsonb_to_recordset(p_updates) as x(task_id uuid,planned_start date,planned_end date) group by task_id having count(*)>1) then raise exception 'Une tâche apparaît plusieurs fois'; end if;
  if exists(select 1 from jsonb_to_recordset(p_updates) as x(task_id uuid,planned_start date,planned_end date) left join public.project_tasks t on t.id=x.task_id and t.project_id=p_project where t.id is null) then raise exception 'La proposition contient une tâche extérieure au projet'; end if;
  update public.project_tasks t set planned_start=x.planned_start,planned_end=x.planned_end,updated_at=now()
  from jsonb_to_recordset(p_updates) as x(task_id uuid,planned_start date,planned_end date) where t.id=x.task_id and t.project_id=p_project;
  get diagnostics v_updated=row_count;
  if v_updated<>v_expected then raise exception 'Toutes les dates proposées n''ont pas été appliquées'; end if;
  update public.project_task_resource_allocations a set allocation_start=t.planned_start,allocation_end=t.planned_end,updated_at=now()
  from public.project_tasks t, jsonb_to_recordset(p_updates) as x(task_id uuid,planned_start date,planned_end date)
  where a.task_id=t.id and t.id=x.task_id and a.project_id=p_project;
  update public.projects set forecast_end=p_forecast_end,forecast_delay_days=coalesce(p_delay_days,0),forecast_calculated_at=now(),updated_at=now() where id=p_project;
  return v_updated;
end; $$;
revoke all on function public.apply_project_schedule_proposal(uuid,jsonb,date,integer) from public;
grant execute on function public.apply_project_schedule_proposal(uuid,jsonb,date,integer) to authenticated;

-- Calendrier par défaut pour les nouveaux projets : lundi à samedi, 8 h/jour.
create or replace function public.create_default_project_work_calendar()
returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare v_calendar uuid;
begin
  insert into public.project_work_calendars(project_id,name,country_code)
  values(new.id,'Calendrier chantier',coalesce(new.country_code,'CM'))
  on conflict(project_id) do update set country_code=excluded.country_code
  returning id into v_calendar;
  update public.projects set work_calendar_id=v_calendar where id=new.id and work_calendar_id is null;
  return new;
end; $$;
drop trigger if exists create_default_project_work_calendar_trigger on public.projects;
create trigger create_default_project_work_calendar_trigger after insert on public.projects for each row execute function public.create_default_project_work_calendar();
