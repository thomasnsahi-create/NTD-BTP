-- =====================================================================
-- V11 — Module électrique, étape E19 : besoins électriques par pièce.
--   Règles de besoins CONFIGURABLES (par destination du bâtiment, type de pièce, surface),
--   besoins retenus par pièce avec traçabilité (minimum réglementaire, justification, validation).
-- Les règles par défaut ne concernent que les logements et sont à confirmer pour le projet :
-- aucune règle d'un logement n'est appliquée à un autre type de bâtiment.
-- Migration NON destructive.
-- =====================================================================

create table public.elec_project_settings (
  project_id uuid primary key references public.projects(id) on delete cascade,
  building_usage text check (building_usage is null or building_usage in
    ('dwelling','office','commercial','industrial','public_assembly','other')),
  regulatory_reference text,
  updated_by uuid default auth.uid() references auth.users(id),
  updated_at timestamptz not null default now()
);
create trigger elec_project_settings_touch before update on public.elec_project_settings
  for each row execute function public.touch_updated_at();

create table public.elec_requirement_rules (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade, -- null = règles par défaut
  building_usage text not null check (building_usage in
    ('dwelling','office','commercial','industrial','public_assembly','other')),
  room_type_code text not null,
  equipment_type_code text not null,
  kind text not null default 'regulatory' check (kind in ('regulatory','design')),
  per_area_m2 numeric(8,2) check (per_area_m2 is null or per_area_m2 > 0),  -- 1 équipement par tranche de N m²
  min_count integer not null default 0 check (min_count >= 0),
  max_count integer check (max_count is null or max_count >= min_count),
  area_min_m2 numeric(8,2),   -- la règle s'applique si surface > area_min_m2 (exclu)
  area_max_m2 numeric(8,2),   -- ... et surface <= area_max_m2 (inclus)
  reference_text text,
  is_confirmed boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  check (area_min_m2 is null or area_max_m2 is null or area_max_m2 > area_min_m2)
);
create index idx_elec_requirement_rules_lookup
  on public.elec_requirement_rules (building_usage, upper(room_type_code));

insert into public.elec_requirement_rules
  (building_usage, room_type_code, equipment_type_code, kind, per_area_m2, min_count, area_min_m2, area_max_m2, reference_text, is_confirmed)
select 'dwelling', r.room, r.eq, r.kind, r.per_area, r.min_count, r.amin, r.amax, r.ref, false
from (values
  ('SEJOUR','PC','regulatory',4::numeric,5,null::numeric,null::numeric,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SEJOUR','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SEJOUR','COM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SALON','PC','regulatory',4,5,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SALON','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SALON','COM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('CHAMBRE','PC','regulatory',null,3,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('CHAMBRE','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('CHAMBRE','COM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('CUISINE','PC','regulatory',null,3,null,4,'NF C 15-100 — cuisine de 4 m² ou moins ; à confirmer'),
  ('CUISINE','PC','regulatory',null,6,4,null,'NF C 15-100 — cuisine de plus de 4 m² ; à confirmer'),
  ('CUISINE','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SDB','PC','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SDB','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('DOUCHE','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('WC','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('COULOIR','PC','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('COULOIR','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('HALL','PC','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('HALL','LUM','regulatory',null,1,null,null,'NF C 15-100 — valeurs usuelles, à confirmer'),
  ('SEJOUR','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)'),
  ('SALON','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)'),
  ('CHAMBRE','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)'),
  ('CUISINE','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)'),
  ('SDB','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)'),
  ('WC','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)'),
  ('COULOIR','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)'),
  ('HALL','INT','design',null,1,null,null,'Proposition de conception (non réglementaire)')
) as r(room, eq, kind, per_area, min_count, amin, amax, ref);

create table public.elec_room_needs (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  room_id uuid not null references public.elec_rooms(id) on delete cascade,
  equipment_type_id uuid not null references public.elec_equipment_types(id),
  quantity integer not null check (quantity >= 0),            -- quantité retenue
  proposed_quantity integer check (proposed_quantity is null or proposed_quantity >= 0),
  regulatory_min integer check (regulatory_min is null or regulatory_min >= 0),  -- minimum calculé au moment de la proposition
  rule_references text,
  justification text,
  status text not null default 'proposed' check (status in ('proposed','validated')),
  validated_by uuid references auth.users(id),
  validated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (room_id, equipment_type_id),
  -- Sous le minimum réglementaire, la validation exige une justification écrite.
  check (status <> 'validated' or quantity >= coalesce(regulatory_min, 0) or length(trim(coalesce(justification, ''))) > 0)
);
create index idx_elec_room_needs_project on public.elec_room_needs(project_id);
create trigger elec_room_needs_touch before update on public.elec_room_needs
  for each row execute function public.touch_updated_at();

create or replace function public.elec_room_needs_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_project uuid;
begin
  select project_id into v_project from public.elec_rooms where id = new.room_id;
  if v_project is null then raise exception 'Pièce introuvable'; end if;
  if v_project <> new.project_id then raise exception 'La pièce n''appartient pas à ce projet'; end if;
  if new.status = 'validated' then
    if tg_op = 'INSERT' or old.status is distinct from 'validated' then
      new.validated_by := auth.uid();
      new.validated_at := now();
    end if;
  else
    new.validated_by := null;
    new.validated_at := null;
  end if;
  return new;
end $$;
create trigger elec_room_needs_guard_trigger before insert or update on public.elec_room_needs
  for each row execute function public.elec_room_needs_guard();

-- ---------------------------------------------------------------- Sécurité
alter table public.elec_project_settings enable row level security;
alter table public.elec_requirement_rules enable row level security;
alter table public.elec_room_needs enable row level security;

create policy elec_project_settings_read on public.elec_project_settings for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_project_settings_write on public.elec_project_settings for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));

create policy elec_requirement_rules_read on public.elec_requirement_rules for select to authenticated
  using (organization_id is null or public.is_org_member(organization_id));
create policy elec_requirement_rules_write on public.elec_requirement_rules for all to authenticated
  using (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'))
  with check (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'));

create policy elec_room_needs_read on public.elec_room_needs for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_room_needs_write on public.elec_room_needs for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));
