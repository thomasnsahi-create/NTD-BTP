-- =====================================================================
-- V12 — Module électrique, étape E20 : bilan de puissance.
--   Coefficients d'utilisation (Ku) et de simultanéité (Ks) CONFIGURABLES par catégorie
--   d'équipement et par destination du bâtiment ; facteur de puissance par équipement ;
--   coefficient général et marge de réserve par projet ; bilans enregistrés (traçabilité).
-- Les coefficients par défaut sont des valeurs usuelles à confirmer pour le projet.
-- Migration NON destructive.
-- =====================================================================

alter table public.elec_equipment
  add column power_factor numeric(4,3) check (power_factor is null or (power_factor > 0 and power_factor <= 1));

alter table public.elec_project_settings
  add column overall_simultaneity numeric(4,3) not null default 1 check (overall_simultaneity > 0 and overall_simultaneity <= 1),
  add column reserve_factor numeric(4,3) not null default 1 check (reserve_factor >= 1 and reserve_factor <= 5);

-- Ks = ks_base + ks_per_n / n (n = nombre d'équipements de la catégorie avec puissance), borné à [0 ; 1].
-- Coefficient fixe : ks_per_n = 0. Exemple prises : 0,1 + 0,9 / n.
create table public.elec_diversity_rules (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade,  -- null = valeurs par défaut
  building_usage text check (building_usage is null or building_usage in
    ('dwelling','office','commercial','industrial','public_assembly','other')),  -- null = toutes destinations
  category text not null check (category in
    ('lighting','switch','socket','junction_box','panel','hvac','specialized','detector','security','communication')),
  ku numeric(4,3) not null default 1 check (ku > 0 and ku <= 1),
  ks_base numeric(5,3) not null default 1 check (ks_base >= 0 and ks_base <= 1),
  ks_per_n numeric(6,3) not null default 0 check (ks_per_n >= 0),
  reference_text text,
  is_confirmed boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index uq_elec_diversity_rules on public.elec_diversity_rules
  (coalesce(organization_id, '00000000-0000-0000-0000-000000000000'::uuid), coalesce(building_usage, 'any'), category);

insert into public.elec_diversity_rules (category, ku, ks_base, ks_per_n, reference_text) values
 ('lighting',1,1,0,'Éclairage : pas de diversité (valeur usuelle, à confirmer)'),
 ('socket',1,0.1,0.9,'Prises de courant : Ks = 0,1 + 0,9 / n (valeur usuelle, à confirmer)'),
 ('hvac',1,1,0,'Climatisation : pas de diversité (valeur usuelle, à confirmer)'),
 ('specialized',1,1,0,'Équipements spécialisés : pas de diversité (valeur prudente, à confirmer)');

create table public.elec_power_balances (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  building_usage text,
  overall_simultaneity numeric(4,3) not null,
  reserve_factor numeric(4,3) not null,
  installed_w numeric(14,2) not null,
  demand_w numeric(14,2) not null,
  apparent_demand_va numeric(14,2),           -- null si un facteur de puissance manque
  equipment_count integer not null,
  equipment_without_power integer not null default 0,
  details jsonb not null,                     -- catégories, coefficients et références utilisés
  note text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now()
);
create index idx_elec_power_balances_project on public.elec_power_balances(project_id, created_at desc);

alter table public.elec_diversity_rules enable row level security;
alter table public.elec_power_balances enable row level security;

create policy elec_diversity_rules_read on public.elec_diversity_rules for select to authenticated
  using (organization_id is null or public.is_org_member(organization_id));
create policy elec_diversity_rules_write on public.elec_diversity_rules for all to authenticated
  using (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'))
  with check (organization_id is not null and public.has_org_permission(organization_id, 'projects.manage'));

create policy elec_power_balances_read on public.elec_power_balances for select to authenticated
  using (public.can_access_project(project_id));
create policy elec_power_balances_write on public.elec_power_balances for all to authenticated
  using (public.can_manage_project_electrical(project_id)) with check (public.can_manage_project_electrical(project_id));
