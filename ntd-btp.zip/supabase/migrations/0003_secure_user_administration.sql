-- BTP MANAGER — V3 : invitations, profils, suspension et audit
-- Migration additive. Ne supprime aucune table ni aucune donnée existante.

alter table public.profiles
  add column if not exists first_name text,
  add column if not exists last_name text,
  add column if not exists job_title text,
  add column if not exists avatar_url text;

-- Invitation en attente. Cette table n'est accessible qu'aux fonctions serveur
-- (service_role) et aux fonctions SECURITY DEFINER ci-dessous.
create table if not exists public.organization_invitations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  email text not null,
  role text not null check (role in ('admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member')),
  invited_by uuid not null references auth.users(id),
  expires_at timestamptz not null default (now() + interval '7 days'),
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  unique (organization_id, email)
);
create index if not exists idx_org_invitations_pending
  on public.organization_invitations(organization_id, expires_at)
  where accepted_at is null;
alter table public.organization_invitations enable row level security;
-- Aucune policy client : lecture/écriture uniquement par fonctions serveur.

-- Ajouter le droit de consulter le journal aux rôles de direction.
insert into public.permission_catalog(code,label,description,module) values
 ('audit.view','Consulter le journal d’activité','Consulter les opérations administratives tracées','Administration')
on conflict (code) do nothing;
insert into public.role_permissions(role,permission_code)
values ('owner','audit.view'),('admin','audit.view') on conflict do nothing;
insert into public.organization_role_permissions(organization_id,role,permission_code,enabled)
select o.id, r.role, 'audit.view', true
from public.organizations o
cross join (values ('owner'),('admin')) as r(role)
on conflict do nothing;

-- Lecture du journal réservée aux utilisateurs disposant du droit dédié.
drop policy if exists audit_select_admins on public.audit_logs;
drop policy if exists audit_select_by_permission on public.audit_logs;
create policy audit_select_by_permission on public.audit_logs
for select to authenticated
using (organization_id is not null and public.has_org_permission(organization_id,'audit.view'));

-- Mise à jour du profil : uniquement son propre profil. Les champs exposés
-- sont des informations professionnelles non sensibles.
create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path=public
as $$ begin new.updated_at = now(); return new; end; $$;
drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles
for each row execute function public.touch_updated_at();

-- Journalisation serveur : les clients ne peuvent pas écrire directement dans audit_logs.
create or replace function public.audit_membership_change()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_org uuid; v_actor uuid; v_action text; v_record text; v_details jsonb;
begin
  v_actor := auth.uid();
  if tg_op = 'INSERT' then
    v_org := new.organization_id; v_action := 'member.added'; v_record := new.id::text;
    v_details := jsonb_build_object('user_id',new.user_id,'role',new.role,'status',new.status);
  elsif tg_op = 'UPDATE' then
    v_org := new.organization_id; v_action := 'member.updated'; v_record := new.id::text;
    v_details := jsonb_build_object('user_id',new.user_id,'old_role',old.role,'new_role',new.role,'old_status',old.status,'new_status',new.status);
  else
    v_org := old.organization_id; v_action := 'member.removed'; v_record := old.id::text;
    v_details := jsonb_build_object('user_id',old.user_id,'role',old.role,'status',old.status);
  end if;
  insert into public.audit_logs(organization_id,actor_user_id,action,table_name,record_id,details)
  values(v_org,v_actor,v_action,'organization_memberships',v_record,v_details);
  if tg_op = 'DELETE' then return old; else return new; end if;
end; $$;
drop trigger if exists audit_membership_changes on public.organization_memberships;
create trigger audit_membership_changes
after insert or update or delete on public.organization_memberships
for each row execute function public.audit_membership_change();

create or replace function public.audit_profile_change()
returns trigger language plpgsql security definer set search_path=public
as $$
declare m record;
begin
  if (old.full_name,old.phone,old.first_name,old.last_name,old.job_title,old.avatar_url)
     is distinct from
     (new.full_name,new.phone,new.first_name,new.last_name,new.job_title,new.avatar_url) then
    for m in select organization_id from public.organization_memberships
             where user_id=new.id and status='active'
    loop
      insert into public.audit_logs(organization_id,actor_user_id,action,table_name,record_id,details)
      values(m.organization_id,auth.uid(),'profile.updated','profiles',new.id::text,
        jsonb_build_object('changed_fields',jsonb_build_array('profile')));
    end loop;
  end if;
  return new;
end; $$;
drop trigger if exists audit_profile_changes on public.profiles;
create trigger audit_profile_changes after update on public.profiles
for each row execute function public.audit_profile_change();

-- Accepter une invitation : l'adresse du compte connecté doit correspondre
-- exactement à l'adresse invitée. Une invitation expirée ou déjà utilisée échoue.
create or replace function public.accept_organization_invitation(p_invitation_id uuid)
returns uuid language plpgsql security definer set search_path=public,auth
as $$
declare v_inv public.organization_invitations%rowtype; v_email text; v_membership uuid;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select lower(email) into v_email from auth.users where id=auth.uid();
  select * into v_inv from public.organization_invitations
   where id=p_invitation_id for update;
  if not found then raise exception 'Invitation introuvable'; end if;
  if v_inv.accepted_at is not null then raise exception 'Invitation déjà utilisée'; end if;
  if v_inv.expires_at <= now() then raise exception 'Invitation expirée'; end if;
  if lower(v_inv.email) <> coalesce(v_email,'') then raise exception 'Cette invitation ne correspond pas à votre adresse e-mail'; end if;
  if exists(select 1 from public.organization_memberships
            where organization_id=v_inv.organization_id and user_id=auth.uid()) then
    raise exception 'Ce compte possède déjà une adhésion à cette organisation';
  end if;
  insert into public.organization_memberships(organization_id,user_id,role,status)
  values(v_inv.organization_id,auth.uid(),v_inv.role,'active') returning id into v_membership;
  update public.organization_invitations set accepted_at=now() where id=v_inv.id;
  return v_membership;
end; $$;
revoke all on function public.accept_organization_invitation(uuid) from public;
grant execute on function public.accept_organization_invitation(uuid) to authenticated;

-- Consultation du journal avec filtre organisation, pagination côté client.
-- Pas de fonction d'écriture exposée : les triggers créent les entrées.

comment on table public.organization_invitations is
'Invitations en attente. Table sans accès direct client; les Edge Functions utilisent service_role.';
comment on function public.accept_organization_invitation(uuid) is
'Accepte une invitation uniquement si l''e-mail du compte authentifié correspond et si elle est valide.';


create or replace function public.list_my_organization_invitations()
returns table(invitation_id uuid, organization_id uuid, organization_name text,
              invited_role text, expires_at timestamptz)
language sql stable security definer set search_path=public,auth
as $$
  select i.id,i.organization_id,o.name,i.role,i.expires_at
  from public.organization_invitations i
  join public.organizations o on o.id=i.organization_id
  join auth.users u on u.id=auth.uid()
  where lower(i.email)=lower(u.email)
    and i.accepted_at is null and i.expires_at > now()
  order by i.created_at desc;
$$;
revoke all on function public.list_my_organization_invitations() from public;
grant execute on function public.list_my_organization_invitations() to authenticated;

create or replace function public.audit_invitation_created()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.audit_logs(organization_id,actor_user_id,action,table_name,record_id,details)
  values(new.organization_id,new.invited_by,
         case when tg_op='INSERT' then 'member.invited' else 'member.invitation_renewed' end,
         'organization_invitations',new.id::text,
         jsonb_build_object('role',new.role,'expires_at',new.expires_at));
  return new;
end; $$;
drop trigger if exists audit_invitation_insert on public.organization_invitations;
drop trigger if exists audit_invitation_changes on public.organization_invitations;
create trigger audit_invitation_changes after insert or update on public.organization_invitations
for each row execute function public.audit_invitation_created();

-- Trace l'ouverture d'une session via l'application. L'utilisateur ne choisit
-- ni l'action, ni l'organisation, ni l'identité inscrite dans le journal.
create or replace function public.record_my_session_start()
returns void language plpgsql security definer set search_path=public
as $$
declare m record;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  for m in select organization_id from public.organization_memberships
           where user_id=auth.uid() and status='active'
  loop
    if not exists (
      select 1 from public.audit_logs a
      where a.organization_id=m.organization_id and a.actor_user_id=auth.uid()
        and a.action='session.started' and a.created_at > now() - interval '5 minutes'
    ) then
      insert into public.audit_logs(organization_id,actor_user_id,action,table_name,record_id,details)
      values(m.organization_id,auth.uid(),'session.started','auth.users',auth.uid()::text,'{}'::jsonb);
    end if;
  end loop;
end; $$;
revoke all on function public.record_my_session_start() from public;
grant execute on function public.record_my_session_start() to authenticated;
