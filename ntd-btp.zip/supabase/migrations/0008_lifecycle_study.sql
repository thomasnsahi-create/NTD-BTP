-- =====================================================================
-- V8 — Cycle de vie du projet + module Étude (métrés, prix, devis, budget initial)
-- Migration NON destructive : aucune table existante n'est supprimée ni vidée.
-- =====================================================================

-- ---------- Colonnes additionnelles sur les tables existantes ----------
alter table public.work_packages add column if not exists trade_id uuid references public.trades(id) on delete set null;
alter table public.project_budget_lines add column if not exists source_estimate_id uuid;
alter table public.project_budget_lines add column if not exists is_baseline boolean not null default false;

-- ---------- Droit d'intervenir dans l'étude ----------
create or replace function public.can_manage_project_study(p_project uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.can_manage_project(p_project)
      or public.can_manage_project_finance(p_project)
      or public.can_manage_project_schedule(p_project)
$$;
revoke all on function public.can_manage_project_study(uuid) from public;
grant execute on function public.can_manage_project_study(uuid) to authenticated;

-- =====================================================================
-- 1. CYCLE DE VIE
-- =====================================================================
create table public.lifecycle_requirements (
  stage text not null check (stage in ('study','preparation','execution','reception','closure')),
  code text not null,
  label text not null,
  sort_order integer not null,
  is_auto boolean not null default false,
  primary key (stage, code)
);

insert into public.lifecycle_requirements (stage, code, label, sort_order, is_auto) values
('study','IDENTIFICATION','Identification du projet',1,false),
('study','BESOINS','Analyse des besoins',2,false),
('study','ETUDES_TECH','Études techniques',3,false),
('study','CORPS_METIER','Choix des corps de métier',4,false),
('study','LOTS','Création des lots',5,false),
('study','METRES','Métrés',6,false),
('study','QUANTITATIFS','Quantitatifs',7,false),
('study','PRIX','Bibliothèque des prix',8,false),
('study','DEVIS','Devis estimatif',9,false),
('study','DEVIS_VALIDE','Validation du devis',10,true),
('preparation','BUDGET_INITIAL','Budget initial',1,true),
('preparation','PLANNING','Planning général',2,false),
('preparation','GANTT','Diagramme de Gantt',3,false),
('preparation','CHEMIN_CRITIQUE','Chemin critique',4,false),
('preparation','CALENDRIERS','Calendriers de travail',5,false),
('preparation','JOURS_FERIES','Jours fériés',6,false),
('preparation','EQUIPES','Affectation des équipes',7,false),
('preparation','COMPETENCES','Gestion des compétences',8,false),
('preparation','ENGINS','Affectation des engins',9,false),
('preparation','APPROVISIONNEMENT','Approvisionnement',10,false),
('preparation','INSTALLATION','Installation du chantier',11,false),
('preparation','PLAN_SECURITE','Plan de sécurité',12,false),
('preparation','DEMARRAGE','Validation du démarrage',13,false),
('execution','JOURNAL','Journal quotidien',1,false),
('execution','PHOTOS','Photos',2,false),
('execution','QUANTITES','Quantités exécutées',3,false),
('execution','DEPENSES','Dépenses réelles',4,false),
('execution','MATERIAUX','Consommation des matériaux',5,false),
('execution','SUIVI_EQUIPES','Suivi des équipes',6,false),
('execution','SUIVI_ENGINS','Suivi des engins',7,false),
('execution','AVANCEMENT_PHYSIQUE','Avancement physique',8,false),
('execution','AVANCEMENT_FINANCIER','Avancement financier',9,false),
('execution','INCIDENTS','Gestion des incidents',10,false),
('execution','RETARDS','Détection des retards',11,false),
('execution','ECARTS','Analyse des écarts',12,false),
('execution','ALERTES','Alertes automatiques',13,false),
('reception','INSPECTION','Inspection des ouvrages',1,false),
('reception','CONFORMITE','Vérification de conformité',2,false),
('reception','ESSAIS','Essais techniques',3,false),
('reception','MISE_EN_SERVICE','Mise en service',4,false),
('reception','RESERVES_LISTE','Liste des réserves',5,false),
('reception','RESERVES_ATTRIBUTION','Attribution des corrections',6,false),
('reception','RESERVES_SUIVI','Suivi des réserves',7,false),
('reception','RESERVES_VALIDATION','Validation des corrections',8,false),
('reception','PV_PROVISOIRE','Procès-verbal de réception provisoire',9,false),
('reception','RECEPTION_DEFINITIVE','Réception définitive',10,false),
('closure','DECOMPTE_FINAL','Décompte final',1,false),
('closure','SITUATION_FINANCIERE','Situation financière définitive',2,false),
('closure','REGLEMENT_FOURNISSEURS','Règlement des fournisseurs',3,false),
('closure','BILAN_COUTS','Bilan des coûts',4,false),
('closure','BILAN_DELAIS','Bilan des délais',5,false),
('closure','ARCHIVAGE','Archivage des documents',6,false),
('closure','PLANS_RECOLEMENT','Plans de récolement',7,false),
('closure','DOSSIER_OUVRAGES','Dossier des ouvrages exécutés',8,false),
('closure','RAPPORT_FINAL','Rapport final',9,false),
('closure','CLOTURE_ADMIN','Clôture administrative et financière',10,false);

create table public.project_lifecycle (
  project_id uuid primary key references public.projects(id) on delete cascade,
  current_stage text not null default 'study' check (current_stage in ('study','preparation','execution','reception','closure')),
  stage_started_at timestamptz not null default now(),
  closed_at timestamptz,
  updated_at timestamptz not null default now()
);

create table public.lifecycle_validations (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  stage text not null check (stage in ('study','preparation','execution','reception','closure')),
  code text not null,
  label text not null,
  sort_order integer not null default 0,
  is_auto boolean not null default false,
  is_done boolean not null default false,
  comment text,
  validated_by uuid references auth.users(id),
  validated_at timestamptz,
  unique (project_id, stage, code)
);
create index idx_lifecycle_validations_project on public.lifecycle_validations(project_id, stage);

create table public.project_stage_history (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  from_stage text,
  to_stage text not null,
  changed_by uuid references auth.users(id),
  changed_at timestamptz not null default now()
);

create trigger audit_lifecycle_validations after insert or update or delete on public.lifecycle_validations
  for each row execute function public.audit_project_record();
create trigger audit_project_stage_history after insert on public.project_stage_history
  for each row execute function public.audit_project_record();

-- Initialisation du cycle de vie d'un projet
create or replace function public.init_project_lifecycle(p_project uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.project_lifecycle(project_id) values (p_project) on conflict (project_id) do nothing;
  insert into public.lifecycle_validations(project_id, stage, code, label, sort_order, is_auto)
  select p_project, r.stage, r.code, r.label, r.sort_order, r.is_auto
  from public.lifecycle_requirements r
  on conflict (project_id, stage, code) do nothing;
end $$;
revoke all on function public.init_project_lifecycle(uuid) from public;

create or replace function public.init_project_lifecycle_trigger()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.init_project_lifecycle(new.id);
  return new;
end $$;
create trigger init_project_lifecycle_after_insert after insert on public.projects
  for each row execute function public.init_project_lifecycle_trigger();

-- Projets existants : cycle de vie créé sans rien modifier d'autre
do $$
declare r record;
begin
  for r in select id from public.projects loop
    perform public.init_project_lifecycle(r.id);
  end loop;
end $$;

-- Cocher / décocher une validation manuelle de l'étape en cours
create or replace function public.set_lifecycle_validation(p_project uuid, p_stage text, p_code text, p_done boolean, p_comment text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_stage text; v_auto boolean;
begin
  if not (public.can_manage_project(p_project) or public.can_manage_project_study(p_project)) then
    raise exception 'Droits insuffisants pour valider cette étape';
  end if;
  select current_stage into v_stage from public.project_lifecycle where project_id = p_project;
  if v_stage is null then raise exception 'Cycle de vie introuvable'; end if;
  if v_stage <> p_stage then raise exception 'Seules les validations de l''étape en cours peuvent être modifiées'; end if;
  select is_auto into v_auto from public.lifecycle_validations where project_id = p_project and stage = p_stage and code = p_code;
  if v_auto is null then raise exception 'Validation introuvable'; end if;
  if v_auto then raise exception 'Cette validation est automatique'; end if;
  update public.lifecycle_validations
     set is_done = p_done,
         comment = coalesce(p_comment, comment),
         validated_by = case when p_done then auth.uid() else null end,
         validated_at = case when p_done then now() else null end
   where project_id = p_project and stage = p_stage and code = p_code;
end $$;
revoke all on function public.set_lifecycle_validation(uuid, text, text, boolean, text) from public;
grant execute on function public.set_lifecycle_validation(uuid, text, text, boolean, text) to authenticated;

-- Passage à l'étape suivante (toutes les validations de l'étape en cours sont obligatoires)
create or replace function public.advance_project_stage(p_project uuid)
returns text language plpgsql security definer set search_path = public as $$
declare v_stage text; v_next text; v_missing integer; v_first text;
begin
  if not public.can_manage_project(p_project) then
    raise exception 'Seul un responsable de projet peut changer d''étape';
  end if;
  select current_stage into v_stage from public.project_lifecycle where project_id = p_project for update;
  if v_stage is null then raise exception 'Cycle de vie introuvable'; end if;
  select count(*), min(label) into v_missing, v_first
    from public.lifecycle_validations where project_id = p_project and stage = v_stage and not is_done;
  if v_missing > 0 then
    raise exception 'Étape incomplète : % validation(s) manquante(s), par exemple « % »', v_missing, v_first;
  end if;
  v_next := case v_stage when 'study' then 'preparation' when 'preparation' then 'execution'
            when 'execution' then 'reception' when 'reception' then 'closure' else null end;
  if v_next is null then
    update public.project_lifecycle set closed_at = coalesce(closed_at, now()), updated_at = now() where project_id = p_project;
    insert into public.project_stage_history(project_id, from_stage, to_stage, changed_by) values (p_project, v_stage, 'closed', auth.uid());
    return 'closed';
  end if;
  update public.project_lifecycle set current_stage = v_next, stage_started_at = now(), updated_at = now() where project_id = p_project;
  insert into public.project_stage_history(project_id, from_stage, to_stage, changed_by) values (p_project, v_stage, v_next, auth.uid());
  return v_next;
end $$;
revoke all on function public.advance_project_stage(uuid) from public;
grant execute on function public.advance_project_stage(uuid) to authenticated;

alter table public.lifecycle_requirements enable row level security;
alter table public.project_lifecycle enable row level security;
alter table public.lifecycle_validations enable row level security;
alter table public.project_stage_history enable row level security;
create policy lifecycle_requirements_read on public.lifecycle_requirements for select to authenticated using (true);
create policy project_lifecycle_read on public.project_lifecycle for select to authenticated using (public.can_access_project(project_id));
create policy lifecycle_validations_read on public.lifecycle_validations for select to authenticated using (public.can_access_project(project_id));
create policy project_stage_history_read on public.project_stage_history for select to authenticated using (public.can_access_project(project_id));

-- =====================================================================
-- 2. BIBLIOTHÈQUE DES PRIX
-- =====================================================================
create table public.price_library (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  kind text not null default 'material' check (kind in ('material','labor','equipment','machine','service','subcontract')),
  code text,
  designation text not null,
  unit text not null,
  unit_price numeric(18,2) not null check (unit_price >= 0),
  currency char(3) not null default 'XAF',
  region text,
  supplier text,
  project_id uuid references public.projects(id) on delete set null,
  valid_from date not null default current_date,
  is_active boolean not null default true,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_price_library_org on public.price_library(organization_id, kind);

create table public.price_history (
  id uuid primary key default gen_random_uuid(),
  price_id uuid not null references public.price_library(id) on delete cascade,
  unit_price numeric(18,2) not null,
  effective_date date not null default current_date,
  changed_by uuid references auth.users(id),
  changed_at timestamptz not null default now()
);

create or replace function public.log_price_history()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' or new.unit_price is distinct from old.unit_price then
    insert into public.price_history(price_id, unit_price, effective_date, changed_by)
    values (new.id, new.unit_price, current_date, auth.uid());
  end if;
  return new;
end $$;
create trigger price_library_history after insert or update on public.price_library
  for each row execute function public.log_price_history();
create trigger price_library_touch before update on public.price_library
  for each row execute function public.touch_updated_at();

alter table public.price_library enable row level security;
alter table public.price_history enable row level security;
create policy price_library_read on public.price_library for select to authenticated
  using (public.is_org_member(organization_id));
create policy price_library_write on public.price_library for all to authenticated
  using (public.has_org_permission(organization_id,'projects.budget.manage') or public.has_org_permission(organization_id,'projects.manage'))
  with check (public.has_org_permission(organization_id,'projects.budget.manage') or public.has_org_permission(organization_id,'projects.manage'));
create policy price_history_read on public.price_history for select to authenticated
  using (exists (select 1 from public.price_library p where p.id = price_id and public.is_org_member(p.organization_id)));

-- =====================================================================
-- 3. MÉTRÉS
-- =====================================================================
create table public.measurements (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  work_package_id uuid references public.work_packages(id) on delete set null,
  title text not null,
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_measurements_project on public.measurements(project_id);

create table public.measurement_items (
  id uuid primary key default gen_random_uuid(),
  measurement_id uuid not null references public.measurements(id) on delete cascade,
  number integer not null default 1,
  designation text not null,
  location text,
  length numeric(14,3),
  width numeric(14,3),
  height numeric(14,3),
  thickness numeric(14,3),
  count numeric(14,3) not null default 1,
  unit text not null default 'm2',
  formula text,
  quantity numeric(18,3) not null default 0,
  notes text,
  plan_ref text,
  created_at timestamptz not null default now()
);
create index idx_measurement_items_fiche on public.measurement_items(measurement_id);

create or replace function public.compute_measurement_quantity()
returns trigger language plpgsql as $$
begin
  new.quantity := round(case lower(new.unit)
    when 'm'  then new.count * coalesce(new.length, 0)
    when 'ml' then new.count * coalesce(new.length, 0)
    when 'm2' then new.count * coalesce(new.length, 0) * coalesce(new.width, new.height, 0)
    when 'm3' then new.count * coalesce(new.length, 0) * coalesce(new.width, 0) * coalesce(new.height, new.thickness, 0)
    else new.count
  end, 3);
  return new;
end $$;
create trigger measurement_items_compute before insert or update on public.measurement_items
  for each row execute function public.compute_measurement_quantity();
create trigger measurements_touch before update on public.measurements
  for each row execute function public.touch_updated_at();
create trigger audit_measurements after insert or update or delete on public.measurements
  for each row execute function public.audit_project_record();

alter table public.measurements enable row level security;
alter table public.measurement_items enable row level security;
create policy measurements_read on public.measurements for select to authenticated using (public.can_access_project(project_id));
create policy measurements_write on public.measurements for all to authenticated
  using (public.can_manage_project_study(project_id)) with check (public.can_manage_project_study(project_id));
create policy measurement_items_read on public.measurement_items for select to authenticated
  using (exists (select 1 from public.measurements m where m.id = measurement_id and public.can_access_project(m.project_id)));
create policy measurement_items_write on public.measurement_items for all to authenticated
  using (exists (select 1 from public.measurements m where m.id = measurement_id and public.can_manage_project_study(m.project_id)))
  with check (exists (select 1 from public.measurements m where m.id = measurement_id and public.can_manage_project_study(m.project_id)));

-- =====================================================================
-- 4. DEVIS ESTIMATIF
-- =====================================================================
create table public.estimates (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  version integer not null,
  title text not null default 'Devis estimatif',
  status text not null default 'draft' check (status in ('draft','approved','superseded')),
  revision_of uuid references public.estimates(id),
  fees_percent numeric(6,2) not null default 0 check (fees_percent >= 0 and fees_percent <= 100),
  currency char(3) not null default 'XAF',
  subtotal numeric(18,2) not null default 0,
  fees_amount numeric(18,2) not null default 0,
  total_amount numeric(18,2) not null default 0,
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (project_id, version)
);
create index idx_estimates_project on public.estimates(project_id);

create table public.estimate_items (
  id uuid primary key default gen_random_uuid(),
  estimate_id uuid not null references public.estimates(id) on delete cascade,
  work_package_id uuid references public.work_packages(id) on delete set null,
  trade_id uuid references public.trades(id) on delete set null,
  line_no integer not null default 0,
  kind text not null default 'material' check (kind in ('material','labor','equipment','machine','service','subcontract')),
  designation text not null,
  unit text not null,
  quantity numeric(18,3) not null default 0 check (quantity >= 0),
  unit_price numeric(18,2) not null default 0 check (unit_price >= 0),
  total numeric(18,2) generated always as (round(quantity * unit_price, 2)) stored,
  price_id uuid references public.price_library(id) on delete set null,
  notes text,
  created_at timestamptz not null default now()
);
create index idx_estimate_items_estimate on public.estimate_items(estimate_id);

-- Verrouillage d'un devis validé + calcul des totaux
create or replace function public.estimates_guard_totals()
returns trigger language plpgsql as $$
begin
  if tg_op = 'UPDATE' and old.status <> 'draft' then
    if not (old.status = 'approved' and new.status = 'superseded'
            and new.subtotal = old.subtotal and new.total_amount = old.total_amount
            and new.fees_percent = old.fees_percent and new.version = old.version) then
      raise exception 'Ce devis est validé : il ne peut plus être modifié (créez une nouvelle version)';
    end if;
    return new;
  end if;
  new.fees_amount := round(new.subtotal * new.fees_percent / 100, 2);
  new.total_amount := new.subtotal + new.fees_amount;
  new.updated_at := now();
  return new;
end $$;
create trigger estimates_guard_totals_trigger before insert or update on public.estimates
  for each row execute function public.estimates_guard_totals();

create or replace function public.estimates_block_delete()
returns trigger language plpgsql as $$
begin
  if old.status <> 'draft' then raise exception 'Un devis validé ne peut pas être supprimé'; end if;
  return old;
end $$;
create trigger estimates_block_delete_trigger before delete on public.estimates
  for each row execute function public.estimates_block_delete();
create trigger audit_estimates after insert or update or delete on public.estimates
  for each row execute function public.audit_project_record();

create or replace function public.estimate_items_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_est uuid; v_status text; v_project uuid; v_wp_trade uuid;
begin
  v_est := case when tg_op = 'DELETE' then old.estimate_id else new.estimate_id end;
  select status, project_id into v_status, v_project from public.estimates where id = v_est;
  if v_status is not null and v_status <> 'draft' then
    raise exception 'Ce devis est validé : ses lignes ne peuvent plus être modifiées';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  if new.work_package_id is not null then
    select trade_id into v_wp_trade from public.work_packages where id = new.work_package_id and project_id = v_project;
    if not found then raise exception 'Le lot choisi n''appartient pas à ce projet'; end if;
    if new.trade_id is null then new.trade_id := v_wp_trade; end if;
  end if;
  return new;
end $$;
create trigger estimate_items_guard_trigger before insert or update or delete on public.estimate_items
  for each row execute function public.estimate_items_guard();

create or replace function public.estimate_items_recompute()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_est uuid;
begin
  v_est := case when tg_op = 'DELETE' then old.estimate_id else new.estimate_id end;
  update public.estimates
     set subtotal = (select coalesce(sum(total), 0) from public.estimate_items where estimate_id = v_est)
   where id = v_est and status = 'draft';
  return null;
end $$;
create trigger estimate_items_recompute_trigger after insert or update or delete on public.estimate_items
  for each row execute function public.estimate_items_recompute();

-- Historique des budgets (initial = révision 0, avenants ensuite)
create table public.budget_revisions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  estimate_id uuid not null references public.estimates(id),
  revision_no integer not null,
  total_amount numeric(18,2) not null,
  previous_total numeric(18,2),
  delta numeric(18,2),
  approved_by uuid references auth.users(id),
  approved_at timestamptz not null default now(),
  unique (project_id, revision_no)
);

alter table public.estimates enable row level security;
alter table public.estimate_items enable row level security;
alter table public.budget_revisions enable row level security;
create policy estimates_read on public.estimates for select to authenticated using (public.can_view_project_budget(project_id) or public.can_manage_project_study(project_id));
create policy estimates_insert on public.estimates for insert to authenticated
  with check (public.can_manage_project_study(project_id) and created_by = auth.uid() and status = 'draft');
create policy estimates_update on public.estimates for update to authenticated
  using (public.can_manage_project_study(project_id)) with check (public.can_manage_project_study(project_id));
create policy estimates_delete on public.estimates for delete to authenticated
  using (public.can_manage_project_study(project_id) and status = 'draft');
create policy estimate_items_read on public.estimate_items for select to authenticated
  using (exists (select 1 from public.estimates e where e.id = estimate_id and (public.can_view_project_budget(e.project_id) or public.can_manage_project_study(e.project_id))));
create policy estimate_items_write on public.estimate_items for all to authenticated
  using (exists (select 1 from public.estimates e where e.id = estimate_id and public.can_manage_project_study(e.project_id)))
  with check (exists (select 1 from public.estimates e where e.id = estimate_id and public.can_manage_project_study(e.project_id)));
create policy budget_revisions_read on public.budget_revisions for select to authenticated
  using (public.can_view_project_budget(project_id));

-- Créer une nouvelle version de devis (copie de la dernière version)
create or replace function public.create_estimate_version(p_project uuid, p_title text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_prev record; v_ver integer; v_id uuid; v_cur char(3);
begin
  if not public.can_manage_project_study(p_project) then raise exception 'Droits insuffisants'; end if;
  if exists (select 1 from public.estimates where project_id = p_project and status = 'draft') then
    raise exception 'Un devis brouillon existe déjà pour ce projet';
  end if;
  select * into v_prev from public.estimates where project_id = p_project order by version desc limit 1;
  v_ver := coalesce(v_prev.version, 0) + 1;
  select currency into v_cur from public.projects where id = p_project;
  insert into public.estimates(project_id, version, title, revision_of, fees_percent, currency, created_by)
  values (p_project, v_ver,
          coalesce(nullif(trim(p_title), ''), case when v_ver = 1 then 'Devis estimatif' else 'Avenant n°' || (v_ver - 1) end),
          v_prev.id, coalesce(v_prev.fees_percent, 0), coalesce(v_cur, 'XAF'), auth.uid())
  returning id into v_id;
  if v_prev.id is not null then
    insert into public.estimate_items(estimate_id, work_package_id, trade_id, line_no, kind, designation, unit, quantity, unit_price, price_id, notes)
    select v_id, work_package_id, trade_id, line_no, kind, designation, unit, quantity, unit_price, price_id, notes
    from public.estimate_items where estimate_id = v_prev.id;
  end if;
  return v_id;
end $$;
revoke all on function public.create_estimate_version(uuid, text) from public;
grant execute on function public.create_estimate_version(uuid, text) to authenticated;

-- Validation du devis : crée le budget initial (une seule fois) puis les avenants
create or replace function public.approve_estimate(p_estimate uuid)
returns integer language plpgsql security definer set search_path = public as $$
declare e record; v_prev record; v_rev integer; v_cnt integer;
begin
  select * into e from public.estimates where id = p_estimate for update;
  if not found then raise exception 'Devis introuvable'; end if;
  if not (public.can_manage_project_finance(e.project_id) or public.can_manage_project(e.project_id)) then
    raise exception 'Seul un responsable financier ou de projet peut valider un devis';
  end if;
  if e.status <> 'draft' then raise exception 'Seul un devis brouillon peut être validé'; end if;
  select count(*) into v_cnt from public.estimate_items where estimate_id = e.id;
  if v_cnt = 0 then raise exception 'Le devis est vide'; end if;

  select * into v_prev from public.estimates where project_id = e.project_id and status = 'approved' limit 1;
  if found then
    update public.estimates set status = 'superseded' where id = v_prev.id;
    select coalesce(max(revision_no), -1) + 1 into v_rev from public.budget_revisions where project_id = e.project_id;
  else
    v_rev := 0;
  end if;

  update public.estimates set status = 'approved', approved_by = auth.uid(), approved_at = now() where id = e.id;
  select * into e from public.estimates where id = p_estimate;

  insert into public.budget_revisions(project_id, estimate_id, revision_no, total_amount, previous_total, delta, approved_by)
  values (e.project_id, e.id, v_rev, e.total_amount, v_prev.total_amount, e.total_amount - coalesce(v_prev.total_amount, 0), auth.uid());

  -- Budget initial : lignes figées (quantités et prix de référence conservés)
  if v_rev = 0 then
    insert into public.project_budget_lines(project_id, work_package_id, code, category, designation, unit, quantity, unit_price, currency, created_by, source_estimate_id, is_baseline)
    select e.project_id, i.work_package_id, 'EST' || e.version || '-' || lpad(row_number() over (order by i.line_no, i.created_at)::text, 3, '0'),
           i.kind, i.designation, i.unit, i.quantity, i.unit_price, e.currency, auth.uid(), e.id, true
    from public.estimate_items i where i.estimate_id = e.id;
    if e.fees_amount > 0 then
      insert into public.project_budget_lines(project_id, code, category, designation, unit, quantity, unit_price, currency, created_by, source_estimate_id, is_baseline)
      values (e.project_id, 'EST' || e.version || '-FRAIS', 'fees', 'Frais retenus (' || e.fees_percent || ' %)', 'forfait', 1, e.fees_amount, e.currency, auth.uid(), e.id, true);
    end if;
  end if;

  update public.lifecycle_validations
     set is_done = true, validated_by = auth.uid(), validated_at = now()
   where project_id = e.project_id
     and ((stage = 'study' and code = 'DEVIS_VALIDE') or (stage = 'preparation' and code = 'BUDGET_INITIAL'));
  return v_rev;
end $$;
revoke all on function public.approve_estimate(uuid) from public;
grant execute on function public.approve_estimate(uuid) to authenticated;

-- Le budget initial approuvé ne peut jamais être écrasé
create or replace function public.protect_baseline_budget()
returns trigger language plpgsql as $$
begin
  if old.is_baseline then
    if tg_op = 'DELETE' then raise exception 'Le budget initial approuvé ne peut pas être supprimé'; end if;
    if new.quantity <> old.quantity or new.unit_price <> old.unit_price or new.designation <> old.designation
       or new.is_baseline <> old.is_baseline or new.work_package_id is distinct from old.work_package_id then
      raise exception 'Le budget initial approuvé ne peut pas être modifié (créez un avenant)';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_baseline_budget_trigger before update or delete on public.project_budget_lines
  for each row execute function public.protect_baseline_budget();

-- Droits API
grant select, insert, update, delete on all tables in schema public to authenticated;
grant all on all tables in schema public to service_role;
notify pgrst, 'reload schema';
