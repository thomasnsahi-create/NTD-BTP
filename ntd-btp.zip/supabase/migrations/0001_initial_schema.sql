-- BTP MANAGER — Migration initiale
-- À exécuter dans Supabase SQL Editor sur un projet neuf.
create extension if not exists pgcrypto;

create type public.membership_status as enum ('invited', 'active', 'suspended');
create type public.project_status as enum ('draft', 'study', 'planned', 'in_progress', 'on_hold', 'completed', 'cancelled');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  legal_name text,
  country_code char(2) not null default 'CM',
  default_currency char(3) not null default 'XAF',
  timezone text not null default 'Africa/Douala',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  preferred_language text not null default 'fr',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organization_memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member')),
  status public.membership_status not null default 'active',
  created_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

create table public.sectors (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  description text,
  is_active boolean not null default true,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.trade_families (
  id uuid primary key default gen_random_uuid(),
  sector_id uuid not null references public.sectors(id) on delete restrict,
  code text,
  name text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (sector_id, name)
);

create table public.trades (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.trade_families(id) on delete restrict,
  code text,
  name text not null,
  description text,
  is_active boolean not null default true,
  is_custom boolean not null default false,
  created_at timestamptz not null default now(),
  unique (family_id, name)
);

create table public.specialties (
  id uuid primary key default gen_random_uuid(),
  trade_id uuid not null references public.trades(id) on delete cascade,
  name text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (trade_id, name)
);

create table public.trade_activities (
  id uuid primary key default gen_random_uuid(),
  specialty_id uuid not null references public.specialties(id) on delete cascade,
  name text not null,
  description text,
  default_unit text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (specialty_id, name)
);

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  name text not null,
  description text,
  sector_id uuid references public.sectors(id),
  project_type text,
  client_name text,
  site_address text,
  country_code char(2) not null default 'CM',
  currency char(3) not null default 'XAF',
  status public.project_status not null default 'draft',
  planned_start date,
  planned_end date,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, code)
);

create table public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  project_role text not null default 'member',
  created_at timestamptz not null default now(),
  unique (project_id, user_id)
);

create table public.work_packages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  parent_id uuid references public.work_packages(id) on delete set null,
  code text,
  name text not null,
  description text,
  status text not null default 'not_started',
  planned_start date,
  planned_end date,
  created_at timestamptz not null default now()
);

create table public.project_trades (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  trade_id uuid not null references public.trades(id) on delete restrict,
  work_package_id uuid references public.work_packages(id) on delete set null,
  responsible_user_id uuid references auth.users(id) on delete set null,
  subcontractor_name text,
  created_at timestamptz not null default now(),
  unique (project_id, trade_id, work_package_id)
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  organization_id uuid references public.organizations(id) on delete set null,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  table_name text not null,
  record_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Helper functions SECURITY DEFINER : évitent les politiques RLS récursives.
create or replace function public.is_org_member(p_org uuid)
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organization_memberships m
    where m.organization_id = p_org
      and m.user_id = auth.uid()
      and m.status = 'active'
  );
$$;

create or replace function public.has_org_role(p_org uuid, p_roles text[])
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organization_memberships m
    where m.organization_id = p_org
      and m.user_id = auth.uid()
      and m.status = 'active'
      and m.role = any(p_roles)
  );
$$;

create or replace function public.can_access_project(p_project uuid)
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.projects p
    join public.organization_memberships m
      on m.organization_id = p.organization_id
    where p.id = p_project
      and m.user_id = auth.uid()
      and m.status = 'active'
  );
$$;

-- Profiles
alter table public.profiles enable row level security;
create policy "profiles_select_self" on public.profiles
for select to authenticated using (id = auth.uid());
create policy "profiles_insert_self" on public.profiles
for insert to authenticated with check (id = auth.uid());
create policy "profiles_update_self" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Organization data
alter table public.organizations enable row level security;
create policy "org_select_members" on public.organizations
for select to authenticated using (public.is_org_member(id));
create policy "org_update_admins" on public.organizations
for update to authenticated using (public.has_org_role(id, array['owner','admin']))
with check (public.has_org_role(id, array['owner','admin']));

alter table public.organization_memberships enable row level security;
create policy "memberships_select_same_org" on public.organization_memberships
for select to authenticated using (public.is_org_member(organization_id));
create policy "memberships_insert_admins" on public.organization_memberships
for insert to authenticated with check (
  public.has_org_role(organization_id, array['owner','admin'])
);
create policy "memberships_update_admins" on public.organization_memberships
for update to authenticated using (
  public.has_org_role(organization_id, array['owner','admin'])
) with check (
  public.has_org_role(organization_id, array['owner','admin'])
);

-- Reference catalogue: visible to authenticated users; custom inserts restricted to org admins later.
alter table public.sectors enable row level security;
alter table public.trade_families enable row level security;
alter table public.trades enable row level security;
alter table public.specialties enable row level security;
alter table public.trade_activities enable row level security;

create policy "sectors_read_authenticated" on public.sectors
for select to authenticated using (true);
create policy "families_read_authenticated" on public.trade_families
for select to authenticated using (true);
create policy "trades_read_authenticated" on public.trades
for select to authenticated using (true);
create policy "specialties_read_authenticated" on public.specialties
for select to authenticated using (true);
create policy "activities_read_authenticated" on public.trade_activities
for select to authenticated using (true);

-- Projects and project-level records
alter table public.projects enable row level security;
create policy "projects_select_org_members" on public.projects
for select to authenticated using (public.is_org_member(organization_id));
create policy "projects_insert_org_managers" on public.projects
for insert to authenticated with check (
  public.has_org_role(organization_id, array['owner','admin','project_manager'])
  and created_by = auth.uid()
);
create policy "projects_update_org_managers" on public.projects
for update to authenticated using (
  public.has_org_role(organization_id, array['owner','admin','project_manager'])
) with check (
  public.has_org_role(organization_id, array['owner','admin','project_manager'])
);

alter table public.project_members enable row level security;
create policy "project_members_select" on public.project_members
for select to authenticated using (public.can_access_project(project_id));
create policy "project_members_manage" on public.project_members
for all to authenticated using (
  exists (
    select 1 from public.projects p
    where p.id = project_id
      and public.has_org_role(p.organization_id, array['owner','admin','project_manager'])
  )
) with check (
  exists (
    select 1 from public.projects p
    where p.id = project_id
      and public.has_org_role(p.organization_id, array['owner','admin','project_manager'])
  )
);

alter table public.work_packages enable row level security;
create policy "work_packages_select" on public.work_packages
for select to authenticated using (public.can_access_project(project_id));
create policy "work_packages_manage" on public.work_packages
for all to authenticated using (
  exists (select 1 from public.projects p where p.id = project_id
    and public.has_org_role(p.organization_id, array['owner','admin','project_manager','engineer','site_manager']))
) with check (
  exists (select 1 from public.projects p where p.id = project_id
    and public.has_org_role(p.organization_id, array['owner','admin','project_manager','engineer','site_manager']))
);

alter table public.project_trades enable row level security;
create policy "project_trades_select" on public.project_trades
for select to authenticated using (public.can_access_project(project_id));
create policy "project_trades_manage" on public.project_trades
for all to authenticated using (
  exists (select 1 from public.projects p where p.id = project_id
    and public.has_org_role(p.organization_id, array['owner','admin','project_manager','engineer','site_manager']))
) with check (
  exists (select 1 from public.projects p where p.id = project_id
    and public.has_org_role(p.organization_id, array['owner','admin','project_manager','engineer','site_manager']))
);

alter table public.audit_logs enable row level security;
create policy "audit_select_admins" on public.audit_logs
for select to authenticated using (
  organization_id is not null and public.has_org_role(organization_id, array['owner','admin'])
);

-- Indexes
create index idx_memberships_user on public.organization_memberships(user_id);
create index idx_projects_org on public.projects(organization_id);
create index idx_project_members_user on public.project_members(user_id);
create index idx_work_packages_project on public.work_packages(project_id);
create index idx_project_trades_project on public.project_trades(project_id);

-- Create a profile row when a Supabase Auth user is created.
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
