-- V6 : prévision de fin et application atomique d'une reprogrammation.
-- Migration additive : aucune table ni donnée existante n'est supprimée.

alter table public.projects
  add column if not exists forecast_end date,
  add column if not exists forecast_delay_days integer not null default 0,
  add column if not exists forecast_calculated_at timestamptz;

comment on column public.projects.forecast_end is
  'Date de fin recalculée après analyse/reprogrammation; distincte de la date contractuelle planned_end.';
comment on column public.projects.forecast_delay_days is
  'Écart en jours calendaires entre la fin prévisionnelle recalculée et la fin initialement planifiée.';

create or replace function public.apply_project_schedule_proposal(
  p_project uuid,
  p_updates jsonb,
  p_forecast_end date,
  p_delay_days integer
)
returns integer
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_expected integer;
  v_updated integer;
begin
  if auth.uid() is null then
    raise exception 'Authentification requise';
  end if;
  if not public.can_manage_project_schedule(p_project) then
    raise exception 'Permission de gestion du planning requise';
  end if;
  if p_updates is null or jsonb_typeof(p_updates) <> 'array' then
    raise exception 'La proposition de planning doit être une liste';
  end if;

  v_expected := jsonb_array_length(p_updates);
  if exists (
    select 1 from jsonb_to_recordset(p_updates)
      as x(task_id uuid, planned_start date, planned_end date)
    where task_id is null or planned_start is null or planned_end is null
       or planned_end < planned_start
  ) then
    raise exception 'Une ou plusieurs dates de tâche sont invalides';
  end if;
  if (select count(*) from jsonb_to_recordset(p_updates)
      as x(task_id uuid, planned_start date, planned_end date)) <> v_expected then
    raise exception 'Proposition de planning invalide';
  end if;
  if exists (
    select 1 from jsonb_to_recordset(p_updates)
      as x(task_id uuid, planned_start date, planned_end date)
    group by task_id having count(*) > 1
  ) then
    raise exception 'Une tâche apparaît plusieurs fois dans la proposition';
  end if;
  if exists (
    select 1 from jsonb_to_recordset(p_updates)
      as x(task_id uuid, planned_start date, planned_end date)
    left join public.project_tasks t on t.id = x.task_id and t.project_id = p_project
    where t.id is null
  ) then
    raise exception 'La proposition contient une tâche extérieure au projet';
  end if;

  update public.project_tasks t
     set planned_start = x.planned_start,
         planned_end = x.planned_end,
         updated_at = now()
    from jsonb_to_recordset(p_updates)
      as x(task_id uuid, planned_start date, planned_end date)
   where t.id = x.task_id and t.project_id = p_project;
  get diagnostics v_updated = row_count;
  if v_updated <> v_expected then
    raise exception 'Toutes les dates proposées n''ont pas été appliquées';
  end if;

  update public.projects
     set forecast_end = p_forecast_end,
         forecast_delay_days = coalesce(p_delay_days, 0),
         forecast_calculated_at = now(),
         updated_at = now()
   where id = p_project;

  return v_updated;
end;
$$;

revoke all on function public.apply_project_schedule_proposal(uuid, jsonb, date, integer) from public;
grant execute on function public.apply_project_schedule_proposal(uuid, jsonb, date, integer) to authenticated;
