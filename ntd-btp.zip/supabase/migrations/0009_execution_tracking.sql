-- =====================================================================
-- V8 — Suivi d'exécution : journal, photos, incidents, quantités exécutées,
-- dépenses réelles, écarts budgétaires et alertes automatiques.
-- Migration NON destructive.
-- =====================================================================

create or replace function public.can_report_site(p_project uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.projects p
    where p.id = p_project
      and (public.has_org_permission(p.organization_id, 'projects.manage')
        or public.has_org_permission(p.organization_id, 'projects.progress.report')
        or public.has_org_permission(p.organization_id, 'projects.schedule.manage')))
$$;
create or replace function public.can_manage_project_expenses(p_project uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.can_manage_project_finance(p_project) or public.can_manage_project(p_project)
$$;
revoke all on function public.can_report_site(uuid) from public;
revoke all on function public.can_manage_project_expenses(uuid) from public;
grant execute on function public.can_report_site(uuid) to authenticated;
grant execute on function public.can_manage_project_expenses(uuid) to authenticated;

-- ---------------------------------------------------------------- Journal de chantier
create table public.site_diaries (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  diary_date date not null default current_date,
  weather text,
  workforce_count integer check (workforce_count is null or workforce_count >= 0),
  trades_mobilized text,
  teams text,
  equipment text,
  work_done text,
  materials_used text,
  incidents_note text,
  delays_note text,
  observations text,
  responsible_user_id uuid references auth.users(id) default auth.uid(),
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id, diary_date)
);
create index idx_site_diaries_project on public.site_diaries(project_id, diary_date desc);

-- ---------------------------------------------------------------- Photos
create table public.site_photos (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  diary_id uuid references public.site_diaries(id) on delete set null,
  work_package_id uuid references public.work_packages(id) on delete set null,
  trade_id uuid references public.trades(id) on delete set null,
  category text not null default 'during' check (category in ('before','during','after','anomaly')),
  caption text,
  storage_path text not null,
  taken_at timestamptz not null default now(),
  uploaded_by uuid not null default auth.uid() references auth.users(id)
);
create index idx_site_photos_project on public.site_photos(project_id, taken_at desc);

-- ---------------------------------------------------------------- Incidents
create table public.site_incidents (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  incident_date date not null default current_date,
  title text not null,
  description text,
  severity text not null default 'medium' check (severity in ('low','medium','high','critical')),
  status text not null default 'open' check (status in ('open','in_progress','resolved')),
  work_package_id uuid references public.work_packages(id) on delete set null,
  responsible_user_id uuid references auth.users(id),
  resolved_at timestamptz,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_site_incidents_project on public.site_incidents(project_id, status);

create or replace function public.site_incidents_before()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  if new.status = 'resolved' then
    if tg_op = 'INSERT' then
      new.resolved_at := now();
    elsif old.status <> 'resolved' then
      new.resolved_at := now();
    end if;
  else
    new.resolved_at := null;
  end if;
  return new;
end $$;
create trigger site_incidents_before_trigger before insert or update on public.site_incidents
  for each row execute function public.site_incidents_before();
create trigger site_diaries_touch before update on public.site_diaries
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------- Quantités exécutées
create table public.progress_records (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  budget_line_id uuid not null references public.project_budget_lines(id) on delete cascade,
  record_date date not null default current_date,
  quantity numeric(18,3) not null check (quantity > 0),
  status text not null default 'declared' check (status in ('declared','validated','rejected')),
  notes text,
  diary_id uuid references public.site_diaries(id) on delete set null,
  declared_by uuid not null default auth.uid() references auth.users(id),
  validated_by uuid references auth.users(id),
  validated_at timestamptz,
  created_at timestamptz not null default now()
);
create index idx_progress_records_project on public.progress_records(project_id, status);
create index idx_progress_records_line on public.progress_records(budget_line_id);

create or replace function public.progress_records_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_line record;
begin
  select project_id, is_baseline, category into v_line from public.project_budget_lines where id = new.budget_line_id;
  if not found or v_line.project_id <> new.project_id then raise exception 'Ligne de budget invalide pour ce projet'; end if;
  if not v_line.is_baseline or v_line.category = 'fees' then
    raise exception 'Les quantités se déclarent sur les lignes du budget initial (devis validé)';
  end if;
  return new;
end $$;
create trigger progress_records_guard_trigger before insert on public.progress_records
  for each row execute function public.progress_records_guard();

create or replace function public.review_progress_record(p_record uuid, p_validate boolean)
returns void language plpgsql security definer set search_path = public as $$
declare v_project uuid; v_status text;
begin
  select project_id, status into v_project, v_status from public.progress_records where id = p_record for update;
  if v_project is null then raise exception 'Déclaration introuvable'; end if;
  if not (public.can_manage_project(v_project) or public.can_manage_project_study(v_project)) then
    raise exception 'Droits insuffisants pour valider les quantités';
  end if;
  if v_status <> 'declared' then raise exception 'Cette déclaration a déjà été traitée'; end if;
  update public.progress_records
     set status = case when p_validate then 'validated' else 'rejected' end,
         validated_by = auth.uid(), validated_at = now()
   where id = p_record;
end $$;
revoke all on function public.review_progress_record(uuid, boolean) from public;
grant execute on function public.review_progress_record(uuid, boolean) to authenticated;

-- ---------------------------------------------------------------- Dépenses réelles
create table public.project_expenses (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  expense_date date not null default current_date,
  work_package_id uuid references public.work_packages(id) on delete set null,
  trade_id uuid references public.trades(id) on delete set null,
  budget_line_id uuid references public.project_budget_lines(id) on delete set null,
  designation text not null,
  quantity numeric(18,3) not null default 1 check (quantity >= 0),
  unit_price numeric(18,2) not null default 0 check (unit_price >= 0),
  amount numeric(18,2) generated always as (round(quantity * unit_price, 2)) stored,
  supplier text,
  payment_method text not null default 'cash' check (payment_method in ('cash','transfer','mobile_money','cheque','card','other')),
  paid_amount numeric(18,2) not null default 0 check (paid_amount >= 0),
  remaining numeric(18,2) generated always as (greatest(round(quantity * unit_price, 2) - paid_amount, 0)) stored,
  payment_status text generated always as (
    case when paid_amount <= 0 then 'committed'
         when paid_amount < round(quantity * unit_price, 2) then 'partial'
         else 'paid' end) stored,
  receipt_path text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (paid_amount <= round(quantity * unit_price, 2))
);
create index idx_project_expenses_project on public.project_expenses(project_id, expense_date desc);

create or replace function public.project_expenses_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.work_package_id is not null and not exists
     (select 1 from public.work_packages where id = new.work_package_id and project_id = new.project_id) then
    raise exception 'Le lot choisi n''appartient pas à ce projet';
  end if;
  if new.budget_line_id is not null and not exists
     (select 1 from public.project_budget_lines where id = new.budget_line_id and project_id = new.project_id) then
    raise exception 'La ligne de budget choisie n''appartient pas à ce projet';
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger project_expenses_guard_trigger before insert or update on public.project_expenses
  for each row execute function public.project_expenses_guard();

-- ---------------------------------------------------------------- Alertes
create table public.project_alerts (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  rule_key text not null,
  severity text not null check (severity in ('info','warning','critical')),
  title text not null,
  message text,
  is_active boolean not null default true,
  first_raised_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id, rule_key)
);

-- ---------------------------------------------------------------- Calcul des écarts
create or replace function public._project_variance(p_project uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_has_base boolean; v_budget_initial numeric := 0; v_budget numeric := 0;
  v_committed numeric := 0; v_paid numeric := 0; v_remaining numeric := 0;
  v_ev numeric := 0; v_plan numeric := 0; v_phys numeric; v_fin numeric; v_eac numeric; v_prog numeric;
  v_lots jsonb; v_trades jsonb;
begin
  select exists (select 1 from public.project_budget_lines where project_id = p_project and is_baseline) into v_has_base;
  select coalesce(sum(estimated_amount), 0) into v_budget_initial
    from public.project_budget_lines where project_id = p_project and (not v_has_base or is_baseline);
  select coalesce((select total_amount from public.estimates where project_id = p_project and status = 'approved' limit 1), v_budget_initial)
    into v_budget;
  select coalesce(sum(amount), 0), coalesce(sum(paid_amount), 0), coalesce(sum(remaining), 0)
    into v_committed, v_paid, v_remaining from public.project_expenses where project_id = p_project;
  select coalesce(sum(least(coalesce(d.done, 0), l.quantity) * l.unit_price), 0), coalesce(sum(l.quantity * l.unit_price), 0)
    into v_ev, v_plan
    from public.project_budget_lines l
    left join (select budget_line_id, sum(quantity) as done from public.progress_records
               where project_id = p_project and status = 'validated' group by budget_line_id) d on d.budget_line_id = l.id
    where l.project_id = p_project and l.is_baseline and l.category <> 'fees';
  select progress_percent into v_prog from public.projects where id = p_project;
  v_phys := case when v_plan > 0 then round(v_ev * 100 / v_plan, 1) else coalesce(v_prog, 0) end;
  v_fin := case when v_budget > 0 then round(v_committed * 100 / v_budget, 1) else null end;
  v_eac := case when v_committed = 0 then v_budget when v_phys >= 5 then round(v_committed * 100 / v_phys, 0) else null end;

  select coalesce(jsonb_agg(s.x order by s.x->>'name'), '[]'::jsonb) into v_lots from (
    select jsonb_build_object(
      'id', w.id, 'name', w.name,
      'budget', coalesce(b.budget, 0), 'committed', coalesce(e.committed, 0), 'paid', coalesce(e.paid, 0),
      'balance', coalesce(b.budget, 0) - coalesce(e.committed, 0),
      'consumption_pct', case when coalesce(b.budget, 0) > 0 then round(coalesce(e.committed, 0) * 100 / b.budget, 1) end,
      'physical_pct', case when coalesce(b.plan, 0) > 0 then round(coalesce(b.ev, 0) * 100 / b.plan, 1) end) as x
    from public.work_packages w
    left join (
      select l.work_package_id as wp, sum(l.estimated_amount) as budget,
             sum(case when l.is_baseline and l.category <> 'fees' then l.quantity * l.unit_price else 0 end) as plan,
             sum(case when l.is_baseline and l.category <> 'fees' then least(coalesce(d.done, 0), l.quantity) * l.unit_price else 0 end) as ev
      from public.project_budget_lines l
      left join (select budget_line_id, sum(quantity) as done from public.progress_records
                 where project_id = p_project and status = 'validated' group by budget_line_id) d on d.budget_line_id = l.id
      where l.project_id = p_project and (not v_has_base or l.is_baseline) and l.work_package_id is not null
      group by l.work_package_id) b on b.wp = w.id
    left join (
      select work_package_id as wp, sum(amount) as committed, sum(paid_amount) as paid
      from public.project_expenses where project_id = p_project and work_package_id is not null
      group by work_package_id) e on e.wp = w.id
    where w.project_id = p_project) s;

  select coalesce(jsonb_agg(s.x order by s.x->>'name'), '[]'::jsonb) into v_trades from (
    select jsonb_build_object(
      'trade_id', k.trade_id, 'name', coalesce(t.name, 'Non affecté'),
      'budget', coalesce(b.budget, 0), 'committed', coalesce(e.committed, 0),
      'balance', coalesce(b.budget, 0) - coalesce(e.committed, 0),
      'consumption_pct', case when coalesce(b.budget, 0) > 0 then round(coalesce(e.committed, 0) * 100 / b.budget, 1) end) as x
    from (
      select u.trade_id from (
        select w.trade_id from public.project_budget_lines l join public.work_packages w on w.id = l.work_package_id
         where l.project_id = p_project
        union
        select coalesce(x.trade_id, w2.trade_id) from public.project_expenses x
          left join public.work_packages w2 on w2.id = x.work_package_id where x.project_id = p_project) u
      group by u.trade_id) k
    left join public.trades t on t.id = k.trade_id
    left join (
      select w.trade_id as tid, sum(l.estimated_amount) as budget
      from public.project_budget_lines l join public.work_packages w on w.id = l.work_package_id
      where l.project_id = p_project and (not v_has_base or l.is_baseline) group by w.trade_id) b on b.tid is not distinct from k.trade_id
    left join (
      select coalesce(x.trade_id, w3.trade_id) as tid, sum(x.amount) as committed
      from public.project_expenses x left join public.work_packages w3 on w3.id = x.work_package_id
      where x.project_id = p_project group by coalesce(x.trade_id, w3.trade_id)) e on e.tid is not distinct from k.trade_id) s;

  return jsonb_build_object(
    'budget_initial', v_budget_initial, 'budget', v_budget,
    'committed', v_committed, 'paid', v_paid, 'remaining_to_pay', v_remaining,
    'balance', v_budget - v_committed, 'consumption_pct', v_fin,
    'physical_pct', v_phys, 'physical_source', case when v_plan > 0 then 'quantities' else 'tasks' end,
    'forecast_final_cost', v_eac, 'lots', v_lots, 'trades', v_trades);
end $$;
revoke all on function public._project_variance(uuid) from public;

create or replace function public.get_project_variance(p_project uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not (public.can_view_project_budget(p_project) or public.can_manage_project_expenses(p_project)) then
    raise exception 'Droits insuffisants pour consulter les écarts financiers';
  end if;
  return public._project_variance(p_project);
end $$;
revoke all on function public.get_project_variance(uuid) from public;
grant execute on function public.get_project_variance(uuid) to authenticated;

-- ---------------------------------------------------------------- Règles d'alerte
create or replace function public._put_alert(p_project uuid, p_key text, p_severity text, p_title text, p_message text)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.project_alerts(project_id, rule_key, severity, title, message)
  values (p_project, p_key, p_severity, p_title, p_message)
  on conflict (project_id, rule_key) do update
    set severity = excluded.severity, title = excluded.title, message = excluded.message,
        first_raised_at = case when public.project_alerts.is_active then public.project_alerts.first_raised_at else now() end,
        is_active = true, updated_at = now();
end $$;
revoke all on function public._put_alert(uuid, text, text, text, text) from public;

create or replace function public._refresh_alerts_core(p_project uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  v jsonb; v_keys text[] := '{}'; r record;
  v_budget numeric; v_committed numeric; v_cons numeric; v_phys numeric; v_eac numeric;
  v_late integer; v_maxlate integer; v_delay integer; v_open integer; v_crit integer; v_stage text; v_last date;
begin
  v := public._project_variance(p_project);
  v_budget := (v->>'budget')::numeric;
  v_committed := (v->>'committed')::numeric;
  v_cons := (v->>'consumption_pct')::numeric;
  v_phys := (v->>'physical_pct')::numeric;
  v_eac := (v->>'forecast_final_cost')::numeric;

  if v_budget > 0 and v_committed > v_budget then
    perform public._put_alert(p_project, 'budget_total', 'critical', 'Dépassement du budget',
      'Les dépenses engagées (' || round(v_committed) || ') dépassent le budget (' || round(v_budget) || ').');
    v_keys := array_append(v_keys, 'budget_total');
  elsif v_budget > 0 and v_cons >= 90 then
    perform public._put_alert(p_project, 'budget_total', 'warning', 'Budget presque consommé',
      'Le budget est consommé à ' || v_cons || ' %.');
    v_keys := array_append(v_keys, 'budget_total');
  end if;

  for r in select * from jsonb_to_recordset(v->'lots') as x(id uuid, name text, budget numeric, committed numeric, consumption_pct numeric) loop
    if r.budget > 0 and r.consumption_pct > 100 then
      perform public._put_alert(p_project, 'lot:' || r.id, 'critical', 'Lot en dépassement : ' || r.name,
        'Consommation du lot : ' || r.consumption_pct || ' % du budget.');
      v_keys := array_append(v_keys, ('lot:' || r.id));
    elsif r.budget > 0 and r.consumption_pct >= 90 then
      perform public._put_alert(p_project, 'lot:' || r.id, 'warning', 'Lot presque consommé : ' || r.name,
        'Consommation du lot : ' || r.consumption_pct || ' % du budget.');
      v_keys := array_append(v_keys, ('lot:' || r.id));
    end if;
  end loop;

  if (v->>'physical_source') = 'quantities' and v_cons is not null and v_phys is not null and v_cons - v_phys > 15 then
    perform public._put_alert(p_project, 'cost_vs_progress', 'warning', 'Dépenses en avance sur l''avancement',
      'Consommation financière ' || v_cons || ' % pour un avancement physique de ' || v_phys || ' %.');
    v_keys := array_append(v_keys, 'cost_vs_progress');
  end if;

  if v_eac is not null and v_budget > 0 and v_eac > v_budget * 1.05 then
    perform public._put_alert(p_project, 'eac_overrun', 'warning', 'Risque de dépassement du coût final',
      'Coût final prévisionnel : ' || round(v_eac) || ' pour un budget de ' || round(v_budget) || '.');
    v_keys := array_append(v_keys, 'eac_overrun');
  end if;

  select count(*), coalesce(max(current_date - planned_end), 0) into v_late, v_maxlate
    from public.project_tasks where project_id = p_project and planned_end < current_date and progress_percent < 100;
  if v_late > 0 then
    perform public._put_alert(p_project, 'late_tasks', case when v_maxlate > 14 then 'critical' else 'warning' end,
      'Tâches en retard', v_late || ' tâche(s) dépassent leur date de fin prévue (retard maximal : ' || v_maxlate || ' jours).');
    v_keys := array_append(v_keys, 'late_tasks');
  end if;

  select coalesce(forecast_delay_days, 0) into v_delay from public.projects where id = p_project;
  if v_delay > 0 then
    perform public._put_alert(p_project, 'forecast_delay', case when v_delay > 30 then 'critical' else 'warning' end,
      'Retard prévisionnel', 'Le planning prévoit une fin du projet avec ' || v_delay || ' jour(s) de retard.');
    v_keys := array_append(v_keys, 'forecast_delay');
  end if;

  select count(*), count(*) filter (where severity in ('high','critical')) into v_open, v_crit
    from public.site_incidents where project_id = p_project and status <> 'resolved';
  if v_open > 0 then
    perform public._put_alert(p_project, 'open_incidents', case when v_crit > 0 then 'critical' else 'info' end,
      'Incidents ouverts', v_open || ' incident(s) non résolu(s) dont ' || v_crit || ' grave(s).');
    v_keys := array_append(v_keys, 'open_incidents');
  end if;

  select current_stage into v_stage from public.project_lifecycle where project_id = p_project;
  select max(diary_date) into v_last from public.site_diaries where project_id = p_project;
  if v_stage = 'execution' and (v_last is null or v_last < current_date - 3) then
    perform public._put_alert(p_project, 'no_diary', 'info', 'Journal de chantier non à jour',
      case when v_last is null then 'Aucun journal n''a encore été rédigé.' else 'Dernier journal : ' || v_last || '.' end);
    v_keys := array_append(v_keys, 'no_diary');
  end if;

  update public.project_alerts set is_active = false, updated_at = now()
   where project_id = p_project and is_active and not (rule_key = any (v_keys));
end $$;
revoke all on function public._refresh_alerts_core(uuid) from public;

create or replace function public.refresh_project_alerts(p_project uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_access_project(p_project) then raise exception 'Accès refusé'; end if;
  perform public._refresh_alerts_core(p_project);
end $$;
revoke all on function public.refresh_project_alerts(uuid) from public;
grant execute on function public.refresh_project_alerts(uuid) to authenticated;

create or replace function public.refresh_alerts_trigger()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public._refresh_alerts_core(case when tg_op = 'DELETE' then old.project_id else new.project_id end);
  return null;
end $$;
create trigger project_expenses_alerts after insert or update or delete on public.project_expenses
  for each row execute function public.refresh_alerts_trigger();
create trigger progress_records_alerts after insert or update or delete on public.progress_records
  for each row execute function public.refresh_alerts_trigger();
create trigger site_incidents_alerts after insert or update or delete on public.site_incidents
  for each row execute function public.refresh_alerts_trigger();

-- Traçabilité
create trigger audit_site_diaries after insert or update or delete on public.site_diaries
  for each row execute function public.audit_project_record();
create trigger audit_project_expenses after insert or update or delete on public.project_expenses
  for each row execute function public.audit_project_record();
create trigger audit_progress_records after insert or update on public.progress_records
  for each row execute function public.audit_project_record();
create trigger audit_site_incidents after insert or update or delete on public.site_incidents
  for each row execute function public.audit_project_record();

-- ---------------------------------------------------------------- Sécurité (RLS)
alter table public.site_diaries enable row level security;
alter table public.site_photos enable row level security;
alter table public.site_incidents enable row level security;
alter table public.progress_records enable row level security;
alter table public.project_expenses enable row level security;
alter table public.project_alerts enable row level security;

create policy site_diaries_read on public.site_diaries for select to authenticated using (public.can_access_project(project_id));
create policy site_diaries_write on public.site_diaries for all to authenticated
  using (public.can_report_site(project_id)) with check (public.can_report_site(project_id));
create policy site_photos_read on public.site_photos for select to authenticated using (public.can_access_project(project_id));
create policy site_photos_write on public.site_photos for all to authenticated
  using (public.can_report_site(project_id)) with check (public.can_report_site(project_id));
create policy site_incidents_read on public.site_incidents for select to authenticated using (public.can_access_project(project_id));
create policy site_incidents_write on public.site_incidents for all to authenticated
  using (public.can_report_site(project_id)) with check (public.can_report_site(project_id));
create policy progress_records_read on public.progress_records for select to authenticated using (public.can_access_project(project_id));
create policy progress_records_insert on public.progress_records for insert to authenticated
  with check (public.can_report_site(project_id) and declared_by = auth.uid() and status = 'declared');
create policy progress_records_delete on public.progress_records for delete to authenticated
  using (public.can_report_site(project_id) and status = 'declared');
create policy project_expenses_read on public.project_expenses for select to authenticated
  using (public.can_view_project_budget(project_id) or public.can_manage_project_expenses(project_id));
create policy project_expenses_write on public.project_expenses for all to authenticated
  using (public.can_manage_project_expenses(project_id)) with check (public.can_manage_project_expenses(project_id));
create policy project_alerts_read on public.project_alerts for select to authenticated using (public.can_access_project(project_id));

-- ---------------------------------------------------------------- Stockage des photos et justificatifs
insert into storage.buckets (id, name, public) values ('project-files', 'project-files', false) on conflict (id) do nothing;

create policy project_files_read on storage.objects for select to authenticated
  using (bucket_id = 'project-files' and case
    when (storage.foldername(name))[1] ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    then public.can_access_project(((storage.foldername(name))[1])::uuid) else false end);
create policy project_files_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'project-files' and case
    when (storage.foldername(name))[1] ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    then public.can_report_site(((storage.foldername(name))[1])::uuid) else false end);
create policy project_files_delete on storage.objects for delete to authenticated
  using (bucket_id = 'project-files' and case
    when (storage.foldername(name))[1] ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    then public.can_report_site(((storage.foldername(name))[1])::uuid) else false end);

grant select, insert, update, delete on all tables in schema public to authenticated;
grant all on all tables in schema public to service_role;
notify pgrst, 'reload schema';
