import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const allowedRoles = new Set([
  'admin', 'project_manager', 'engineer', 'site_manager', 'accountant',
  'storekeeper', 'qse_manager', 'client', 'subcontractor', 'member',
]);
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Méthode non autorisée' }, 405);

  const authorization = req.headers.get('Authorization');
  if (!authorization?.startsWith('Bearer ')) return json({ error: 'Authentification requise' }, 401);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const redirectUrl = Deno.env.get('APP_INVITE_REDIRECT_URL');
  if (!supabaseUrl || !anonKey || !serviceKey || !redirectUrl) {
    return json({ error: 'Configuration serveur incomplète' }, 500);
  }

  const caller = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: authData, error: authError } = await caller.auth.getUser();
  if (authError || !authData.user) return json({ error: 'Session invalide' }, 401);

  let payload: { organization_id?: string; email?: string; role?: string };
  try { payload = await req.json(); } catch { return json({ error: 'Corps JSON invalide' }, 400); }
  const organizationId = payload.organization_id?.trim();
  const email = payload.email?.trim().toLowerCase();
  const role = payload.role?.trim();
  if (!organizationId || !email || !role || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return json({ error: 'Organisation, adresse e-mail et rôle valides obligatoires' }, 400);
  }
  if (!allowedRoles.has(role)) return json({ error: 'Ce rôle ne peut pas être attribué par invitation' }, 400);

  const { data: allowed, error: permissionError } = await caller.rpc('has_org_permission', {
    p_org: organizationId, p_permission: 'members.manage',
  });
  if (permissionError || allowed !== true) return json({ error: 'Droits insuffisants pour inviter un membre' }, 403);

  const { data: organization, error: organizationError } = await admin
    .from('organizations').select('id').eq('id', organizationId).maybeSingle();
  if (organizationError || !organization) return json({ error: 'Organisation introuvable' }, 404);

  // Recherche paginée pour éviter de manquer un compte existant.
  let matchingUser: { id: string } | null = null;
  for (let page = 1; page <= 20 && !matchingUser; page++) {
    const { data: authUsers, error: usersError } = await admin.auth.admin.listUsers({ page, perPage: 1000 });
    if (usersError) return json({ error: 'Vérification du compte impossible' }, 500);
    matchingUser = authUsers.users.find((u) => (u.email ?? '').toLowerCase() === email) ?? null;
    if (authUsers.users.length < 1000) break;
  }
  if (matchingUser) {
    const { data: membership, error: memberCheckError } = await admin
      .from('organization_memberships').select('id').eq('organization_id', organizationId)
      .eq('user_id', matchingUser.id).maybeSingle();
    if (memberCheckError) return json({ error: 'Vérification de l’adhésion impossible' }, 500);
    if (membership) return json({ error: 'Cette adresse est déjà membre de l’organisation' }, 409);
  }

  const { data: invitation, error: invitationError } = await admin
    .from('organization_invitations')
    .upsert({
      organization_id: organizationId, email, role,
      invited_by: authData.user.id,
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      accepted_at: null,
    }, { onConflict: 'organization_id,email' })
    .select('id,expires_at').single();
  if (invitationError || !invitation) return json({ error: 'Création de l’invitation impossible' }, 500);

  if (!matchingUser) {
    const { error: mailError } = await admin.auth.admin.inviteUserByEmail(email, {
      redirectTo: redirectUrl,
      data: { invitation_id: invitation.id },
    });
    if (mailError) {
      await admin.from('organization_invitations').delete().eq('id', invitation.id);
      return json({ error: `Envoi de l’invitation impossible : ${mailError.message}` }, 502);
    }
  }

  return json({
    invitation_id: invitation.id,
    expires_at: invitation.expires_at,
    email_sent: !matchingUser,
    message: matchingUser
      ? 'Invitation créée. Le membre doit se connecter avec cette adresse puis ouvrir ses invitations reçues.'
      : 'Invitation envoyée par e-mail. Elle expire dans 7 jours.',
  }, 201);
});
