-- Catalogue de départ. Les administrateurs pourront ajouter d'autres métiers.
with s(code, name, description) as (
  values
  ('STUDIES','Études, architecture et ingénierie','Conception, études et ingénierie'),
  ('BUILDING','Bâtiments et gros œuvre','Construction et structure des bâtiments'),
  ('FINISH','Second œuvre et finitions','Aménagement et finitions'),
  ('ELECTRIC','Électricité et énergie','Installations électriques et production énergétique'),
  ('FLUIDS','Plomberie et fluides','Eau, gaz, hydraulique et assainissement'),
  ('HVAC','Climatisation, ventilation et froid','Génie climatique et réfrigération'),
  ('PUBLIC','Travaux publics et infrastructures','Routes, ouvrages et réseaux'),
  ('INDUSTRY','Industrie et maintenance','Installations et maintenance industrielles'),
  ('SECURITY','Sécurité et télécommunications','Protection, sûreté et communications'),
  ('ENVIRONMENT','Environnement et aménagement','Environnement, déchets et paysage')
)
insert into public.sectors(code, name, description)
select code, name, description from s
on conflict (code) do nothing;

with f(sector_code, code, name) as (
  values
  ('STUDIES','ARCH','Architecture et conception'),
  ('STUDIES','BET','Bureaux d’études techniques'),
  ('STUDIES','SURVEY','Topographie et géotechnique'),
  ('BUILDING','EARTH','Terrassement et fondations'),
  ('BUILDING','STRUCT','Structure et béton armé'),
  ('BUILDING','MASON','Maçonnerie et charpente'),
  ('FINISH','INTERIOR','Aménagement intérieur'),
  ('FINISH','JOINERY','Menuiserie et serrurerie'),
  ('ELECTRIC','POWER','Électricité bâtiment et industrielle'),
  ('ELECTRIC','RENEW','Énergies renouvelables'),
  ('FLUIDS','PLUMB','Plomberie et sanitaire'),
  ('FLUIDS','WATER','Hydraulique et traitement des eaux'),
  ('HVAC','AIR','Climatisation et ventilation'),
  ('HVAC','REFRIG','Froid et réfrigération'),
  ('PUBLIC','ROAD','Routes et voiries'),
  ('PUBLIC','NETWORK','VRD et réseaux'),
  ('INDUSTRY','MECH','Mécanique et montage industriel'),
  ('INDUSTRY','PIPING','Tuyauterie et chaudronnerie'),
  ('SECURITY','FIRE','Sécurité incendie'),
  ('SECURITY','ICT','Télécommunications et réseaux'),
  ('ENVIRONMENT','WASTE','Déchets et dépollution'),
  ('ENVIRONMENT','LAND','Espaces verts et paysage')
)
insert into public.trade_families(sector_id, code, name)
select s.id, f.code, f.name
from f join public.sectors s on s.code = f.sector_code
on conflict (sector_id, name) do nothing;

with t(family_code, name) as (
  values
  ('ARCH','Architecte'),('BET','Ingénieur génie civil'),('BET','Ingénieur structure'),
  ('BET','Économiste de la construction'),('SURVEY','Géomètre topographe'),
  ('SURVEY','Géotechnicien'),('EARTH','Terrassier'),('EARTH','Fondations spéciales'),
  ('STRUCT','Coffreur'),('STRUCT','Ferrailleur'),('STRUCT','Bétonneur'),
  ('MASON','Maçon'),('MASON','Charpentier bois'),('MASON','Charpentier métallique'),
  ('INTERIOR','Plâtrier'),('INTERIOR','Carreleur'),('INTERIOR','Peintre'),
  ('INTERIOR','Étanchéiste'),('JOINERY','Menuisier bois'),('JOINERY','Menuisier aluminium'),
  ('JOINERY','Vitrier'),('JOINERY','Serrurier-métallier'),
  ('POWER','Électricien bâtiment'),('POWER','Électricien industriel'),
  ('POWER','Monteur réseaux électriques'),('POWER','Automaticien'),
  ('RENEW','Installateur photovoltaïque'),('PLUMB','Plombier'),('PLUMB','Installateur sanitaire'),
  ('WATER','Technicien hydraulique'),('WATER','Foreur'),('WATER','Technicien traitement des eaux'),
  ('AIR','Frigoriste'),('AIR','Technicien climatisation'),('AIR','Ventiliste'),
  ('REFRIG','Technicien froid commercial'),('ROAD','Constructeur routier'),
  ('ROAD','Conducteur d’engins'),('NETWORK','Canalisateur'),('NETWORK','Poseur de réseaux'),
  ('MECH','Mécanicien industriel'),('MECH','Monteur mécanicien'),('PIPING','Tuyauteur'),
  ('PIPING','Chaudronnier'),('FIRE','Installateur système incendie'),
  ('ICT','Technicien télécoms'),('ICT','Installateur fibre optique'),
  ('WASTE','Technicien gestion des déchets'),('LAND','Paysagiste')
)
insert into public.trades(family_id, name)
select f.id, t.name
from t join public.trade_families f on f.code = t.family_code
on conflict (family_id, name) do nothing;
