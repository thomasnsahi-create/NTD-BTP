-- Vérifications du planning Gantt (après migrations 0001 à 0004)
-- 1. Tâches ayant des dates inversées (doit retourner zéro ligne).
select id, project_id, name, planned_start, planned_end
from public.project_tasks
where planned_start is not null and planned_end is not null
  and planned_end < planned_start;

-- 2. Dépendances dont les tâches ne sont pas dans le même projet (zéro ligne attendu).
select d.task_id, d.depends_on_task_id
from public.project_task_dependencies d
join public.project_tasks t on t.id = d.task_id
join public.project_tasks p on p.id = d.depends_on_task_id
where t.project_id <> p.project_id;

-- 3. Résumé de planning par projet.
select project_id, count(*) as total_tasks,
       count(*) filter (where planned_start is not null and planned_end is not null) as scheduled_tasks,
       count(*) filter (where planned_end < current_date and progress_percent < 100 and status <> 'cancelled') as late_tasks,
       round(avg(progress_percent), 1) as average_progress
from public.project_tasks
group by project_id
order by project_id;
