-- Vérifications de présence après application de 0004_project_management.sql.
select to_regclass('public.project_sectors') as project_sectors,
       to_regclass('public.project_phases') as project_phases,
       to_regclass('public.project_tasks') as project_tasks,
       to_regclass('public.project_task_dependencies') as project_task_dependencies,
       to_regclass('public.project_budget_lines') as project_budget_lines,
       to_regclass('public.project_progress_updates') as project_progress_updates;

select c.relname as table_name, c.relrowsecurity as rls_enabled
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname in (
  'project_sectors','project_phases','project_tasks','project_task_dependencies',
  'project_budget_lines','project_progress_updates'
)
order by c.relname;

select tablename, policyname, cmd
from pg_policies
where schemaname='public' and tablename in (
  'project_sectors','project_phases','project_tasks','project_task_dependencies',
  'project_budget_lines','project_progress_updates','work_packages','project_members'
)
order by tablename, policyname;

select code, label, module
from public.permission_catalog
where code like 'projects.%' or code like 'finance.%'
order by module, code;
