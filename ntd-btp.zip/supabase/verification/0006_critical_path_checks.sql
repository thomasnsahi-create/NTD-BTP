-- Après application de 0006 : contrôler les prévisions enregistrées.
select id, code, name, planned_end, forecast_end, forecast_delay_days, forecast_calculated_at
from public.projects
where forecast_calculated_at is not null
order by forecast_calculated_at desc;

-- Doit retourner 0 ligne : tâches dont les dates sont incohérentes.
select id, project_id, name, planned_start, planned_end
from public.project_tasks
where planned_start is not null and planned_end is not null
  and planned_end < planned_start;
