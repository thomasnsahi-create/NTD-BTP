-- Contrôles V7 : toutes les requêtes doivent retourner zéro ligne, sauf les synthèses.

-- Affectations dont la tâche ou la ressource ne correspond pas au projet.
select a.id,a.project_id,a.task_id,a.resource_id
from public.project_task_resource_allocations a
left join public.project_tasks t on t.id=a.task_id and t.project_id=a.project_id
left join public.project_resources r on r.id=a.resource_id and r.project_id=a.project_id
where t.id is null or r.id is null;

-- Affectations qui chevauchent une période d'indisponibilité.
select a.id,a.resource_id,a.allocation_start,a.allocation_end,u.reason
from public.project_task_resource_allocations a
join public.project_resource_unavailability u on u.resource_id=a.resource_id
 and daterange(a.allocation_start,a.allocation_end,'[]') && daterange(u.unavailable_start,u.unavailable_end,'[]');

-- Ressources sur-réservées (la capacité simultanée ne doit jamais être dépassée).
select r.id,r.name,d.work_date,sum(a.allocated_capacity) as reserved_capacity,r.capacity
from public.project_resources r
join public.project_task_resource_allocations a on a.resource_id=r.id
cross join lateral generate_series(a.allocation_start,a.allocation_end,interval '1 day') d(work_date)
group by r.id,r.name,d.work_date,r.capacity
having sum(a.allocated_capacity)>r.capacity;

-- Synthèse par projet.
select p.id,p.name,count(distinct c.id) as calendars,count(distinct h.id) as holidays,
 count(distinct r.id) as resources,count(distinct a.id) as allocations
from public.projects p
left join public.project_work_calendars c on c.project_id=p.id
left join public.project_calendar_holidays h on h.calendar_id=c.id
left join public.project_resources r on r.project_id=p.id
left join public.project_task_resource_allocations a on a.project_id=p.id
group by p.id,p.name order by p.name;
