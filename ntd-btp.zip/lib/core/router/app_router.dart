import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../modules/auth/presentation/login_page.dart';
import '../../modules/dashboard/presentation/dashboard_page.dart';
import '../../modules/projects/presentation/projects_page.dart';
import '../../modules/projects/presentation/project_detail_page.dart';
import '../../modules/trades/presentation/trades_page.dart';
import '../../modules/organizations/presentation/organizations_page.dart';
import '../services/auth_service.dart';
import '../ui/immersive.dart';
import '../ui/brand_logo.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  final auth = ref.watch(authStateProvider);
  return GoRouter(
    initialLocation: '/login',
    refreshListenable: auth,
    redirect: (context, state) {
      final loggedIn = auth.currentUser != null;
      final onLogin = state.matchedLocation == '/login';
      if (!loggedIn && !onLogin) return '/login';
      if (loggedIn && onLogin) return '/';
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
      ShellRoute(
        builder: (context, state, child) => AppShell(child: child),
        routes: [
          GoRoute(path: '/', builder: (_, __) => const DashboardPage()),
          GoRoute(path: '/projects', builder: (_, __) => const ProjectsPage()),
          GoRoute(path: '/projects/:projectId', builder: (_, state) => ProjectDetailPage(projectId: state.pathParameters['projectId']!)),
          GoRoute(path: '/trades', builder: (_, __) => const TradesPage()),
          GoRoute(path: '/organizations', builder: (_, __) => const OrganizationsPage()),
        ],
      ),
    ],
  );
});

class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).uri.path;
    return ValueListenableBuilder<bool>(
      valueListenable: immersiveMode,
      builder: (context, immersive, _) => Scaffold(
      appBar: immersive ? null : AppBar(
        title: const Row(mainAxisSize: MainAxisSize.min, children: [BrandLogo.mark(height: 34), SizedBox(width: 10), Text('BTP MANAGER')]),
        actions: [
          IconButton(
            tooltip: 'Déconnexion',
            onPressed: () => AuthService.instance.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: Row(
        children: [
          if (MediaQuery.sizeOf(context).width >= 700 && !immersive)
            NavigationRail(
              selectedIndex: location.startsWith('/projects') ? 1 : location == '/trades' ? 2 : location == '/organizations' ? 3 : 0,
              onDestinationSelected: (i) {
                final paths = ['/', '/projects', '/trades', '/organizations'];
                context.go(paths[i]);
              },
              labelType: NavigationRailLabelType.all,
              destinations: const [
                NavigationRailDestination(icon: Icon(Icons.dashboard_outlined), label: Text('Accueil')),
                NavigationRailDestination(icon: Icon(Icons.apartment_outlined), label: Text('Projets')),
                NavigationRailDestination(icon: Icon(Icons.construction_outlined), label: Text('Métiers')),
                NavigationRailDestination(icon: Icon(Icons.business_outlined), label: Text('Organisations')),
              ],
            ),
          Expanded(child: child),
        ],
      ),
      bottomNavigationBar: (MediaQuery.sizeOf(context).width < 700 && !immersive)
          ? NavigationBar(
              selectedIndex: location.startsWith('/projects') ? 1 : location == '/trades' ? 2 : location == '/organizations' ? 3 : 0,
              onDestinationSelected: (i) {
                final paths = ['/', '/projects', '/trades', '/organizations'];
                context.go(paths[i]);
              },
              destinations: const [
                NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Accueil'),
                NavigationDestination(icon: Icon(Icons.apartment_outlined), label: 'Projets'),
                NavigationDestination(icon: Icon(Icons.construction_outlined), label: 'Métiers'),
                NavigationDestination(icon: Icon(Icons.business_outlined), label: 'Organisations'),
              ],
            )
          : null,
    ));
  }
}
