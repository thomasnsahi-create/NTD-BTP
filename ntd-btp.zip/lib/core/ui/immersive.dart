import 'package:flutter/foundation.dart';

/// Mode plein écran : masque la barre de titre et la navigation du bas
/// pour laisser toute la place au contenu (ex. fiche d'un projet).
final ValueNotifier<bool> immersiveMode = ValueNotifier<bool>(false);
