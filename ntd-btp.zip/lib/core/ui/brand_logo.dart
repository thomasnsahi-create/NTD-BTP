import 'package:flutter/material.dart';

/// Logo BTP MANAGER.
/// [BrandLogo.full] : logo complet avec nom et signature ; [BrandLogo.mark] : emblème seul (barre d'application).
class BrandLogo extends StatelessWidget {
  const BrandLogo.full({super.key, this.height = 160})
      : _asset = 'assets/images/logo.png',
        _fallbackSize = 64;

  const BrandLogo.mark({super.key, this.height = 32})
      : _asset = 'assets/images/logo_mark.png',
        _fallbackSize = 28;

  final double height;
  final String _asset;
  final double _fallbackSize;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'BTP MANAGER',
      image: true,
      child: Image.asset(
        _asset,
        height: height,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.medium,
        // Si l'image est introuvable (ex. test sans assets), on affiche l'icône d'origine.
        errorBuilder: (_, __, ___) => Icon(Icons.engineering, size: _fallbackSize, color: const Color(0xFF176B45)),
      ),
    );
  }
}
