import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  AuthService._();
  static final instance = AuthService._();
  SupabaseClient get _client => Supabase.instance.client;

  Future<void> signIn(String email, String password) async {
    await _client.auth.signInWithPassword(email: email.trim(), password: password);
    try { await _client.rpc('record_my_session_start'); } catch (_) { /* La connexion ne doit pas échouer si le journal est momentanément indisponible. */ }
  }

  Future<void> signUp(String email, String password) async {
    await _client.auth.signUp(email: email.trim(), password: password);
  }

  Future<void> signOut() => _client.auth.signOut();
}

final authStateProvider = ChangeNotifierProvider<AuthStateNotifier>((ref) {
  return AuthStateNotifier();
});

class AuthStateNotifier extends ChangeNotifier {
  AuthStateNotifier() {
    _subscription = Supabase.instance.client.auth.onAuthStateChange.listen((_) {
      notifyListeners();
    });
  }

  late final StreamSubscription<AuthState> _subscription;
  User? get currentUser => Supabase.instance.client.auth.currentUser;

  @override
  void dispose() {
    unawaited(_subscription.cancel());
    super.dispose();
  }
}
