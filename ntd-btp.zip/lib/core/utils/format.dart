/// Formate un montant avec séparateur de milliers (espace) : 1250000 -> "1 250 000".
String formatAmount(num? value, {int decimals = 0}) {
  final v = (value ?? 0).toDouble();
  final fixed = v.abs().toStringAsFixed(decimals);
  final parts = fixed.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (var i = 0; i < intPart.length; i++) {
    if (i > 0 && (intPart.length - i) % 3 == 0) buf.write(' ');
    buf.write(intPart[i]);
  }
  final sign = v < 0 ? '-' : '';
  if (decimals > 0) return '$sign${buf.toString()},${parts[1]}';
  return '$sign${buf.toString()}';
}

/// Formate une quantité : entier sans décimales, sinon jusqu'à 3 décimales utiles.
String formatQuantity(num? value) {
  final v = (value ?? 0).toDouble();
  if (v == v.roundToDouble()) return v.toStringAsFixed(0);
  var s = v.toStringAsFixed(3);
  while (s.endsWith('0')) {
    s = s.substring(0, s.length - 1);
  }
  return s.replaceAll('.', ',');
}

/// Lit un nombre saisi par l'utilisateur (accepte la virgule et les espaces).
double parseNumber(String text) {
  return double.tryParse(text.trim().replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
}

/// Comme [parseNumber], mais renvoie null si le champ est vide.
double? parseOptionalNumber(String text) {
  if (text.trim().isEmpty) return null;
  return double.tryParse(text.trim().replaceAll(' ', '').replaceAll(',', '.'));
}
