import 'package:flutter/material.dart';

class TradesPage extends StatelessWidget {
  const TradesPage({super.key});

  static const sectors = [
    'Architecture et études',
    'Bâtiments et gros œuvre',
    'Second œuvre et finitions',
    'Électricité et énergie',
    'Plomberie et fluides',
    'Climatisation et froid',
    'Travaux publics et VRD',
    'Industrie et maintenance',
    'Télécommunications et sécurité',
    'Environnement et aménagement',
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Référentiel des métiers', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        const Text('Catalogue initial extensible : les métiers et spécialités sont administrés dans la base de données.'),
        const SizedBox(height: 12),
        ...sectors.map((s) => Card(child: ListTile(
          leading: const Icon(Icons.category_outlined),
          title: Text(s),
          trailing: const Icon(Icons.chevron_right),
        ))),
      ],
    );
  }
}
