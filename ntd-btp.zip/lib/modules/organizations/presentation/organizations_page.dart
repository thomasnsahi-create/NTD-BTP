import 'package:flutter/material.dart';
import '../data/organization_service.dart';

class OrganizationsPage extends StatefulWidget {
  const OrganizationsPage({super.key});
  @override
  State<OrganizationsPage> createState() => _OrganizationsPageState();
}

class _OrganizationsPageState extends State<OrganizationsPage> {
  final _service = OrganizationService.instance;
  late Future<List<Map<String, dynamic>>> _organizations;
  String? _selectedId;
  @override
  void initState() { super.initState(); _organizations = _service.listOrganizations(); }
  void _reload() => setState(() { _organizations = _service.listOrganizations(); });

  Future<void> _inviteMember() async {
    if (_selectedId == null) return;
    final email = TextEditingController();
    String role = 'member';
    const roles = ['admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member'];
    final result = await showDialog<String>(context: context, builder: (context) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      title: const Text('Inviter un utilisateur'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Adresse e-mail')),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: role, decoration: const InputDecoration(labelText: 'Rôle attribué'), items: roles.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(), onChanged: (v) { if (v != null) setDialogState(() => role = v); }),
        const SizedBox(height: 8),
        const Text('Le lien d’invitation expire après 7 jours. Le rôle propriétaire ne peut pas être attribué par invitation.', style: TextStyle(fontSize: 12)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(context, role), child: const Text('Envoyer'))],
    )));
    if (result == null) return;
    try {
      final response = await _service.inviteMember(organizationId: _selectedId!, email: email.text, role: result);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(response['message']?.toString() ?? 'Invitation créée.')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invitation impossible : $e'))); }
  }

  Future<void> _createOrganization() async {
    final name = TextEditingController();
    final legal = TextEditingController();
    final country = TextEditingController(text: 'CM');
    final currency = TextEditingController(text: 'XAF');
    final ok = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Nouvelle organisation'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom de l’organisation *')),
        TextField(controller: legal, decoration: const InputDecoration(labelText: 'Raison sociale (facultatif)')),
        TextField(controller: country, maxLength: 2, decoration: const InputDecoration(labelText: 'Code pays (ex. CM)')),
        TextField(controller: currency, maxLength: 3, decoration: const InputDecoration(labelText: 'Devise (ex. XAF)')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Créer'))],
    ));
    if (ok != true) return;
    try {
      final id = await _service.createOrganization(name: name.text.trim(), legalName: legal.text.trim().isEmpty ? null : legal.text.trim(), countryCode: country.text.trim().toUpperCase(), currency: currency.text.trim().toUpperCase());
      if (!mounted) return;
      setState(() { _selectedId = id; });
      _reload();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Organisation créée. Vous en êtes propriétaire.')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Création impossible : $e'))); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: _organizations,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Impossible de charger les organisations. Vérifiez la migration SQL 0002 et les droits Supabase.\n\n${snapshot.error}')));
        final orgs = snapshot.data ?? [];
        return ListView(padding: const EdgeInsets.all(16), children: [
          const _MyProfilePanel(),
          const SizedBox(height: 12),
          const _MyInvitationsPanel(),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: Text('Organisations', style: Theme.of(context).textTheme.headlineSmall)), FilledButton.icon(onPressed: _createOrganization, icon: const Icon(Icons.add), label: const Text('Créer'))]),
          const SizedBox(height: 8),
          const Text('Une organisation représente une entreprise, une structure ou un groupement qui gère ses propres projets et membres.'),
          const SizedBox(height: 16),
          if (orgs.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Aucune organisation accessible. Créez votre première organisation pour devenir son propriétaire.'))),
          ...orgs.map((o) => Card(child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.business)),
            title: Text(o['name']?.toString() ?? 'Sans nom'),
            subtitle: Text('${o['country_code']} • ${o['default_currency']}  ${o['legal_name'] ?? ''}'),
            trailing: const Icon(Icons.chevron_right),
            selected: _selectedId == o['id'],
            onTap: () => setState(() => _selectedId = o['id'] as String),
          ))),
          if (_selectedId != null) ...[
            const SizedBox(height: 16),
            Row(children: [Expanded(child: Text('Membres de l’organisation', style: Theme.of(context).textTheme.titleLarge)), FilledButton.tonalIcon(onPressed: _inviteMember, icon: const Icon(Icons.person_add_alt_1), label: const Text('Inviter'))]),
            const SizedBox(height: 8),
            _MembersPanel(key: ValueKey(_selectedId), organizationId: _selectedId!, service: _service),
            const SizedBox(height: 16),
            Text('Référentiel des permissions par rôle', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            _RolePermissionsPanel(key: ValueKey('permissions-$_selectedId'), organizationId: _selectedId!, service: _service),
            const SizedBox(height: 16),
            Text('Journal d’activité', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            _AuditPanel(key: ValueKey('audit-$_selectedId'), organizationId: _selectedId!, service: _service),
          ],
        ]);
      },
    ),
  );
}

class _MembersPanel extends StatefulWidget {
  const _MembersPanel({super.key, required this.organizationId, required this.service});
  final String organizationId;
  final OrganizationService service;
  @override
  State<_MembersPanel> createState() => _MembersPanelState();
}
class _MembersPanelState extends State<_MembersPanel> {
  late Future<List<Map<String, dynamic>>> _members;
  static const roles = ['owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member'];
  @override
  void initState() { super.initState(); _members = widget.service.listMembers(widget.organizationId); }
  void _reload() => setState(() => _members = widget.service.listMembers(widget.organizationId));
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
    future: _members,
    builder: (context, s) {
      if (s.connectionState == ConnectionState.waiting) return const LinearProgressIndicator();
      if (s.hasError) return Text('Erreur de chargement des membres : ${s.error}');
      final members = s.data ?? [];
      if (members.isEmpty) return const Text('Aucun membre trouvé.');
      return Column(children: members.map((m) {
        final profile = m['profile'] as Map<String, dynamic>?;
        final label = (profile?['full_name'] as String?)?.trim();
        final title = (label == null || label.isEmpty) ? 'Utilisateur ${m['user_id'].toString().substring(0,8)}' : label;
        return Card(child: ListTile(
          leading: const Icon(Icons.person_outline), title: Text(title),
          subtitle: Text('${m['role']} • ${m['status']}'),
          trailing: PopupMenuButton<String>(tooltip: 'Gérer le membre', onSelected: (action) async {
            try {
              final isStatus = action.startsWith('status:');
              final role = isStatus ? m['role'] as String : action;
              final status = isStatus ? action.substring(7) : m['status'] as String;
              await widget.service.updateMember(membershipId: m['id'], role: role, status: status);
              _reload();
            } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Modification refusée : $e'))); }
          }, itemBuilder: (_) => [
            const PopupMenuItem(enabled: false, child: Text('Changer le rôle')),
            ...roles.map((r) => PopupMenuItem(value: r, child: Text(r))),
            const PopupMenuDivider(),
            PopupMenuItem(value: m['status'] == 'active' ? 'status:suspended' : 'status:active', child: Text(m['status'] == 'active' ? 'Suspendre l’accès' : 'Réactiver l’accès')),
          ]),
        ));
      }).toList());
    },
  );
}


class _RolePermissionsPanel extends StatefulWidget {
  const _RolePermissionsPanel({super.key, required this.organizationId, required this.service});
  final String organizationId;
  final OrganizationService service;
  @override
  State<_RolePermissionsPanel> createState() => _RolePermissionsPanelState();
}
class _RolePermissionsPanelState extends State<_RolePermissionsPanel> {
  static const roles = ['owner','admin','project_manager','engineer','site_manager','accountant','storekeeper','qse_manager','client','subcontractor','member'];
  String role = 'project_manager';
  late Future<List<Map<String, dynamic>>> _permissions;
  late Future<List<Map<String, dynamic>>> _assigned;
  @override
  void initState() { super.initState(); _load(); }
  void _load() {
    _permissions = widget.service.listPermissions();
    _assigned = widget.service.listRolePermissions(widget.organizationId, role);
  }
  Future<void> _changeRole(String value) async { setState(() { role=value; _load(); }); }
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    DropdownButtonFormField<String>(value: role, decoration: const InputDecoration(labelText: 'Rôle à configurer'), items: roles.map((r) => DropdownMenuItem(value:r, child:Text(r))).toList(), onChanged: (v) { if (v != null) _changeRole(v); }),
    const SizedBox(height: 8),
    FutureBuilder<List<Map<String, dynamic>>>(future: _permissions, builder: (context, ps) {
      if (ps.connectionState == ConnectionState.waiting) return const LinearProgressIndicator();
      if (ps.hasError) return Text('Catalogue indisponible : ${ps.error}');
      return FutureBuilder<List<Map<String, dynamic>>>(future: _assigned, builder: (context, as) {
        if (as.connectionState == ConnectionState.waiting) return const LinearProgressIndicator();
        if (as.hasError) return Text('Permissions indisponibles : ${as.error}');
        final assigned = (as.data ?? []).map((e) => e['permission_code']).toSet();
        return Column(children: (ps.data ?? []).map((p) {
          final code = p['code'] as String;
          return SwitchListTile(dense:true, contentPadding: EdgeInsets.zero, title: Text(p['label'] as String), subtitle: Text('${p['module']} • $code'), value: assigned.contains(code), onChanged: (enabled) async {
            try { await widget.service.setRolePermission(organizationId: widget.organizationId, role: role, permissionCode: code, enabled: enabled); if (mounted) setState(_load); }
            catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Modification refusée : $e'))); }
          });
        }).toList());
      });
    }),
    const SizedBox(height: 4),
    const Text('Les changements sont contrôlés par Supabase. Le rôle propriétaire reste réservé au propriétaire de l’organisation.', style: TextStyle(fontSize: 12)),
  ])));
}


class _MyProfilePanel extends StatefulWidget {
  const _MyProfilePanel();
  @override
  State<_MyProfilePanel> createState() => _MyProfilePanelState();
}
class _MyProfilePanelState extends State<_MyProfilePanel> {
  final service = OrganizationService.instance;
  final first = TextEditingController();
  final last = TextEditingController();
  final phone = TextEditingController();
  final job = TextEditingController();
  final avatar = TextEditingController();
  bool loading = true;
  bool saving = false;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    try { final p = await service.getMyProfile(); first.text = p['first_name'] ?? ''; last.text = p['last_name'] ?? ''; phone.text = p['phone'] ?? ''; job.text = p['job_title'] ?? ''; avatar.text = p['avatar_url'] ?? ''; }
    catch (_) {}
    if (mounted) setState(() => loading = false);
  }
  @override
  void dispose() { first.dispose(); last.dispose(); phone.dispose(); job.dispose(); avatar.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text('Mon profil professionnel', style: Theme.of(context).textTheme.titleMedium),
    if (loading) const LinearProgressIndicator() else ...[
      const SizedBox(height: 8),
      TextField(controller: first, decoration: const InputDecoration(labelText: 'Prénom')),
      TextField(controller: last, decoration: const InputDecoration(labelText: 'Nom')),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone')),
      TextField(controller: job, decoration: const InputDecoration(labelText: 'Fonction / métier')),
      TextField(controller: avatar, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'URL de la photo (facultatif)')),
      const SizedBox(height: 8),
      Align(alignment: Alignment.centerRight, child: FilledButton.icon(onPressed: saving ? null : () async {
        setState(() => saving = true);
        try { await service.updateMyProfile(firstName: first.text, lastName: last.text, phone: phone.text, jobTitle: job.text, avatarUrl: avatar.text); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profil mis à jour.'))); }
        catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Mise à jour impossible : $e'))); }
        if (mounted) setState(() => saving = false);
      }, icon: const Icon(Icons.save_outlined), label: Text(saving ? 'Enregistrement…' : 'Enregistrer le profil'))),
    ],
  ])));
}

class _MyInvitationsPanel extends StatefulWidget {
  const _MyInvitationsPanel();
  @override
  State<_MyInvitationsPanel> createState() => _MyInvitationsPanelState();
}
class _MyInvitationsPanelState extends State<_MyInvitationsPanel> {
  final service = OrganizationService.instance;
  late Future<List<Map<String,dynamic>>> future;
  @override
  void initState() { super.initState(); future = service.listMyInvitations(); }
  void reload() => setState(() => future = service.listMyInvitations());
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String,dynamic>>>(future: future, builder: (context,s) {
    if (s.connectionState == ConnectionState.waiting) return const Card(child: LinearProgressIndicator());
    if (s.hasError) return Card(child: Padding(padding: const EdgeInsets.all(12), child: Text('Invitations reçues indisponibles : ${s.error}')));
    final rows = s.data ?? [];
    if (rows.isEmpty) return const SizedBox.shrink();
    return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Invitations reçues', style: Theme.of(context).textTheme.titleMedium),
      ...rows.map((r) => ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.mark_email_unread_outlined), title: Text(r['organization_name'].toString()), subtitle: Text('Rôle : ${r['invited_role']} • Expire le ${r['expires_at'].toString().substring(0,10)}'), trailing: FilledButton(onPressed: () async {
        try { await service.acceptInvitation(r['invitation_id'].toString()); reload(); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invitation acceptée.'))); }
        catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Acceptation impossible : $e'))); }
      }, child: const Text('Accepter')))),
    ])));
  });
}

class _AuditPanel extends StatefulWidget {
  const _AuditPanel({super.key, required this.organizationId, required this.service});
  final String organizationId;
  final OrganizationService service;
  @override
  State<_AuditPanel> createState() => _AuditPanelState();
}
class _AuditPanelState extends State<_AuditPanel> {
  late Future<List<Map<String,dynamic>>> future;
  @override
  void initState() { super.initState(); future = widget.service.listAuditLogs(widget.organizationId); }
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String,dynamic>>>(future: future, builder: (context,s) {
    if (s.connectionState == ConnectionState.waiting) return const LinearProgressIndicator();
    if (s.hasError) return Text('Journal non accessible : ${s.error}');
    final rows = s.data ?? [];
    if (rows.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Aucune activité enregistrée pour le moment.')));
    return Card(child: Column(children: rows.map((r) {
      final date = DateTime.tryParse(r['created_at'].toString())?.toLocal();
      final stamp = date == null ? '' : '${date.day.toString().padLeft(2,'0')}/${date.month.toString().padLeft(2,'0')}/${date.year} ${date.hour.toString().padLeft(2,'0')}:${date.minute.toString().padLeft(2,'0')}';
      return ListTile(dense: true, leading: const Icon(Icons.history), title: Text(r['action'].toString()), subtitle: Text('${r['table_name']} • utilisateur ${r['actor_user_id'].toString().substring(0,8)} • $stamp'), trailing: const Icon(Icons.verified_user_outlined, size: 18));
    }).toList()));
  });
}
