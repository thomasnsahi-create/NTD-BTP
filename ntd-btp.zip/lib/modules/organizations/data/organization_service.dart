import 'package:supabase_flutter/supabase_flutter.dart';

class OrganizationService {
  OrganizationService._();
  static final instance = OrganizationService._();
  SupabaseClient get _db => Supabase.instance.client;

  Future<Map<String, dynamic>> getMyProfile() async {
    final user = _db.auth.currentUser;
    if (user == null) throw Exception('Session expirée');
    final row = await _db.from('profiles').select('id,full_name,first_name,last_name,phone,job_title,avatar_url,preferred_language').eq('id', user.id).single();
    return Map<String, dynamic>.from(row);
  }

  Future<void> updateMyProfile({required String firstName, required String lastName, required String phone, required String jobTitle, String? avatarUrl}) async {
    final user = _db.auth.currentUser;
    if (user == null) throw Exception('Session expirée');
    final fullName = '$firstName $lastName'.trim();
    await _db.from('profiles').update({
      'first_name': firstName.trim(), 'last_name': lastName.trim(),
      'full_name': fullName, 'phone': phone.trim(), 'job_title': jobTitle.trim(),
      'avatar_url': (avatarUrl ?? '').trim().isEmpty ? null : avatarUrl!.trim(),
    }).eq('id', user.id);
  }

  Future<Map<String, dynamic>> inviteMember({required String organizationId, required String email, required String role}) async {
    final result = await _db.functions.invoke('invite-organization-member', body: {
      'organization_id': organizationId, 'email': email.trim(), 'role': role,
    });
    if (result.status < 200 || result.status >= 300) {
      throw Exception((result.data is Map ? result.data['error'] : null) ?? 'Invitation refusée');
    }
    return Map<String, dynamic>.from(result.data as Map);
  }

  Future<List<Map<String, dynamic>>> listMyInvitations() async {
    final rows = await _db.rpc('list_my_organization_invitations');
    return List<Map<String, dynamic>>.from(rows as List);
  }

  Future<void> acceptInvitation(String invitationId) async {
    await _db.rpc('accept_organization_invitation', params: {'p_invitation_id': invitationId});
  }

  Future<List<Map<String, dynamic>>> listAuditLogs(String organizationId) async {
    final rows = await _db.from('audit_logs')
      .select('id,actor_user_id,action,table_name,record_id,details,created_at')
      .eq('organization_id', organizationId).order('created_at', ascending: false).limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> listOrganizations() async {
    final rows = await _db.from('organizations').select('id,name,legal_name,country_code,default_currency,created_at').order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<String> createOrganization({required String name, String? legalName, required String countryCode, required String currency}) async {
    final id = await _db.rpc('create_organization', params: {
      'p_name': name,
      'p_legal_name': legalName,
      'p_country_code': countryCode,
      'p_default_currency': currency,
    });
    return id as String;
  }

  Future<List<Map<String, dynamic>>> listMembers(String organizationId) async {
    final rows = await _db.from('organization_memberships')
      .select('id,user_id,role,status,created_at')
      .eq('organization_id', organizationId).order('created_at');
    final members = List<Map<String, dynamic>>.from(rows);
    if (members.isEmpty) return members;
    final ids = members.map((m) => m['user_id'] as String).toList();
    final profiles = await _db.from('profiles').select('id,full_name,first_name,last_name,phone,job_title').inFilter('id', ids);
    final byId = {for (final p in profiles) p['id']: p};
    return members.map((m) => {...m, 'profile': byId[m['user_id']]}).toList();
  }

  Future<void> updateMember({required String membershipId, required String role, required String status}) async {
    await _db.rpc('set_organization_member', params: {
      'p_membership_id': membershipId,
      'p_role': role,
      'p_status': status,
    });
  }

  Future<List<Map<String, dynamic>>> listRolePermissions(String organizationId, String role) async {
    final rows = await _db.from('organization_role_permissions').select('permission_code,enabled').eq('organization_id', organizationId).eq('role', role).eq('enabled', true);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> setRolePermission({required String organizationId, required String role, required String permissionCode, required bool enabled}) async {
    await _db.rpc('set_role_permission', params: {'p_organization_id': organizationId, 'p_role': role, 'p_permission_code': permissionCode, 'p_enabled': enabled});
  }

  Future<List<Map<String, dynamic>>> listPermissions() async {
    final rows = await _db.from('permission_catalog').select('code,label,description,module').eq('is_active', true).order('module').order('label');
    return List<Map<String, dynamic>>.from(rows);
  }
}
