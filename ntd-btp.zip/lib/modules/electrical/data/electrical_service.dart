import 'package:supabase_flutter/supabase_flutter.dart';

/// Accès Supabase au module électrique (E14 à E17).
class ElectricalService {
  ElectricalService._();
  static final instance = ElectricalService._();
  SupabaseClient get _db => Supabase.instance.client;

  List<Map<String, dynamic>> _list(dynamic rows) => List<Map<String, dynamic>>.from(rows as List);

  /// Garde, pour chaque code, la ligne de l'organisation si elle existe (sinon le défaut).
  List<Map<String, dynamic>> _preferOrg(List<Map<String, dynamic>> rows) {
    final byCode = <String, Map<String, dynamic>>{};
    for (final r in rows) {
      final code = (r['code'] as String).toUpperCase();
      final existing = byCode[code];
      if (existing == null || (existing['organization_id'] == null && r['organization_id'] != null)) {
        byCode[code] = r;
      }
    }
    return byCode.values.toList();
  }

  // ---------------------------------------------------------------- Référentiels
  Future<List<Map<String, dynamic>>> listVoltageDomains() async {
    final rows = await _db.from('elec_voltage_domains').select().eq('is_active', true).order('sort_order');
    return _preferOrg(_list(rows))..sort((a, b) => (a['sort_order'] as int).compareTo(b['sort_order'] as int));
  }

  Future<void> saveVoltageDomain(String organizationId, Map<String, dynamic> domain) async {
    final data = {
      'min_ac_v': domain['min_ac_v'],
      'max_ac_v': domain['max_ac_v'],
      'min_dc_v': domain['min_dc_v'],
      'max_dc_v': domain['max_dc_v'],
      'reference_standard': domain['reference_standard'],
      'is_confirmed': domain['is_confirmed'] == true,
    };
    if (domain['organization_id'] == organizationId) {
      await _db.from('elec_voltage_domains').update(data).eq('id', domain['id'] as String);
    } else {
      await _db.from('elec_voltage_domains').insert({
        'organization_id': organizationId,
        'code': domain['code'],
        'label': domain['label'],
        'description': domain['description'],
        'sort_order': domain['sort_order'],
        ...data,
      });
    }
  }

  Future<List<Map<String, dynamic>>> listCableTypes() async {
    final rows = await _db.from('elec_cable_types').select().eq('is_active', true).order('category').order('code');
    return _preferOrg(_list(rows))..sort((a, b) => (a['code'] as String).compareTo(b['code'] as String));
  }

  Future<List<Map<String, dynamic>>> listRoomTypes() async {
    final rows = await _db.from('elec_room_types').select().eq('is_active', true).order('sort_order');
    return _preferOrg(_list(rows))..sort((a, b) => (a['sort_order'] as int).compareTo(b['sort_order'] as int));
  }

  // ---------------------------------------------------------------- Installations
  Future<List<Map<String, dynamic>>> listInstallations(String projectId) async {
    final rows = await _db
        .from('elec_installations')
        .select('*, elec_voltage_domains(code,label)')
        .eq('project_id', projectId)
        .order('created_at');
    return _list(rows);
  }

  Future<void> saveInstallation(String projectId, Map<String, dynamic> data, {String? id}) async {
    if (id == null) {
      await _db.from('elec_installations').insert({...data, 'project_id': projectId});
    } else {
      await _db.from('elec_installations').update(data).eq('id', id);
    }
  }

  Future<void> deleteInstallation(String id) async {
    await _db.from('elec_installations').delete().eq('id', id);
  }

  // ---------------------------------------------------------------- Pièces
  Future<List<Map<String, dynamic>>> listRooms(String projectId) async {
    final rows = await _db
        .from('elec_rooms')
        .select('*, elec_room_types(code,label)')
        .eq('project_id', projectId)
        .order('building')
        .order('floor_label')
        .order('name');
    return _list(rows);
  }

  Future<void> saveRoom(String projectId, Map<String, dynamic> data, {String? id}) async {
    if (id == null) {
      await _db.from('elec_rooms').insert({...data, 'project_id': projectId});
    } else {
      await _db.from('elec_rooms').update(data).eq('id', id);
    }
  }

  Future<void> deleteRoom(String id) async {
    await _db.from('elec_rooms').delete().eq('id', id);
  }

  Future<List<Map<String, dynamic>>> listOpenings(String roomId) async {
    final rows = await _db.from('elec_room_openings').select().eq('room_id', roomId).order('created_at');
    return _list(rows);
  }

  Future<void> addOpening(Map<String, dynamic> data) async {
    await _db.from('elec_room_openings').insert(data);
  }

  Future<void> deleteOpening(String id) async {
    await _db.from('elec_room_openings').delete().eq('id', id);
  }

  // ---------------------------------------------------------------- E18 Implantation
  Future<List<Map<String, dynamic>>> listEquipmentTypes() async {
    final rows = await _db.from('elec_equipment_types').select().eq('is_active', true).order('sort_order');
    return _preferOrg(_list(rows))..sort((a, b) => (a['sort_order'] as int).compareTo(b['sort_order'] as int));
  }

  Future<List<Map<String, dynamic>>> listEquipment(String roomId) async {
    final rows = await _db
        .from('elec_equipment')
        .select('*, elec_equipment_types(code,label,category,symbol,height_source)')
        .eq('room_id', roomId)
        .order('created_at');
    return _list(rows);
  }

  Future<void> addEquipment(Map<String, dynamic> data) async {
    await _db.from('elec_equipment').insert(data);
  }

  Future<void> updateEquipment(String id, Map<String, dynamic> data) async {
    await _db.from('elec_equipment').update(data).eq('id', id);
  }

  Future<void> deleteEquipment(String id) async {
    await _db.from('elec_equipment').delete().eq('id', id);
  }

  Future<List<Map<String, dynamic>>> listRoutes(String roomId) async {
    final rows = await _db.from('elec_routes').select().eq('room_id', roomId).order('created_at');
    return _list(rows);
  }

  Future<void> addRoute(Map<String, dynamic> data) async {
    await _db.from('elec_routes').insert(data);
  }

  Future<void> deleteRoute(String id) async {
    await _db.from('elec_routes').delete().eq('id', id);
  }

  // ---------------------------------------------------------------- E19 Besoins
  Future<Map<String, dynamic>?> getProjectSettings(String projectId) async {
    final row = await _db.from('elec_project_settings').select().eq('project_id', projectId).maybeSingle();
    return row == null ? null : Map<String, dynamic>.from(row as Map);
  }

  Future<void> saveProjectSettings(String projectId, {String? buildingUsage, String? regulatoryReference}) async {
    await _db.from('elec_project_settings').upsert({
      'project_id': projectId,
      'building_usage': buildingUsage,
      'regulatory_reference': regulatoryReference,
    }, onConflict: 'project_id');
  }

  Future<List<Map<String, dynamic>>> listRequirementRules() async {
    final rows = await _db.from('elec_requirement_rules').select().eq('is_active', true);
    return _list(rows);
  }

  Future<List<Map<String, dynamic>>> listRoomNeeds(String projectId) async {
    final rows = await _db.from('elec_room_needs').select().eq('project_id', projectId);
    return _list(rows);
  }

  Future<void> upsertNeed(Map<String, dynamic> data) async {
    await _db.from('elec_room_needs').upsert(data, onConflict: 'room_id,equipment_type_id');
  }

  /// Équipements déjà implantés (E18), pour comparer au besoin.
  Future<List<Map<String, dynamic>>> listProjectEquipmentRefs(String projectId) async {
    final rows = await _db.from('elec_equipment').select('room_id,equipment_type_id').eq('project_id', projectId);
    return _list(rows);
  }

  // ---------------------------------------------------------------- E20 Bilan de puissance
  Future<List<Map<String, dynamic>>> listPowerItems(String projectId) async {
    final rows = await _db
        .from('elec_equipment')
        .select('id,label,room_id,power_w,power_factor,efficiency,elec_equipment_types(code,label,category),elec_rooms(name)')
        .eq('project_id', projectId)
        .order('created_at');
    return _list(rows);
  }

  Future<List<Map<String, dynamic>>> listDiversityRules() async {
    final rows = await _db.from('elec_diversity_rules').select().eq('is_active', true);
    return _list(rows);
  }

  Future<void> saveBalanceFactors(String projectId, {required double overall, required double reserve}) async {
    // upsert partiel : seules ces deux colonnes sont modifiées (destination et référentiel conservés).
    await _db.from('elec_project_settings').upsert({
      'project_id': projectId,
      'overall_simultaneity': overall,
      'reserve_factor': reserve,
    }, onConflict: 'project_id');
  }

  Future<List<Map<String, dynamic>>> listPowerBalances(String projectId) async {
    final rows = await _db.from('elec_power_balances').select().eq('project_id', projectId).order('created_at', ascending: false).limit(20);
    return _list(rows);
  }

  Future<void> savePowerBalance(Map<String, dynamic> data) async {
    await _db.from('elec_power_balances').insert(data);
  }

  Future<void> deletePowerBalance(String id) async {
    await _db.from('elec_power_balances').delete().eq('id', id);
  }

  // ---------------------------------------------------------------- E21 Courants
  Future<List<Map<String, dynamic>>> listCurrentItems(String projectId) async {
    final rows = await _db
        .from('elec_equipment')
        .select('id,label,room_id,power_w,power_factor,efficiency,connection,installation_id,circuit_id,'
            'elec_equipment_types(code,label,category),elec_rooms(name)')
        .eq('project_id', projectId)
        .order('created_at');
    return _list(rows);
  }

  // ---------------------------------------------------------------- Gestion des règles
  Future<void> saveRequirementRule(String organizationId, Map<String, dynamic> data, {String? id}) async {
    if (id == null) {
      await _db.from('elec_requirement_rules').insert({...data, 'organization_id': organizationId});
    } else {
      await _db.from('elec_requirement_rules').update(data).eq('id', id);
    }
  }

  Future<void> deleteRequirementRule(String id) async {
    await _db.from('elec_requirement_rules').delete().eq('id', id);
  }

  Future<void> saveDiversityRule(String organizationId, Map<String, dynamic> data, {String? id}) async {
    if (id == null) {
      await _db.from('elec_diversity_rules').insert({...data, 'organization_id': organizationId});
    } else {
      await _db.from('elec_diversity_rules').update(data).eq('id', id);
    }
  }

  Future<void> deleteDiversityRule(String id) async {
    await _db.from('elec_diversity_rules').delete().eq('id', id);
  }

  // ---------------------------------------------------------------- Circuits
  Future<List<Map<String, dynamic>>> listCircuits(String projectId) async {
    final rows = await _db.from('elec_circuits').select().eq('project_id', projectId).order('number');
    return _list(rows);
  }

  Future<void> saveCircuit(String projectId, Map<String, dynamic> data, {String? id}) async {
    if (id == null) {
      await _db.from('elec_circuits').insert({...data, 'project_id': projectId});
    } else {
      await _db.from('elec_circuits').update(data).eq('id', id);
    }
  }

  Future<void> deleteCircuit(String id) async {
    await _db.from('elec_circuits').delete().eq('id', id);
  }

  /// Rattache [add] au circuit et détache [remove] (les autres équipements ne sont pas touchés).
  Future<void> assignCircuitEquipment(String circuitId, {required List<String> add, required List<String> remove}) async {
    if (add.isNotEmpty) {
      await _db.from('elec_equipment').update({'circuit_id': circuitId}).inFilter('id', add);
    }
    if (remove.isNotEmpty) {
      await _db.from('elec_equipment').update({'circuit_id': null}).inFilter('id', remove);
    }
  }
}
