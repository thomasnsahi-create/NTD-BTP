import 'validation.dart';

/// Coefficients d'utilisation (Ku) et de simultanéité (Ks) d'une catégorie d'équipements.
/// Ks = ksBase + ksPerN / n, borné à [0 ; 1] (n = nombre d'équipements de la catégorie).
/// Un coefficient fixe a ksPerN = 0 ; les prises donnent par exemple 0,1 + 0,9 / n.
class DiversityRule {
  const DiversityRule({
    required this.category,
    this.buildingUsage,
    this.ku = 1,
    this.ksBase = 1,
    this.ksPerN = 0,
    this.reference,
    this.isConfirmed = false,
    this.id,
    this.isOrg = false,
  });

  factory DiversityRule.fromMap(Map<String, dynamic> m) => DiversityRule(
        category: m['category'] as String,
        buildingUsage: m['building_usage'] as String?,
        ku: (m['ku'] as num).toDouble(),
        ksBase: (m['ks_base'] as num).toDouble(),
        ksPerN: (m['ks_per_n'] as num).toDouble(),
        reference: m['reference_text'] as String?,
        isConfirmed: m['is_confirmed'] == true,
        id: m['id'] as String?,
        isOrg: m['organization_id'] != null,
      );

  final String? id;

  /// Règle propre à l'organisation (sinon règle par défaut).
  final bool isOrg;
  final String category;
  final String? buildingUsage; // null = toutes destinations
  final double ku;
  final double ksBase;
  final double ksPerN;
  final String? reference;
  final bool isConfirmed;

  double ks(int n) {
    final v = ksBase + (n > 0 ? ksPerN / n : 0);
    return v.clamp(0.0, 1.0).toDouble();
  }
}

/// Équipement pris en compte dans le bilan.
class PowerItem {
  const PowerItem({
    required this.id,
    required this.label,
    required this.roomId,
    required this.roomName,
    required this.category,
    this.powerW,
    this.powerFactor,
  });

  final String id;
  final String label;
  final String roomId;
  final String roomName;
  final String category;
  final double? powerW;
  final double? powerFactor;

  bool get hasPower => powerW != null && powerW! > 0;
}

class CategoryBalance {
  const CategoryBalance({
    required this.category,
    required this.count,
    required this.installedW,
    required this.ku,
    required this.ks,
    required this.demandW,
    required this.ruleFound,
    required this.ruleConfirmed,
    this.reference,
    this.apparentDemandVA,
  });

  final String category;
  final int count;
  final double installedW;
  final double ku;
  final double ks;
  final double demandW;
  final bool ruleFound;
  final bool ruleConfirmed;
  final String? reference;

  /// Puissance apparente d'appel de la catégorie ; null si un facteur de puissance manque.
  final double? apparentDemandVA;

  Map<String, dynamic> toJson() => {
        'category': category,
        'count': count,
        'installed_w': installedW,
        'ku': ku,
        'ks': ks,
        'demand_w': demandW,
        'rule_found': ruleFound,
        'rule_confirmed': ruleConfirmed,
        'reference': reference,
        'apparent_demand_va': apparentDemandVA,
      };
}

class PowerBalance {
  const PowerBalance({
    required this.categories,
    required this.installedW,
    required this.demandBeforeFactorsW,
    required this.overallSimultaneity,
    required this.reserveFactor,
    required this.demandW,
    required this.apparentDemandVA,
    required this.itemsWithPower,
    required this.itemsWithoutPower,
    required this.issues,
  });

  final List<CategoryBalance> categories;
  final double installedW;

  /// Somme des puissances d'appel par catégorie (Ku × Ks), avant coefficient général et réserve.
  final double demandBeforeFactorsW;
  final double overallSimultaneity;
  final double reserveFactor;

  /// Puissance d'appel retenue = somme par catégorie × coefficient général × réserve.
  final double demandW;

  /// Puissance apparente d'appel ; null si un facteur de puissance manque.
  final double? apparentDemandVA;
  final int itemsWithPower;
  final List<PowerItem> itemsWithoutPower;
  final List<ValidationIssue> issues;

  Map<String, dynamic> toJson() => {
        'categories': categories.map((c) => c.toJson()).toList(),
        'installed_w': installedW,
        'demand_before_factors_w': demandBeforeFactorsW,
        'overall_simultaneity': overallSimultaneity,
        'reserve_factor': reserveFactor,
        'demand_w': demandW,
        'apparent_demand_va': apparentDemandVA,
        'items_without_power': itemsWithoutPower.map((i) => i.id).toList(),
      };
}

/// Règle applicable : celle de la destination du bâtiment, à défaut la règle générale.
DiversityRule? pickRule(Iterable<DiversityRule> rules, String category, String? usage) {
  DiversityRule? generic;
  for (final r in rules) {
    if (r.category != category) continue;
    if (usage != null && r.buildingUsage == usage) return r;
    if (r.buildingUsage == null) generic = r;
  }
  return generic;
}

/// Calcule le bilan : par catégorie, installé × Ku × Ks(n) ; puis coefficient général et réserve.
/// Sans règle pour une catégorie, aucun coefficient n'est supposé : Ku = Ks = 1 (aucune diversité,
/// hypothèse prudente) et un avertissement est émis. Les équipements sans puissance sont exclus
/// du calcul et listés ; leur puissance n'est jamais estimée.
PowerBalance computePowerBalance({
  required Iterable<PowerItem> items,
  required Iterable<DiversityRule> rules,
  String? usage,
  double overallSimultaneity = 1,
  double reserveFactor = 1,
}) {
  final issues = <ValidationIssue>[];
  if (overallSimultaneity <= 0 || overallSimultaneity > 1) {
    issues.add(const ValidationIssue(IssueSeverity.error, 'Le coefficient de simultanéité général doit être compris entre 0 (exclu) et 1.'));
  }
  if (reserveFactor < 1) {
    issues.add(const ValidationIssue(IssueSeverity.error, 'Le coefficient de réserve doit être supérieur ou égal à 1.'));
  }
  if (usage == null) {
    issues.add(const ValidationIssue(
      IssueSeverity.warning,
      'Destination du bâtiment non renseignée : seuls les coefficients généraux sont utilisés.',
    ));
  }

  final withPower = items.where((i) => i.hasPower).toList();
  final without = items.where((i) => !i.hasPower).toList();
  if (without.isNotEmpty) {
    issues.add(ValidationIssue(
      IssueSeverity.warning,
      '${without.length} équipement(s) sans puissance renseignée, exclus du bilan.',
    ));
  }

  final byCategory = <String, List<PowerItem>>{};
  for (final i in withPower) {
    byCategory.putIfAbsent(i.category, () => []).add(i);
  }

  final cats = <CategoryBalance>[];
  var installed = 0.0;
  var before = 0.0;
  double? apparentSum = 0;
  for (final e in byCategory.entries) {
    final list = e.value;
    final p = list.fold<double>(0, (s, i) => s + i.powerW!);
    final rule = pickRule(rules, e.key, usage);
    final ku = rule?.ku ?? 1;
    final ks = rule?.ks(list.length) ?? 1;
    final demand = p * ku * ks;

    double? apparent;
    if (list.every((i) => i.powerFactor != null && i.powerFactor! > 0)) {
      final s = list.fold<double>(0, (a, i) => a + i.powerW! / i.powerFactor!);
      apparent = demand * (s / p); // cos φ moyen pondéré de la catégorie
    }
    if (rule == null) {
      issues.add(ValidationIssue(
        IssueSeverity.warning,
        'Aucun coefficient défini pour la catégorie « ${e.key} » : Ku = Ks = 1 appliqué (aucune diversité).',
      ));
    } else if (!rule.isConfirmed) {
      issues.add(ValidationIssue(
        IssueSeverity.warning,
        'Coefficients de « ${e.key} » : valeurs par défaut à confirmer pour ce projet.',
      ));
    }
    cats.add(CategoryBalance(
      category: e.key,
      count: list.length,
      installedW: p,
      ku: ku,
      ks: ks,
      demandW: demand,
      ruleFound: rule != null,
      ruleConfirmed: rule?.isConfirmed ?? false,
      reference: rule?.reference,
      apparentDemandVA: apparent,
    ));
    installed += p;
    before += demand;
    apparentSum = (apparentSum == null || apparent == null) ? null : apparentSum + apparent;
  }
  cats.sort((a, b) => a.category.compareTo(b.category));

  if (withPower.isNotEmpty && apparentSum == null) {
    issues.add(const ValidationIssue(
      IssueSeverity.warning,
      'Facteur de puissance manquant sur certains équipements : puissance apparente non calculée.',
    ));
  }

  final factor = overallSimultaneity * reserveFactor;
  return PowerBalance(
    categories: cats,
    installedW: installed,
    demandBeforeFactorsW: before,
    overallSimultaneity: overallSimultaneity,
    reserveFactor: reserveFactor,
    demandW: before * factor,
    apparentDemandVA: withPower.isEmpty ? null : (apparentSum == null ? null : apparentSum * factor),
    itemsWithPower: withPower.length,
    itemsWithoutPower: without,
    issues: issues,
  );
}

/// Puissance installée par pièce (information ; la puissance d'appel est calculée au niveau du projet).
Map<String, double> installedByRoom(Iterable<PowerItem> items) {
  final out = <String, double>{};
  for (final i in items.where((i) => i.hasPower)) {
    out[i.roomId] = (out[i.roomId] ?? 0) + i.powerW!;
  }
  return out;
}

String _diversityKey(DiversityRule r) => '${r.buildingUsage ?? 'any'}|${r.category}';

/// Une règle de l'organisation remplace la règle par défaut de même clé (destination, catégorie).
List<DiversityRule> effectiveDiversityRules(Iterable<DiversityRule> rules) {
  final overridden = rules.where((r) => r.isOrg).map(_diversityKey).toSet();
  return rules.where((r) => r.isOrg || !overridden.contains(_diversityKey(r))).toList();
}

/// Puissance absorbée d'un équipement : puissance utile / rendement si le rendement est connu,
/// sinon la puissance saisie telle quelle (considérée comme absorbée).
double? absorbedPower(double? powerW, double? efficiency) {
  if (powerW == null) return null;
  if (efficiency != null && efficiency > 0 && efficiency <= 1) return powerW / efficiency;
  return powerW;
}
