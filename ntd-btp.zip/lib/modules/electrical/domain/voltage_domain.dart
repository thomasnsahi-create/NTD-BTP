import 'dart:math' as math;
import 'validation.dart';

/// Domaine de tension configurable (TBT, BT, MTA, MTB, HTA, HTB...).
/// Les limites ne sont jamais figées dans le code : elles viennent du référentiel
/// (réglementation nationale, distributeur, contrat). Une limite absente (null)
/// signifie « non définie » : aucun contrôle n'est alors inventé.
class VoltageDomain {
  const VoltageDomain({
    required this.code,
    required this.label,
    this.minAcV,
    this.maxAcV,
    this.minDcV,
    this.maxDcV,
    this.isConfirmed = false,
  });

  factory VoltageDomain.fromMap(Map<String, dynamic> m) => VoltageDomain(
        code: m['code'] as String,
        label: m['label'] as String,
        minAcV: (m['min_ac_v'] as num?)?.toDouble(),
        maxAcV: (m['max_ac_v'] as num?)?.toDouble(),
        minDcV: (m['min_dc_v'] as num?)?.toDouble(),
        maxDcV: (m['max_dc_v'] as num?)?.toDouble(),
        isConfirmed: m['is_confirmed'] == true,
      );

  final String code;
  final String label;
  final double? minAcV;
  final double? maxAcV;
  final double? minDcV;
  final double? maxDcV;
  final bool isConfirmed;

  bool hasLimits(bool dc) => dc ? (minDcV != null || maxDcV != null) : (minAcV != null || maxAcV != null);

  /// Vrai/faux si les limites sont connues, null si elles ne sont pas définies.
  /// Convention : borne basse exclue, borne haute incluse (ex. BT : 50 < U ≤ 1000).
  /// Pour une borne basse nulle (TBT, 0 V) la valeur 0 est acceptée.
  bool? contains(double volts, {bool dc = false}) {
    if (!hasLimits(dc)) return null;
    final lo = dc ? minDcV : minAcV;
    final hi = dc ? maxDcV : maxAcV;
    if (lo != null && (lo == 0 ? volts < 0 : volts <= lo)) return false;
    if (hi != null && volts > hi) return false;
    return true;
  }

  String limitsLabel({bool dc = false}) {
    final lo = dc ? minDcV : minAcV;
    final hi = dc ? maxDcV : maxAcV;
    if (lo == null && hi == null) return 'limites non définies';
    final unit = dc ? 'V c.c.' : 'V c.a.';
    if (hi == null) return '> ${_n(lo!)} $unit';
    return '${_n(lo ?? 0)} – ${_n(hi)} $unit';
  }

  static String _n(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();
}

const List<String> neutralRegimes = ['TT', 'TN-C', 'TN-S', 'TN-C-S', 'IT'];

/// Données saisies pour une installation, avant enregistrement.
class InstallationData {
  const InstallationData({
    required this.domain,
    this.dc = false,
    this.nominalV,
    this.maxV,
    this.phaseToPhaseV,
    this.phaseToNeutralV,
    this.frequencyHz,
    this.phases,
    this.neutralRegime,
  });

  final VoltageDomain? domain;
  final bool dc;
  final double? nominalV;
  final double? maxV;
  final double? phaseToPhaseV;
  final double? phaseToNeutralV;
  final double? frequencyHz;
  final int? phases;
  final String? neutralRegime;
}

/// Contrôle la cohérence d'une installation avec son domaine de tension.
/// Une donnée manquante est signalée, jamais remplacée par une valeur supposée.
List<ValidationIssue> validateInstallation(InstallationData d) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));
  void warn(String m) => out.add(ValidationIssue(IssueSeverity.warning, m));

  if (d.domain == null) {
    err('Choisissez un domaine de tension.');
    return out;
  }
  final dom = d.domain!;
  if (d.nominalV == null) {
    err('La tension nominale est obligatoire.');
  } else {
    final inside = dom.contains(d.nominalV!, dc: d.dc);
    if (inside == false) {
      err('La tension nominale (${d.nominalV} V) est hors du domaine ${dom.code} (${dom.limitsLabel(dc: d.dc)}).');
    } else if (inside == null) {
      warn('Les limites du domaine ${dom.code} ne sont pas définies : renseignez-les dans le référentiel pour activer ce contrôle.');
    }
  }
  if (d.nominalV != null && d.maxV != null && d.maxV! < d.nominalV!) {
    err('La tension maximale ne peut pas être inférieure à la tension nominale.');
  }
  if (!d.dc) {
    if (d.frequencyHz == null) warn('La fréquence n\'est pas renseignée.');
    if (d.phases == null) {
      warn('Le nombre de phases n\'est pas renseigné.');
    } else if (d.phases == 3) {
      if (d.phaseToPhaseV == null) {
        warn('Tension entre phases non renseignée pour une installation triphasée.');
      } else if (d.phaseToNeutralV != null) {
        final expected = d.phaseToPhaseV! / math.sqrt(3);
        if ((d.phaseToNeutralV! - expected).abs() > expected * 0.05) {
          warn('Tension phase-neutre (${d.phaseToNeutralV} V) éloignée de U/√3 (≈ ${expected.toStringAsFixed(0)} V).');
        }
      }
    }
    if (d.neutralRegime == null) {
      warn('Le régime de neutre n\'est pas renseigné.');
    } else if (!neutralRegimes.contains(d.neutralRegime)) {
      err('Régime de neutre inconnu : ${d.neutralRegime}.');
    }
  }
  if (!dom.isConfirmed) {
    warn('Les limites du domaine ${dom.code} sont des valeurs par défaut à confirmer pour ce projet.');
  }
  return out;
}
