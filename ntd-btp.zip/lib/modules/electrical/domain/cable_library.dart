import 'validation.dart';

/// Sections normalisées usuelles (mm²). Les sections réellement disponibles
/// dépendent du type de câble ([CableType.availableSections]).
const List<double> standardSectionsMm2 = [
  0.5, 0.75, 1, 1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300,
];

const Map<String, String> conductorLabels = {'cu': 'Cuivre', 'al': 'Aluminium'};

const Map<String, String> categoryLabels = {
  'power': 'Puissance',
  'control': 'Commande',
  'shielded': 'Blindé',
  'armoured': 'Armé',
  'fire_resistant': 'Résistant au feu',
  'halogen_free': 'Sans halogène',
  'photovoltaic': 'Photovoltaïque',
  'communication': 'Communication',
  'earth': 'Terre',
  'industrial': 'Industriel',
};

const Map<String, String> layingLabels = {
  'flush': 'Encastré',
  'conduit': 'Sous conduit',
  'sheath': 'Sous gaine',
  'apparent': 'Apparent',
  'tray': 'Sur chemin de câbles',
  'false_ceiling': 'En faux plafond',
  'trench': 'En caniveau',
  'buried': 'Enterré',
  'support': 'Sur support',
  'duct': 'En goulotte',
  'industrial': 'En milieu industriel',
};

const Map<String, String> environmentLabels = {
  'dry': 'Local sec',
  'humid': 'Local humide',
  'hot': 'Local chaud',
  'cold': 'Local froid',
  'outdoor': 'Extérieur',
  'buried': 'Enterré',
  'uv': 'Exposition aux UV',
  'chemical': 'Produits chimiques',
  'mechanical': 'Risques mécaniques',
  'fire_risk': 'Risque d\'incendie',
  'industrial': 'Milieu industriel',
};

/// Câble de la bibliothèque technique.
class CableType {
  const CableType({
    required this.code,
    required this.label,
    required this.category,
    required this.conductorMaterials,
    required this.ratedUV,
    this.currentType = 'ac',
    this.insulation = 'PVC',
    this.allowedLaying = const [],
    this.allowedEnvironments = const [],
    this.availableSections = const [],
    this.availableCores = const [],
    this.isFireResistant = false,
    this.isHalogenFree = false,
    this.dataConfirmed = false,
  });

  factory CableType.fromMap(Map<String, dynamic> m) => CableType(
        code: m['code'] as String,
        label: m['label'] as String,
        category: m['category'] as String,
        conductorMaterials: List<String>.from(m['conductor_materials'] as List),
        ratedUV: (m['rated_u_v'] as num).toDouble(),
        currentType: (m['current_type'] ?? 'ac') as String,
        insulation: (m['insulation'] ?? 'PVC') as String,
        allowedLaying: List<String>.from((m['allowed_laying'] ?? const []) as List),
        allowedEnvironments: List<String>.from((m['allowed_environments'] ?? const []) as List),
        availableSections:
            ((m['available_sections_mm2'] ?? const []) as List).map((e) => (e as num).toDouble()).toList(),
        availableCores: ((m['available_cores'] ?? const []) as List).map((e) => (e as num).toInt()).toList(),
        isFireResistant: m['is_fire_resistant'] == true,
        isHalogenFree: m['is_halogen_free'] == true,
        dataConfirmed: m['data_status'] == 'confirmed',
      );

  final String code;
  final String label;
  final String category;
  final List<String> conductorMaterials;
  final double ratedUV;
  final String currentType; // ac | dc | ac_dc
  final String insulation;
  final List<String> allowedLaying;
  final List<String> allowedEnvironments;
  final List<double> availableSections;
  final List<int> availableCores;
  final bool isFireResistant;
  final bool isHalogenFree;
  final bool dataConfirmed;
}

/// Contexte d'emploi d'un câble.
class CableUsage {
  const CableUsage({
    required this.voltageV,
    this.dc = false,
    this.conductor,
    this.laying,
    this.environments = const [],
    this.requiresFireResistance = false,
    this.requiresHalogenFree = false,
  });

  final double voltageV;
  final bool dc;
  final String? conductor;
  final String? laying;
  final List<String> environments;
  final bool requiresFireResistance;
  final bool requiresHalogenFree;
}

/// Une référence n'est proposée que si elle convient à la tension, à la pose et à
/// l'environnement. Retourne la liste des raisons de rejet (vide = adapté).
List<ValidationIssue> checkCableSuitability(CableType c, CableUsage u) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));

  if (u.dc && c.currentType == 'ac') err('${c.code} n\'est pas prévu pour le courant continu.');
  if (!u.dc && c.currentType == 'dc') err('${c.code} n\'est pas prévu pour le courant alternatif.');
  if (u.voltageV > c.ratedUV) {
    err('Tension du circuit (${u.voltageV.toStringAsFixed(0)} V) supérieure à la tension assignée de ${c.code} (${c.ratedUV.toStringAsFixed(0)} V).');
  }
  if (u.conductor != null && !c.conductorMaterials.contains(u.conductor)) {
    err('${c.code} n\'existe pas en ${conductorLabels[u.conductor] ?? u.conductor}.');
  }
  if (u.laying != null && c.allowedLaying.isNotEmpty && !c.allowedLaying.contains(u.laying)) {
    err('Mode de pose « ${layingLabels[u.laying] ?? u.laying} » non prévu pour ${c.code}.');
  }
  for (final env in u.environments) {
    if (c.allowedEnvironments.isNotEmpty && !c.allowedEnvironments.contains(env)) {
      err('Environnement « ${environmentLabels[env] ?? env} » non prévu pour ${c.code}.');
    }
  }
  if (u.requiresFireResistance && !c.isFireResistant) err('${c.code} n\'est pas résistant au feu.');
  if (u.requiresHalogenFree && !c.isHalogenFree) err('${c.code} n\'est pas sans halogène.');
  return out;
}

/// Câbles de la bibliothèque convenant à l'usage décrit.
List<CableType> suitableCables(Iterable<CableType> library, CableUsage usage) =>
    library.where((c) => !hasErrors(checkCableSuitability(c, usage))).toList();

/// Plus petite section disponible ≥ [minimumMm2] pour ce câble, ou null.
/// Ne remplace pas le calcul de dimensionnement (E22) : sert à arrondir à la section normalisée.
double? nextAvailableSection(CableType c, double minimumMm2) {
  final sorted = [...c.availableSections]..sort();
  for (final s in sorted) {
    if (s >= minimumMm2) return s;
  }
  return null;
}
