import 'dart:math' as math;
import 'current_calc.dart';
import 'validation.dart';

const Map<String, String> circuitTypeLabels = {
  'lighting': 'Éclairage',
  'socket': 'Prises de courant',
  'specialized': 'Circuit spécialisé',
  'hvac': 'Climatisation',
  'power': 'Force / puissance',
  'control': 'Commande',
  'communication': 'Communication',
  'other': 'Autre',
};

/// Charge d'un circuit : puissance absorbée (W) et facteur de puissance.
class CircuitLoad {
  const CircuitLoad({required this.id, required this.label, this.powerW, this.powerFactor});
  final String id;
  final String label;
  final double? powerW;
  final double? powerFactor;
}

class CircuitCurrent {
  const CircuitCurrent({
    this.ibA,
    this.activeW,
    this.apparentVA,
    this.supply,
    this.missing = const [],
    this.assumptions = const [],
  });

  /// Courant d'emploi Ib du circuit (A) ; null si des données manquent.
  final double? ibA;
  final double? activeW;
  final double? apparentVA;
  final LoadSupply? supply;
  final List<String> missing;
  final List<String> assumptions;
  bool get isComplete => ibA != null;
}

/// Courant d'emploi d'un circuit : Ib = k × S / U (monophasé), k × S / (√3 U) (triphasé), k × P / U (continu),
/// avec S = Σ (P_i / cos φ_i) et k le coefficient de simultanéité du circuit (1 = aucune diversité).
/// Un circuit n'est jamais calculé avec des charges inconnues : tout équipement sans puissance
/// ou sans cos φ (en alternatif) est signalé et bloque le calcul.
CircuitCurrent computeCircuitCurrent({
  required InstallationSupply? installation,
  required String? connection,
  required List<CircuitLoad> loads,
  double demandCoefficient = 1,
}) {
  final missing = <String>[];
  final assumptions = <String>[];
  if (loads.isEmpty) missing.add('équipements du circuit');
  final noPower = loads.where((l) => l.powerW == null || l.powerW! <= 0).length;
  if (noPower > 0) missing.add('puissance de $noPower équipement(s)');
  if (demandCoefficient <= 0 || demandCoefficient > 1) missing.add('coefficient de simultanéité valide (0 exclu à 1)');

  final resolved = resolveLoadSupply(installation, connection);
  missing.addAll(resolved.missing);
  assumptions.addAll(resolved.assumptions);
  final supply = resolved.supply;
  final isDc = supply?.phases == 0;

  if (!isDc && installation != null && !installation.dc) {
    final noCos = loads.where((l) => l.powerFactor == null || l.powerFactor! <= 0 || l.powerFactor! > 1).length;
    if (noCos > 0) missing.add('cos φ de $noCos équipement(s)');
  }
  final active = noPower == 0 && loads.isNotEmpty ? loads.fold<double>(0, (s, l) => s + l.powerW!) : null;
  if (missing.isNotEmpty || supply == null) {
    return CircuitCurrent(activeW: active, supply: supply, missing: missing, assumptions: assumptions);
  }

  final k = demandCoefficient;
  if (k < 1) assumptions.add('Coefficient de simultanéité du circuit : ${k.toStringAsFixed(2).replaceAll('.', ',')}.');
  if (isDc) {
    return CircuitCurrent(ibA: k * active! / supply.voltageV, activeW: active, supply: supply, assumptions: assumptions);
  }
  final s = loads.fold<double>(0, (a, l) => a + l.powerW! / l.powerFactor!);
  final double ib;
  if (supply.phases == 3) {
    assumptions.add('Charges supposées équilibrées entre les phases.');
    ib = k * s / (math.sqrt(3) * supply.voltageV);
  } else {
    ib = k * s / supply.voltageV;
  }
  return CircuitCurrent(ibA: ib, activeW: active, apparentVA: s, supply: supply, assumptions: assumptions);
}

/// Contrôle les données saisies d'un circuit.
List<ValidationIssue> validateCircuit({
  required String number,
  double? demandCoefficient,
  double? lengthM,
  double? ambientTempC,
  int? groupedCircuits,
  double? maxDropPct,
  double? iccKa,
}) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));
  if (number.trim().isEmpty) err('Le numéro du circuit est obligatoire.');
  if (demandCoefficient != null && (demandCoefficient <= 0 || demandCoefficient > 1)) {
    err('Le coefficient de simultanéité doit être compris entre 0 (exclu) et 1.');
  }
  if (lengthM != null && lengthM <= 0) err('La longueur doit être strictement positive.');
  if (groupedCircuits != null && groupedCircuits < 1) err('Le nombre de circuits regroupés doit être au moins 1.');
  if (maxDropPct != null && (maxDropPct <= 0 || maxDropPct > 100)) err('La chute de tension admissible doit être comprise entre 0 (exclu) et 100 %.');
  if (iccKa != null && iccKa <= 0) err('Le courant de court-circuit doit être strictement positif.');
  if (ambientTempC != null && (ambientTempC < -60 || ambientTempC > 150)) err('Température ambiante hors plage (-60 à 150 °C).');
  if (maxDropPct != null && maxDropPct > 10) {
    out.add(const ValidationIssue(IssueSeverity.warning, 'Chute de tension admissible supérieure à 10 % : vérifiez la valeur.'));
  }
  return out;
}

/// Données encore nécessaires avant le dimensionnement de la section (E22).
/// Liste vide = circuit prêt. Aucune valeur n'est supposée à la place de l'utilisateur.
List<String> sizingMissingData({
  required CircuitCurrent current,
  String? conductorMaterial,
  String? layingMode,
  double? ambientTempC,
  int? groupedCircuits,
  double? lengthM,
  double? maxDropPct,
  double? iccKa,
  String? protectionType,
}) {
  final m = <String>[...current.missing];
  if (conductorMaterial == null) m.add('matériau du conducteur');
  if (layingMode == null) m.add('mode de pose');
  if (ambientTempC == null) m.add('température ambiante');
  if (groupedCircuits == null) m.add('nombre de circuits regroupés');
  if (lengthM == null) m.add('longueur');
  if (maxDropPct == null) m.add('chute de tension admissible');
  if (iccKa == null) m.add('courant de court-circuit');
  if (protectionType == null || protectionType.trim().isEmpty) m.add('type de protection');
  return m;
}
