/// Gravité d'un contrôle de cohérence.
enum IssueSeverity { error, warning }

/// Résultat d'un contrôle : une erreur bloque la validation, un avertissement informe.
class ValidationIssue {
  const ValidationIssue(this.severity, this.message);
  final IssueSeverity severity;
  final String message;

  bool get isError => severity == IssueSeverity.error;

  @override
  String toString() => '${isError ? 'Erreur' : 'Avertissement'} : $message';
}

bool hasErrors(Iterable<ValidationIssue> issues) => issues.any((i) => i.isError);
