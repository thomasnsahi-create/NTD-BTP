import 'validation.dart';

const List<String> wallNames = ['north', 'south', 'east', 'west'];
const Map<String, String> wallLabels = {'north': 'Nord', 'south': 'Sud', 'east': 'Est', 'west': 'Ouest'};

/// Dimensions d'une pièce. Surface, périmètre et volume sont toujours calculés,
/// jamais saisis. Mêmes formules que les colonnes générées de la base (E17).
class RoomGeometry {
  const RoomGeometry({required this.lengthM, required this.widthM, required this.heightM});

  final double lengthM;
  final double widthM;
  final double heightM;

  /// SURFACE = LONGUEUR × LARGEUR.
  double get areaM2 => lengthM * widthM;

  /// PÉRIMÈTRE = 2 × (LONGUEUR + LARGEUR).
  double get perimeterM => 2 * (lengthM + widthM);

  /// VOLUME = LONGUEUR × LARGEUR × HAUTEUR.
  double get volumeM3 => lengthM * widthM * heightM;

  /// Longueur du mur : nord/sud suivent la longueur, est/ouest la largeur.
  double wallLengthM(String wall) => (wall == 'north' || wall == 'south') ? lengthM : widthM;
}

class RoomInput {
  const RoomInput({
    this.name = '',
    this.lengthM,
    this.widthM,
    this.heightM,
    this.ceilingHeightM,
    this.socketHeightM,
    this.switchHeightM,
    this.luminaireHeightM,
    this.panelXM,
    this.panelYM,
  });

  final String name;
  final double? lengthM;
  final double? widthM;
  final double? heightM;
  final double? ceilingHeightM;
  final double? socketHeightM;
  final double? switchHeightM;
  final double? luminaireHeightM;
  final double? panelXM;
  final double? panelYM;
}

List<ValidationIssue> validateRoom(RoomInput r) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));
  void warn(String m) => out.add(ValidationIssue(IssueSeverity.warning, m));

  if (r.name.trim().isEmpty) err('Le nom de la pièce est obligatoire.');
  for (final e in {'longueur': r.lengthM, 'largeur': r.widthM, 'hauteur': r.heightM}.entries) {
    if (e.value == null) {
      err('La ${e.key} est obligatoire.');
    } else if (e.value! <= 0) {
      err('La ${e.key} doit être strictement positive.');
    }
  }
  if (out.any((i) => i.isError)) return out;

  final h = r.heightM!;
  if (r.ceilingHeightM != null && r.ceilingHeightM! > h) {
    err('La hauteur de plafond ne peut pas dépasser la hauteur de la pièce.');
  }
  for (final e in {
    'prises': r.socketHeightM,
    'interrupteurs': r.switchHeightM,
    'luminaires': r.luminaireHeightM,
  }.entries) {
    if (e.value != null && e.value! > h) err('La hauteur des ${e.key} dépasse la hauteur de la pièce.');
  }
  if (r.panelXM != null && (r.panelXM! < 0 || r.panelXM! > r.lengthM!)) {
    err('La position X du tableau est hors de la pièce.');
  }
  if (r.panelYM != null && (r.panelYM! < 0 || r.panelYM! > r.widthM!)) {
    err('La position Y du tableau est hors de la pièce.');
  }
  if (r.lengthM! > 100 || r.widthM! > 100) warn('Dimensions supérieures à 100 m : vérifiez l\'unité (mètres).');
  if (h < 2) warn('Hauteur inférieure à 2 m : vérifiez la saisie.');
  return out;
}

/// Une porte ou une fenêtre doit tenir dans son mur.
List<ValidationIssue> validateOpening(
  RoomGeometry room, {
  required String wall,
  required double offsetM,
  required double widthM,
  double? heightM,
}) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));
  if (!wallNames.contains(wall)) err('Mur inconnu : $wall.');
  if (widthM <= 0) err('La largeur de l\'ouverture doit être positive.');
  if (offsetM < 0) err('Le décalage ne peut pas être négatif.');
  if (out.isNotEmpty) return out;
  final len = room.wallLengthM(wall);
  if (offsetM + widthM > len) {
    err('L\'ouverture dépasse le mur ${wallLabels[wall]} (${len.toStringAsFixed(2)} m).');
  }
  if (heightM != null && heightM > room.heightM) err('L\'ouverture est plus haute que la pièce.');
  return out;
}

/// Totaux d'un ensemble de pièces (étage, bâtiment ou projet).
class RoomTotals {
  const RoomTotals(this.count, this.areaM2, this.volumeM3);
  final int count;
  final double areaM2;
  final double volumeM3;
}

RoomTotals totalsOf(Iterable<RoomGeometry> rooms) {
  var n = 0;
  var a = 0.0;
  var v = 0.0;
  for (final r in rooms) {
    n++;
    a += r.areaM2;
    v += r.volumeM3;
  }
  return RoomTotals(n, a, v);
}
