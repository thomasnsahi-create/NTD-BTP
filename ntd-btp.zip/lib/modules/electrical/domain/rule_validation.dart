import 'validation.dart';

const List<String> buildingUsages = ['dwelling', 'office', 'commercial', 'industrial', 'public_assembly', 'other'];
const List<String> equipmentCategories = [
  'lighting', 'switch', 'socket', 'junction_box', 'panel', 'hvac', 'specialized', 'detector', 'security', 'communication',
];

/// Contrôle une règle de besoin avant enregistrement.
/// Une règle réglementaire doit citer sa référence : c'est ce qui la rend vérifiable.
List<ValidationIssue> validateRequirementRule({
  required String? buildingUsage,
  required String? roomTypeCode,
  required String? equipmentCode,
  required String kind,
  double? perAreaM2,
  int? minCount,
  int? maxCount,
  double? areaMinM2,
  double? areaMaxM2,
  String? reference,
}) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));
  if (buildingUsage == null || !buildingUsages.contains(buildingUsage)) err('Choisissez la destination du bâtiment.');
  if (roomTypeCode == null || roomTypeCode.trim().isEmpty) err('Choisissez le type de pièce.');
  if (equipmentCode == null || equipmentCode.trim().isEmpty) err('Choisissez le type d\'équipement.');
  if (kind != 'regulatory' && kind != 'design') err('Nature de règle inconnue.');
  if (perAreaM2 != null && perAreaM2 <= 0) err('La tranche de surface doit être strictement positive.');
  if (minCount == null || minCount < 0) err('Le minimum doit être un entier positif ou nul.');
  if (maxCount != null && minCount != null && maxCount < minCount) err('Le maximum ne peut pas être inférieur au minimum.');
  if (areaMinM2 != null && areaMaxM2 != null && areaMaxM2 <= areaMinM2) err('La surface maximale doit dépasser la surface minimale.');
  if (perAreaM2 == null && (minCount ?? 0) == 0 && kind == 'regulatory') {
    out.add(const ValidationIssue(IssueSeverity.warning, 'Règle sans effet : ni minimum ni tranche de surface.'));
  }
  if (kind == 'regulatory' && (reference == null || reference.trim().isEmpty)) {
    err('Une règle réglementaire doit indiquer sa référence (norme, article, texte).');
  }
  return out;
}

/// Contrôle une règle de coefficients Ku / Ks avant enregistrement.
List<ValidationIssue> validateDiversityRule({
  required String? category,
  String? buildingUsage,
  double? ku,
  double? ksBase,
  double? ksPerN,
  String? reference,
}) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));
  if (category == null || !equipmentCategories.contains(category)) err('Choisissez la catégorie d\'équipements.');
  if (buildingUsage != null && !buildingUsages.contains(buildingUsage)) err('Destination inconnue.');
  if (ku == null || ku <= 0 || ku > 1) err('Ku doit être compris entre 0 (exclu) et 1.');
  if (ksBase == null || ksBase < 0 || ksBase > 1) err('Ks de base doit être compris entre 0 et 1.');
  if (ksPerN == null || ksPerN < 0) err('Le terme en 1/n doit être positif ou nul.');
  if (ksBase != null && ksPerN != null && ksBase + ksPerN > 1 && ksPerN > 0) {
    out.add(const ValidationIssue(IssueSeverity.warning, 'Pour un seul équipement, Ks dépasse 1 : il sera ramené à 1.'));
  }
  if (reference == null || reference.trim().isEmpty) {
    err('Indiquez la référence ou la justification des coefficients.');
  }
  return out;
}
