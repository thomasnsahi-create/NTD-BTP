import 'validation.dart';

const Map<String, String> buildingUsageLabels = {
  'dwelling': 'Logement',
  'office': 'Bureaux / tertiaire',
  'commercial': 'Commerce',
  'industrial': 'Industriel',
  'public_assembly': 'Établissement recevant du public',
  'other': 'Autre',
};

/// Règle de besoin configurable (référentiel de l'organisation).
/// Pour la surface : la règle s'applique si surface > [areaMinM2] (exclu) et <= [areaMaxM2] (inclus).
class RequirementRule {
  const RequirementRule({
    required this.buildingUsage,
    required this.roomTypeCode,
    required this.equipmentCode,
    this.kind = 'regulatory',
    this.perAreaM2,
    this.minCount = 0,
    this.maxCount,
    this.areaMinM2,
    this.areaMaxM2,
    this.reference,
    this.isConfirmed = false,
    this.id,
    this.isOrg = false,
  });

  factory RequirementRule.fromMap(Map<String, dynamic> m) => RequirementRule(
        buildingUsage: m['building_usage'] as String,
        roomTypeCode: m['room_type_code'] as String,
        equipmentCode: m['equipment_type_code'] as String,
        kind: (m['kind'] ?? 'regulatory') as String,
        perAreaM2: (m['per_area_m2'] as num?)?.toDouble(),
        minCount: (m['min_count'] as num?)?.toInt() ?? 0,
        maxCount: (m['max_count'] as num?)?.toInt(),
        areaMinM2: (m['area_min_m2'] as num?)?.toDouble(),
        areaMaxM2: (m['area_max_m2'] as num?)?.toDouble(),
        reference: m['reference_text'] as String?,
        isConfirmed: m['is_confirmed'] == true,
        id: m['id'] as String?,
        isOrg: m['organization_id'] != null,
      );

  final String? id;

  /// Règle propre à l'organisation (sinon règle par défaut).
  final bool isOrg;
  final String buildingUsage;
  final String roomTypeCode;
  final String equipmentCode;
  final String kind; // regulatory | design
  final double? perAreaM2;
  final int minCount;
  final int? maxCount;
  final double? areaMinM2;
  final double? areaMaxM2;
  final String? reference;
  final bool isConfirmed;

  bool get isRegulatory => kind == 'regulatory';

  bool appliesTo(String usage, String roomCode, double areaM2) {
    if (buildingUsage != usage) return false;
    if (roomTypeCode.toUpperCase() != roomCode.toUpperCase()) return false;
    if (areaMinM2 != null && !(areaM2 > areaMinM2!)) return false;
    if (areaMaxM2 != null && areaM2 > areaMaxM2!) return false;
    return true;
  }

  /// max(minimum, ⌈surface / tranche⌉), plafonné par le maximum éventuel.
  int countFor(double areaM2) {
    var n = minCount;
    if (perAreaM2 != null) {
      final byArea = (areaM2 / perAreaM2! - 1e-9).ceil();
      if (byArea > n) n = byArea;
    }
    if (maxCount != null && n > maxCount!) n = maxCount!;
    return n;
  }
}

/// Besoin calculé pour un type d'équipement dans une pièce.
class NeedLine {
  const NeedLine({
    required this.equipmentCode,
    required this.regulatoryMin,
    required this.proposed,
    required this.references,
    required this.allConfirmed,
  });

  final String equipmentCode;

  /// Minimum issu des règles réglementaires (0 si aucune règle réglementaire).
  final int regulatoryMin;

  /// Quantité proposée : au moins le minimum réglementaire, plus les propositions de conception.
  final int proposed;
  final List<String> references;

  /// Faux si une règle utilisée est encore « à confirmer ».
  final bool allConfirmed;
}

class NeedsResult {
  const NeedsResult(this.lines, this.issues);
  final List<NeedLine> lines;
  final List<ValidationIssue> issues;
}

/// Propose les besoins d'une pièce à partir des règles configurées.
/// Sans destination de bâtiment ou sans règle correspondante, aucune quantité n'est inventée :
/// le résultat est vide et un message l'explique (les règles d'un logement ne sont jamais
/// appliquées à un autre type de bâtiment).
NeedsResult computeNeeds({
  required String? usage,
  required String? roomTypeCode,
  required double areaM2,
  required Iterable<RequirementRule> rules,
}) {
  if (usage == null) {
    return const NeedsResult([], [
      ValidationIssue(IssueSeverity.error, 'Renseignez d\'abord la destination du bâtiment.'),
    ]);
  }
  if (roomTypeCode == null) {
    return const NeedsResult([], [
      ValidationIssue(IssueSeverity.error, 'Choisissez le type de la pièce pour calculer ses besoins.'),
    ]);
  }
  final matching = rules.where((r) => r.appliesTo(usage, roomTypeCode, areaM2)).toList();
  if (matching.isEmpty) {
    return NeedsResult([], [
      ValidationIssue(
        IssueSeverity.warning,
        'Aucune règle définie pour « $roomTypeCode » (${buildingUsageLabels[usage] ?? usage}). Saisissez les besoins manuellement ou ajoutez des règles au référentiel.',
      ),
    ]);
  }
  final byEquipment = <String, List<RequirementRule>>{};
  for (final r in matching) {
    byEquipment.putIfAbsent(r.equipmentCode.toUpperCase(), () => []).add(r);
  }
  final lines = <NeedLine>[];
  final issues = <ValidationIssue>[];
  for (final e in byEquipment.entries) {
    var regMin = 0;
    var design = 0;
    final refs = <String>{};
    var confirmed = true;
    for (final r in e.value) {
      final n = r.countFor(areaM2);
      if (r.isRegulatory) {
        if (n > regMin) regMin = n;
      } else if (n > design) {
        design = n;
      }
      if (r.reference != null && r.reference!.trim().isNotEmpty) refs.add(r.reference!.trim());
      if (r.isRegulatory && !r.isConfirmed) confirmed = false;
    }
    lines.add(NeedLine(
      equipmentCode: e.key,
      regulatoryMin: regMin,
      proposed: design > regMin ? design : regMin,
      references: refs.toList()..sort(),
      allConfirmed: confirmed,
    ));
  }
  lines.sort((a, b) => a.equipmentCode.compareTo(b.equipmentCode));
  if (lines.any((l) => !l.allConfirmed)) {
    issues.add(const ValidationIssue(
      IssueSeverity.warning,
      'Certaines règles sont des valeurs par défaut à confirmer pour ce projet.',
    ));
  }
  return NeedsResult(lines, issues);
}

/// Contrôle une quantité retenue par rapport au minimum réglementaire.
/// Sous le minimum, une justification écrite est obligatoire pour valider.
List<ValidationIssue> validateNeedQuantity({
  required int quantity,
  required int regulatoryMin,
  String? justification,
}) {
  final out = <ValidationIssue>[];
  if (quantity < 0) {
    out.add(const ValidationIssue(IssueSeverity.error, 'La quantité ne peut pas être négative.'));
    return out;
  }
  if (quantity < regulatoryMin && (justification == null || justification.trim().isEmpty)) {
    out.add(ValidationIssue(
      IssueSeverity.error,
      'Quantité ($quantity) inférieure au minimum réglementaire ($regulatoryMin) : une justification est obligatoire.',
    ));
  }
  return out;
}

/// Écart entre le besoin retenu et ce qui est déjà implanté sur plan (E18).
/// Positif : il reste à implanter ; négatif : excédent.
int remainingToPlace(int needed, int placed) => needed - placed;

String _needKey(RequirementRule r) => '${r.buildingUsage}|${r.roomTypeCode.toUpperCase()}|${r.equipmentCode.toUpperCase()}';

/// Une règle de l'organisation remplace TOUTES les règles par défaut de même clé
/// (destination, type de pièce, équipement). Sans cela, une règle plus basse ne pourrait jamais
/// l'emporter sur le défaut, car le calcul retient le maximum des règles applicables.
List<RequirementRule> effectiveRequirementRules(Iterable<RequirementRule> rules) {
  final overridden = rules.where((r) => r.isOrg).map(_needKey).toSet();
  return rules.where((r) => r.isOrg || !overridden.contains(_needKey(r))).toList();
}
