import 'dart:math' as math;

/// Alimentation (installation) telle que saisie en E14.
class InstallationSupply {
  const InstallationSupply({
    required this.id,
    required this.name,
    this.dc = false,
    this.phases,
    this.nominalV,
    this.phaseToPhaseV,
    this.phaseToNeutralV,
  });

  factory InstallationSupply.fromMap(Map<String, dynamic> m) => InstallationSupply(
        id: m['id'] as String,
        name: (m['name'] ?? '').toString(),
        dc: m['current_type'] == 'dc',
        phases: (m['phases_count'] as num?)?.toInt(),
        nominalV: (m['nominal_voltage_v'] as num?)?.toDouble(),
        phaseToPhaseV: (m['phase_to_phase_v'] as num?)?.toDouble(),
        phaseToNeutralV: (m['phase_to_neutral_v'] as num?)?.toDouble(),
      );

  final String id;
  final String name;
  final bool dc;
  final int? phases;
  final double? nominalV;
  final double? phaseToPhaseV;
  final double? phaseToNeutralV;
}

/// Tension et nombre de phases effectivement vus par une charge. phases = 0 : courant continu.
class LoadSupply {
  const LoadSupply(this.voltageV, this.phases);
  final double voltageV;
  final int phases;

  String get label => phases == 0 ? '${_n(voltageV)} V c.c.' : '${_n(voltageV)} V ${phases == 3 ? 'triphasé' : 'monophasé'}';
  static String _n(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(1);
}

/// Résultat d'un calcul : soit un courant, soit la liste des données à demander.
class CurrentResult {
  const CurrentResult({this.currentA, this.supply, this.missing = const [], this.assumptions = const []});
  final double? currentA;
  final LoadSupply? supply;
  final List<String> missing;
  final List<String> assumptions;
  bool get isComplete => currentA != null;
}

class _Resolved {
  _Resolved(this.supply, this.missing, this.assumptions);
  final LoadSupply? supply;
  final List<String> missing;
  final List<String> assumptions;
}

/// Détermine la tension et le nombre de phases d'une charge selon son installation et son raccordement.
/// - c.c. : tension nominale de l'installation.
/// - installation monophasée : tension nominale (ou phase-neutre).
/// - installation triphasée : le raccordement (monophasé / triphasé) doit être précisé ;
///   monophasé = tension phase-neutre, triphasé = tension entre phases.
_Resolved _resolve(InstallationSupply? inst, String? connection) {
  final missing = <String>[];
  final assumptions = <String>[];
  if (inst == null) return _Resolved(null, ['installation d\'alimentation'], assumptions);
  if (inst.dc) {
    if (inst.nominalV == null) return _Resolved(null, ['tension nominale de « ${inst.name} »'], assumptions);
    return _Resolved(LoadSupply(inst.nominalV!, 0), missing, assumptions);
  }
  if (inst.phases == null) return _Resolved(null, ['nombre de phases de « ${inst.name} »'], assumptions);
  if (inst.phases == 1) {
    final u = inst.nominalV ?? inst.phaseToNeutralV;
    if (u == null) return _Resolved(null, ['tension nominale de « ${inst.name} »'], assumptions);
    return _Resolved(LoadSupply(u, 1), missing, assumptions);
  }
  if (inst.phases == 3) {
    if (connection == null) return _Resolved(null, ['raccordement (monophasé ou triphasé)'], assumptions);
    if (connection == 'three') {
      if (inst.phaseToPhaseV == null) return _Resolved(null, ['tension entre phases de « ${inst.name} »'], assumptions);
      return _Resolved(LoadSupply(inst.phaseToPhaseV!, 3), missing, assumptions);
    }
    if (inst.phaseToNeutralV != null) return _Resolved(LoadSupply(inst.phaseToNeutralV!, 1), missing, assumptions);
    if (inst.phaseToPhaseV != null) {
      assumptions.add('Tension phase-neutre déduite de U/√3.');
      return _Resolved(LoadSupply(inst.phaseToPhaseV! / math.sqrt(3), 1), missing, assumptions);
    }
    return _Resolved(null, ['tension phase-neutre ou entre phases de « ${inst.name} »'], assumptions);
  }
  return _Resolved(null, ['calcul non pris en charge pour ${inst.phases} phases : saisie manuelle'], assumptions);
}

/// Courant d'une charge :
///   monophasé  I = P / (U × cos φ × η)
///   triphasé   I = P / (√3 × U × cos φ × η)
///   continu    I = P / (U × η)
/// P = puissance utile si le rendement est renseigné, sinon puissance absorbée (η = 1, signalé).
/// Toute donnée manquante est listée dans [CurrentResult.missing] ; rien n'est inventé.
CurrentResult computeLoadCurrent({
  required double? powerW,
  required InstallationSupply? installation,
  String? connection,
  double? cosPhi,
  double? efficiency,
}) {
  final missing = <String>[];
  final assumptions = <String>[];
  if (powerW == null || powerW <= 0) missing.add('puissance');
  final r = _resolve(installation, connection);
  missing.addAll(r.missing);
  assumptions.addAll(r.assumptions);
  if (installation != null && !installation.dc) {
    if (cosPhi == null || cosPhi <= 0 || cosPhi > 1) missing.add('facteur de puissance (0 à 1)');
  }
  if (efficiency == null) {
    assumptions.add('Rendement non renseigné : puissance considérée comme absorbée (η = 1).');
  } else if (efficiency <= 0 || efficiency > 1) {
    missing.add('rendement valide (0 exclu à 1)');
  }
  if (missing.isNotEmpty || r.supply == null) {
    return CurrentResult(supply: r.supply, missing: missing, assumptions: assumptions);
  }
  final eta = efficiency ?? 1;
  final u = r.supply!.voltageV;
  final double i;
  switch (r.supply!.phases) {
    case 0:
      i = powerW! / (u * eta);
      break;
    case 3:
      i = powerW! / (math.sqrt(3) * u * cosPhi! * eta);
      break;
    default:
      i = powerW! / (u * cosPhi! * eta);
  }
  return CurrentResult(currentA: i, supply: r.supply, assumptions: assumptions);
}

/// Courant d'appel d'une installation à partir de sa puissance apparente d'appel (alternatif)
/// ou de sa puissance active (continu). Triphasé : I = S / (√3 × U) avec charges supposées équilibrées.
CurrentResult computeInstallationCurrent(InstallationSupply inst, {double? apparentVA, double? activeW}) {
  final missing = <String>[];
  final assumptions = <String>[];
  if (inst.dc) {
    if (inst.nominalV == null) missing.add('tension nominale');
    if (activeW == null) missing.add('puissance');
    if (missing.isNotEmpty) return CurrentResult(missing: missing);
    return CurrentResult(currentA: activeW! / inst.nominalV!, supply: LoadSupply(inst.nominalV!, 0));
  }
  if (apparentVA == null) missing.add('puissance apparente (facteurs de puissance manquants)');
  if (inst.phases == 3) {
    if (inst.phaseToPhaseV == null) missing.add('tension entre phases');
    if (missing.isNotEmpty) return CurrentResult(missing: missing);
    assumptions.add('Charges supposées équilibrées entre les phases.');
    return CurrentResult(
      currentA: apparentVA! / (math.sqrt(3) * inst.phaseToPhaseV!),
      supply: LoadSupply(inst.phaseToPhaseV!, 3),
      assumptions: assumptions,
    );
  }
  if (inst.phases == 1) {
    final u = inst.nominalV ?? inst.phaseToNeutralV;
    if (u == null) missing.add('tension nominale');
    if (missing.isNotEmpty) return CurrentResult(missing: missing);
    return CurrentResult(currentA: apparentVA! / u!, supply: LoadSupply(u, 1));
  }
  missing.add(inst.phases == null ? 'nombre de phases' : 'calcul non pris en charge pour ${inst.phases} phases');
  return CurrentResult(missing: missing);
}

/// Tension et nombre de phases vus par une charge ou un circuit (version publique de la résolution).
/// Retourne le [LoadSupply] ou la liste des données manquantes.
CurrentResult resolveLoadSupply(InstallationSupply? installation, String? connection) {
  final r = _resolve(installation, connection);
  return CurrentResult(supply: r.supply, missing: r.missing, assumptions: r.assumptions);
}
