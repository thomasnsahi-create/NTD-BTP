import 'dart:math' as math;
import 'room_geometry.dart';
import 'validation.dart';

/// Point d'un plan, en mètres, dans le repère de la pièce
/// (origine = coin nord-ouest, X vers l'est le long de la longueur, Y vers le sud le long de la largeur).
class PlanPoint {
  const PlanPoint(this.x, this.y);

  factory PlanPoint.fromJson(Map<String, dynamic> m) =>
      PlanPoint((m['x'] as num).toDouble(), (m['y'] as num).toDouble());

  final double x;
  final double y;

  Map<String, dynamic> toJson() => {'x': x, 'y': y};

  double distanceTo(PlanPoint o) => math.sqrt(math.pow(x - o.x, 2) + math.pow(y - o.y, 2));

  @override
  bool operator ==(Object other) => other is PlanPoint && other.x == x && other.y == y;

  @override
  int get hashCode => Object.hash(x, y);
}

/// Longueur horizontale d'un tracé : somme des segments réellement dessinés.
/// Même calcul que le trigger de la base (arrondi au millimètre).
double polylineLength(List<PlanPoint> points) {
  var total = 0.0;
  for (var i = 1; i < points.length; i++) {
    total += points[i - 1].distanceTo(points[i]);
  }
  return (total * 1000).round() / 1000;
}

bool insideRoom(RoomGeometry room, PlanPoint p) =>
    p.x >= 0 && p.x <= room.lengthM && p.y >= 0 && p.y <= room.widthM;

/// Aimante une valeur sur une grille de [step] mètres (step <= 0 : aucun aimantage).
double snapValue(double v, double step) => step <= 0 ? v : (v / step).round() * step;

PlanPoint snapPoint(PlanPoint p, double step) => PlanPoint(
      double.parse(snapValue(p.x, step).toStringAsFixed(3)),
      double.parse(snapValue(p.y, step).toStringAsFixed(3)),
    );

/// Ramène un point dans la pièce (pour un glissement qui dépasse un mur).
PlanPoint clampToRoom(RoomGeometry room, PlanPoint p) =>
    PlanPoint(p.x.clamp(0.0, room.lengthM).toDouble(), p.y.clamp(0.0, room.widthM).toDouble());

/// Indice du point de [candidates] le plus proche de [p] dans le rayon [radiusM], ou -1.
int nearestIndex(List<PlanPoint> candidates, PlanPoint p, double radiusM) {
  var best = -1;
  var bestD = radiusM;
  for (var i = 0; i < candidates.length; i++) {
    final d = candidates[i].distanceTo(p);
    if (d <= bestD) {
      best = i;
      bestD = d;
    }
  }
  return best;
}

/// Hauteur de pose proposée d'après le type d'équipement et les hauteurs de la pièce.
/// Retourne null si le type n'a pas de hauteur type : la hauteur est alors à saisir.
double? defaultMountHeight(String heightSource, {double? socketM, double? switchM, double? luminaireM}) {
  switch (heightSource) {
    case 'socket':
      return socketM;
    case 'switch':
      return switchM;
    case 'luminaire':
      return luminaireM;
    default:
      return null;
  }
}

List<ValidationIssue> validatePlacement(RoomGeometry room, PlanPoint p, {double? zM}) {
  final out = <ValidationIssue>[];
  if (!insideRoom(room, p)) {
    out.add(const ValidationIssue(IssueSeverity.error, 'La position est hors de la pièce.'));
  }
  if (zM != null && (zM < 0 || zM > room.heightM)) {
    out.add(const ValidationIssue(IssueSeverity.error, 'La hauteur de pose doit être comprise entre 0 et la hauteur de la pièce.'));
  }
  return out;
}

const Map<String, String> routeKindLabels = {
  'cable': 'Cheminement de câble',
  'cable_tray': 'Chemin de câbles',
  'duct': 'Gaine',
  'conduit': 'Conduit',
};

List<ValidationIssue> validateRoute(RoomGeometry room, List<PlanPoint> points) {
  final out = <ValidationIssue>[];
  void err(String m) => out.add(ValidationIssue(IssueSeverity.error, m));
  if (points.length < 2) {
    err('Un cheminement comporte au moins 2 points.');
    return out;
  }
  for (var i = 0; i < points.length; i++) {
    if (!insideRoom(room, points[i])) err('Le point ${i + 1} est hors de la pièce.');
  }
  if (polylineLength(points) <= 0) err('Le cheminement a une longueur nulle.');
  for (var i = 1; i < points.length; i++) {
    if (points[i] == points[i - 1]) {
      out.add(ValidationIssue(IssueSeverity.warning, 'Les points ${i} et ${i + 1} sont confondus.'));
    }
  }
  return out;
}
