import 'package:flutter/material.dart';
import '../domain/validation.dart';

/// Liste les erreurs (rouge) et avertissements (orange) d'un contrôle.
class IssuesView extends StatelessWidget {
  const IssuesView(this.issues, {super.key});

  final List<ValidationIssue> issues;

  @override
  Widget build(BuildContext context) {
    if (issues.isEmpty) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final i in issues)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(i.isError ? Icons.error_outline : Icons.warning_amber_outlined,
                  size: 16, color: i.isError ? scheme.error : Colors.orange.shade800),
              const SizedBox(width: 6),
              Expanded(child: Text(i.message, style: Theme.of(context).textTheme.bodySmall)),
            ]),
          ),
      ],
    );
  }
}
