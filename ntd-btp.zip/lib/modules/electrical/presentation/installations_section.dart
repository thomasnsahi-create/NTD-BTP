import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/validation.dart';
import '../domain/voltage_domain.dart';
import 'issues_view.dart';

const Map<String, String> _typeLabels = {
  'installation': 'Installation',
  'transformer': 'Transformateur',
  'substation': 'Poste électrique',
  'protection_cell': 'Cellule de protection',
  'distribution_network': 'Réseau de distribution',
  'link': 'Liaison électrique',
  'protection_device': 'Protection / appareillage',
};

/// E14 : installations rattachées à un domaine de tension.
class InstallationsSection extends StatefulWidget {
  const InstallationsSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<InstallationsSection> createState() => _InstallationsSectionState();
}

class _InstallationsSectionState extends State<InstallationsSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = [];
  List<Map<String, dynamic>> _domains = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _items = await _service.listInstallations(widget.projectId);
      _domains = await _service.listVoltageDomains();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  String _t(dynamic v) => v == null ? '' : formatQuantity(v as num);

  Future<void> _edit([Map<String, dynamic>? item]) async {
    if (_domains.isEmpty) {
      showSnack(context, 'Aucun domaine de tension disponible.');
      return;
    }
    final name = TextEditingController(text: (item?['name'] ?? '').toString());
    final nominal = TextEditingController(text: _t(item?['nominal_voltage_v']));
    final maxV = TextEditingController(text: _t(item?['max_voltage_v']));
    final pp = TextEditingController(text: _t(item?['phase_to_phase_v']));
    final pn = TextEditingController(text: _t(item?['phase_to_neutral_v']));
    final freq = TextEditingController(text: _t(item?['frequency_hz']));
    final supply = TextEditingController(text: (item?['supply_type'] ?? '').toString());
    final standard = TextEditingController(text: (item?['applicable_standard'] ?? '').toString());
    final design = TextEditingController(text: (item?['design_reference'] ?? '').toString());
    final verif = TextEditingController(text: (item?['verification_reference'] ?? '').toString());
    String domainId = (item?['voltage_domain_id'] ?? _domains.first['id']) as String;
    String type = (item?['installation_type'] ?? 'installation') as String;
    bool dc = item?['current_type'] == 'dc';
    int? phases = (item?['phases_count'] as num?)?.toInt();
    String? regime = item?['neutral_regime'] as String?;
    List<ValidationIssue> issues = [];

    InstallationData data() {
      final raw = _domains.firstWhere((d) => d['id'] == domainId);
      return InstallationData(
        domain: VoltageDomain.fromMap(raw),
        dc: dc,
        nominalV: parseOptionalNumber(nominal.text),
        maxV: parseOptionalNumber(maxV.text),
        phaseToPhaseV: parseOptionalNumber(pp.text),
        phaseToNeutralV: parseOptionalNumber(pn.text),
        frequencyHz: parseOptionalNumber(freq.text),
        phases: phases,
        neutralRegime: regime,
      );
    }

    String? orNull(TextEditingController c) => c.text.trim().isEmpty ? null : c.text.trim();

    final saved = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(item == null ? 'Nouvelle installation' : 'Modifier l\'installation'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Désignation')),
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: 'Nature'),
                items: _typeLabels.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
                onChanged: (v) => setD(() => type = v ?? type),
              ),
              DropdownButtonFormField<String>(
                value: domainId,
                decoration: const InputDecoration(labelText: 'Domaine de tension'),
                items: _domains.map((d) => DropdownMenuItem(value: d['id'] as String, child: Text('${d['code']} — ${d['label']}'))).toList(),
                onChanged: (v) => setD(() => domainId = v ?? domainId),
              ),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Courant continu'), value: dc, onChanged: (v) => setD(() => dc = v)),
              TextField(controller: nominal, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tension nominale (V)')),
              TextField(controller: maxV, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tension maximale (V)')),
              if (!dc) ...[
                TextField(controller: pp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tension entre phases (V)')),
                TextField(controller: pn, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tension phase-neutre (V)')),
                TextField(controller: freq, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Fréquence (Hz)')),
                DropdownButtonFormField<int?>(
                  value: phases,
                  decoration: const InputDecoration(labelText: 'Nombre de phases'),
                  items: const [
                    DropdownMenuItem<int?>(value: null, child: Text('Non renseigné')),
                    DropdownMenuItem<int?>(value: 1, child: Text('Monophasé')),
                    DropdownMenuItem<int?>(value: 2, child: Text('Biphasé')),
                    DropdownMenuItem<int?>(value: 3, child: Text('Triphasé')),
                  ],
                  onChanged: (v) => setD(() => phases = v),
                ),
                DropdownButtonFormField<String?>(
                  value: regime,
                  decoration: const InputDecoration(labelText: 'Régime de neutre'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Non renseigné')),
                    ...neutralRegimes.map((r) => DropdownMenuItem<String?>(value: r, child: Text(r))),
                  ],
                  onChanged: (v) => setD(() => regime = v),
                ),
              ],
              TextField(controller: supply, decoration: const InputDecoration(labelText: 'Type d\'alimentation')),
              TextField(controller: standard, decoration: const InputDecoration(labelText: 'Norme applicable')),
              TextField(controller: design, decoration: const InputDecoration(labelText: 'Référentiel de conception')),
              TextField(controller: verif, decoration: const InputDecoration(labelText: 'Référentiel de vérification')),
              const SizedBox(height: 8),
              Align(alignment: Alignment.centerLeft, child: IssuesView(issues)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () {
                final found = [
                  if (name.text.trim().isEmpty) const ValidationIssue(IssueSeverity.error, 'La désignation est obligatoire.'),
                  ...validateInstallation(data()),
                ];
                if (hasErrors(found)) {
                  setD(() => issues = found);
                } else {
                  issues = found;
                  Navigator.pop(c, true);
                }
              },
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
    if (saved != true) return;
    try {
      await _service.saveInstallation(
        widget.projectId,
        {
          'name': name.text.trim(),
          'installation_type': type,
          'voltage_domain_id': domainId,
          'current_type': dc ? 'dc' : 'ac',
          'nominal_voltage_v': parseOptionalNumber(nominal.text),
          'max_voltage_v': parseOptionalNumber(maxV.text),
          'phase_to_phase_v': dc ? null : parseOptionalNumber(pp.text),
          'phase_to_neutral_v': dc ? null : parseOptionalNumber(pn.text),
          'frequency_hz': dc ? null : parseOptionalNumber(freq.text),
          'phases_count': dc ? null : phases,
          'neutral_regime': dc ? null : regime,
          'supply_type': orNull(supply),
          'applicable_standard': orNull(standard),
          'design_reference': orNull(design),
          'verification_reference': orNull(verif),
        },
        id: item?['id'] as String?,
      );
      await _load();
      if (mounted && issues.isNotEmpty) showSnack(context, 'Enregistré avec ${issues.length} avertissement(s).');
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _delete(Map<String, dynamic> item) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer « ${item['name']} » ?');
    if (ok != true) return;
    try {
      await _service.deleteInstallation(item['id'] as String);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(child: Text('Installations (${_items.length})', style: Theme.of(context).textTheme.titleMedium)),
        FilledButton.tonalIcon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Ajouter')),
      ]),
      if (_items.isEmpty)
        const Padding(padding: EdgeInsets.all(24), child: Text('Aucune installation. Déclarez le domaine de tension et le régime de neutre avant de dimensionner.')),
      ..._items.map((i) {
        final dom = (i['elec_voltage_domains'] as Map?)?['code'] ?? '?';
        final phases = i['phases_count'];
        return Card(
          child: ListTile(
            title: Text('${i['name']}'),
            subtitle: Text('${_typeLabels[i['installation_type']] ?? i['installation_type']} • $dom • ${_t(i['nominal_voltage_v'])} V ${i['current_type'] == 'dc' ? 'c.c.' : 'c.a.'}'
                '${phases != null ? ' • $phases ph.' : ''}${i['neutral_regime'] != null ? ' • ${i['neutral_regime']}' : ''}'),
            onTap: () => _edit(i),
            trailing: IconButton(tooltip: 'Supprimer', icon: const Icon(Icons.delete_outline), onPressed: () => _delete(i)),
          ),
        );
      }),
    ]);
  }
}
