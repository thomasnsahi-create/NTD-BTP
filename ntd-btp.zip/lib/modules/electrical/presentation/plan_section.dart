import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/plan_geometry.dart';
import '../domain/room_geometry.dart';
import '../domain/validation.dart';
import 'issues_view.dart';

const Map<String, Color> _categoryColors = {
  'lighting': Color(0xFFF9A825),
  'switch': Color(0xFF6A1B9A),
  'socket': Color(0xFF1565C0),
  'junction_box': Color(0xFF5D4037),
  'panel': Color(0xFFC62828),
  'hvac': Color(0xFF00838F),
  'specialized': Color(0xFF2E7D32),
  'detector': Color(0xFFEF6C00),
  'security': Color(0xFFAD1457),
  'communication': Color(0xFF37474F),
};

const Map<String, Color> _routeColors = {
  'cable': Color(0xFF1565C0),
  'cable_tray': Color(0xFFEF6C00),
  'duct': Color(0xFF6D4C41),
  'conduit': Color(0xFF00897B),
};

const Map<String, double> _routeWidths = {'cable': 2, 'cable_tray': 5, 'duct': 5, 'conduit': 3};

enum _Tool { select, place, route }

/// E18 : implantation des équipements et dessin des cheminements dans une pièce, à l'échelle.
class PlanSection extends StatefulWidget {
  const PlanSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<PlanSection> createState() => _PlanSectionState();
}

class _PlanSectionState extends State<PlanSection> {
  static const double _pad = 28;
  static const double _maxCanvasHeight = 420;

  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _rooms = [];
  List<Map<String, dynamic>> _types = [];
  List<Map<String, dynamic>> _equipment = [];
  List<Map<String, dynamic>> _routes = [];
  List<Map<String, dynamic>> _openings = [];
  String? _roomId;

  _Tool _tool = _Tool.select;
  String? _typeId;
  String _routeKind = 'cable';
  bool _snap = true;
  String? _selectedId;
  String? _draggingId;
  bool _moved = false;
  final List<PlanPoint> _draft = [];
  final List<String?> _draftEquip = [];
  List<ValidationIssue> _issues = [];
  double _scale = 1;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Map<String, dynamic>? get _room {
    for (final r in _rooms) {
      if (r['id'] == _roomId) return r;
    }
    return null;
  }

  RoomGeometry _geo(Map<String, dynamic> r) => RoomGeometry(
        lengthM: (r['length_m'] as num).toDouble(),
        widthM: (r['width_m'] as num).toDouble(),
        heightM: (r['height_m'] as num).toDouble(),
      );

  double? _num(dynamic v) => (v as num?)?.toDouble();

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _rooms = await _service.listRooms(widget.projectId);
      _types = await _service.listEquipmentTypes();
      _typeId ??= _types.isEmpty ? null : _types.first['id'] as String;
      if (_roomId == null || _room == null) _roomId = _rooms.isEmpty ? null : _rooms.first['id'] as String;
      await _loadRoom();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadRoom() async {
    if (_roomId == null) {
      _equipment = [];
      _routes = [];
      _openings = [];
      return;
    }
    _equipment = await _service.listEquipment(_roomId!);
    _routes = await _service.listRoutes(_roomId!);
    _openings = await _service.listOpenings(_roomId!);
  }

  Future<void> _refreshRoom() async {
    try {
      await _loadRoom();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
    if (mounted) setState(() {});
  }

  Future<void> _selectRoom(String? id) async {
    setState(() {
      _roomId = id;
      _selectedId = null;
      _draft.clear();
      _draftEquip.clear();
      _issues = [];
    });
    await _refreshRoom();
  }

  // ---------------------------------------------------------------- Conversions
  Offset _toPx(PlanPoint p) => Offset(_pad + p.x * _scale, _pad + p.y * _scale);
  PlanPoint _toM(Offset o) => PlanPoint((o.dx - _pad) / _scale, (o.dy - _pad) / _scale);
  PlanPoint _equipPos(Map<String, dynamic> e) => PlanPoint(_num(e['x_m'])!, _num(e['y_m'])!);
  double get _hitRadiusM => 18 / _scale;
  double get _step => _snap ? 0.1 : 0;

  int _equipmentAt(PlanPoint p) => nearestIndex(_equipment.map(_equipPos).toList(), p, _hitRadiusM);

  String _typeLabel(Map<String, dynamic> e) => ((e['elec_equipment_types'] as Map?)?['label'] ?? '?').toString();

  // ---------------------------------------------------------------- Interactions
  Future<void> _onTap(Offset local) async {
    final room = _room;
    if (room == null) return;
    final geo = _geo(room);
    final raw = _toM(local);
    if (!insideRoom(geo, raw)) return;
    switch (_tool) {
      case _Tool.select:
        final i = _equipmentAt(raw);
        setState(() => _selectedId = i < 0 ? null : _equipment[i]['id'] as String);
        break;
      case _Tool.place:
        await _placeAt(room, geo, snapPoint(raw, _step));
        break;
      case _Tool.route:
        final i = _equipmentAt(raw);
        setState(() {
          if (i >= 0) {
            _draft.add(_equipPos(_equipment[i]));
            _draftEquip.add(_equipment[i]['id'] as String);
          } else {
            _draft.add(clampToRoom(geo, snapPoint(raw, _step)));
            _draftEquip.add(null);
          }
          _issues = [];
        });
        break;
    }
  }

  Future<void> _placeAt(Map<String, dynamic> room, RoomGeometry geo, PlanPoint p) async {
    final type = _types.where((t) => t['id'] == _typeId).toList();
    if (type.isEmpty) return;
    final t = type.first;
    final z = defaultMountHeight(
      (t['height_source'] ?? 'none') as String,
      socketM: _num(room['socket_height_m']),
      switchM: _num(room['switch_height_m']),
      luminaireM: _num(room['luminaire_height_m']),
    );
    final issues = validatePlacement(geo, p, zM: z);
    if (hasErrors(issues)) {
      showSnack(context, issues.first.message);
      return;
    }
    final sameType = _equipment.where((e) => e['equipment_type_id'] == _typeId).length;
    try {
      await _service.addEquipment({
        'project_id': widget.projectId,
        'room_id': room['id'],
        'equipment_type_id': _typeId,
        'label': '${t['code']}${sameType + 1}',
        'x_m': p.x,
        'y_m': p.y,
        'z_m': z,
      });
      await _refreshRoom();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  void _onPanStart(Offset local) {
    if (_tool != _Tool.select) return;
    final i = _equipmentAt(_toM(local));
    if (i < 0) return;
    setState(() {
      _draggingId = _equipment[i]['id'] as String;
      _selectedId = _draggingId;
      _moved = false;
    });
  }

  void _onPanUpdate(Offset local) {
    final room = _room;
    if (_draggingId == null || room == null) return;
    final p = snapPoint(clampToRoom(_geo(room), _toM(local)), _step);
    final i = _equipment.indexWhere((e) => e['id'] == _draggingId);
    if (i < 0) return;
    setState(() {
      _equipment[i] = {..._equipment[i], 'x_m': p.x, 'y_m': p.y};
      _moved = true;
    });
  }

  Future<void> _onPanEnd() async {
    final id = _draggingId;
    _draggingId = null;
    if (id == null || !_moved) return;
    final e = _equipment.firstWhere((x) => x['id'] == id);
    try {
      await _service.updateEquipment(id, {'x_m': e['x_m'], 'y_m': e['y_m']});
      await _refreshRoom();
    } catch (err) {
      if (mounted) showSnack(context, cleanError(err));
      await _refreshRoom();
    }
  }

  Future<void> _finishRoute() async {
    final room = _room;
    if (room == null) return;
    final issues = validateRoute(_geo(room), _draft);
    if (hasErrors(issues)) {
      setState(() => _issues = issues);
      return;
    }
    try {
      await _service.addRoute({
        'project_id': widget.projectId,
        'room_id': room['id'],
        'kind': _routeKind,
        'from_equipment_id': _draftEquip.first,
        'to_equipment_id': _draftEquip.last,
        'points': _draft.map((p) => p.toJson()).toList(),
      });
      setState(() {
        _draft.clear();
        _draftEquip.clear();
        _issues = [];
      });
      await _refreshRoom();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _editEquipment(Map<String, dynamic> e) async {
    final label = TextEditingController(text: (e['label'] ?? '').toString());
    final z = TextEditingController(text: e['z_m'] == null ? '' : formatQuantity(e['z_m'] as num));
    final power = TextEditingController(text: e['power_w'] == null ? '' : formatQuantity(e['power_w'] as num));
    final pf = TextEditingController(text: e['power_factor'] == null ? '' : formatQuantity(e['power_factor'] as num));
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(_typeLabel(e)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: label, decoration: const InputDecoration(labelText: 'Repère')),
          TextField(controller: z, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Hauteur de pose (m)')),
          TextField(controller: power, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Puissance (W)')),
          TextField(controller: pf, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Facteur de puissance cos φ (0 à 1)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (ok != true) return;
    final zv = parseOptionalNumber(z.text);
    final pfv = parseOptionalNumber(pf.text);
    if (pfv != null && (pfv <= 0 || pfv > 1)) {
      if (mounted) showSnack(context, 'Le facteur de puissance doit être compris entre 0 (exclu) et 1.');
      return;
    }
    final room = _room;
    if (room != null) {
      final issues = validatePlacement(_geo(room), _equipPos(e), zM: zv);
      if (hasErrors(issues)) {
        if (mounted) showSnack(context, issues.first.message);
        return;
      }
    }
    try {
      await _service.updateEquipment(e['id'] as String, {
        'label': label.text.trim().isEmpty ? null : label.text.trim(),
        'z_m': zv,
        'power_w': parseOptionalNumber(power.text),
        'power_factor': pfv,
      });
      await _refreshRoom();
    } catch (err) {
      if (mounted) showSnack(context, cleanError(err));
    }
  }

  Future<void> _deleteEquipment(Map<String, dynamic> e) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer « ${e['label'] ?? _typeLabel(e)} » ? Les cheminements restent tracés.');
    if (ok != true) return;
    try {
      await _service.deleteEquipment(e['id'] as String);
      if (_selectedId == e['id']) _selectedId = null;
      await _refreshRoom();
    } catch (err) {
      if (mounted) showSnack(context, cleanError(err));
    }
  }

  Future<void> _deleteRoute(Map<String, dynamic> r) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer ce cheminement ?');
    if (ok != true) return;
    try {
      await _service.deleteRoute(r['id'] as String);
      await _refreshRoom();
    } catch (err) {
      if (mounted) showSnack(context, cleanError(err));
    }
  }

  // ---------------------------------------------------------------- UI
  Widget _toolbar() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Wrap(spacing: 8, children: [
        ChoiceChip(label: const Text('Sélection / déplacer'), selected: _tool == _Tool.select, onSelected: (_) => setState(() => _tool = _Tool.select)),
        ChoiceChip(label: const Text('Placer'), selected: _tool == _Tool.place, onSelected: (_) => setState(() => _tool = _Tool.place)),
        ChoiceChip(label: const Text('Tracer un cheminement'), selected: _tool == _Tool.route, onSelected: (_) => setState(() => _tool = _Tool.route)),
      ]),
      if (_tool == _Tool.place)
        DropdownButtonFormField<String>(
          value: _typeId,
          decoration: const InputDecoration(labelText: 'Équipement à placer'),
          items: _types.map((t) => DropdownMenuItem(value: t['id'] as String, child: Text('${t['symbol']} — ${t['label']}'))).toList(),
          onChanged: (v) => setState(() => _typeId = v),
        ),
      if (_tool == _Tool.route) ...[
        DropdownButtonFormField<String>(
          value: _routeKind,
          decoration: const InputDecoration(labelText: 'Nature du cheminement'),
          items: routeKindLabels.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
          onChanged: (v) => setState(() => _routeKind = v ?? _routeKind),
        ),
        Row(children: [
          Expanded(child: Text(_draft.length < 2 ? 'Touchez le plan pour ajouter des points (${_draft.length}).' : '${_draft.length} points • ${formatQuantity(polylineLength(_draft))} m')),
          TextButton(onPressed: _draft.isEmpty ? null : () => setState(() {
                _draft.removeLast();
                _draftEquip.removeLast();
              }), child: const Text('Annuler le dernier')),
          FilledButton(onPressed: _draft.length < 2 ? null : _finishRoute, child: const Text('Terminer')),
        ]),
        IssuesView(_issues),
      ],
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Aimanter sur une grille de 10 cm'),
        value: _snap,
        onChanged: (v) => setState(() => _snap = v),
      ),
    ]);
  }

  Widget _canvas(Map<String, dynamic> room) {
    final geo = _geo(room);
    return LayoutBuilder(builder: (context, constraints) {
      final availW = constraints.maxWidth - 2 * _pad;
      var scale = availW / geo.lengthM;
      if (scale * geo.widthM > _maxCanvasHeight - 2 * _pad) scale = (_maxCanvasHeight - 2 * _pad) / geo.widthM;
      _scale = scale;
      final size = Size(geo.lengthM * scale + 2 * _pad, geo.widthM * scale + 2 * _pad);
      return Center(
        child: GestureDetector(
          onTapUp: (d) => _onTap(d.localPosition),
          onPanStart: (d) => _onPanStart(d.localPosition),
          onPanUpdate: (d) => _onPanUpdate(d.localPosition),
          onPanEnd: (_) => _onPanEnd(),
          child: CustomPaint(
            size: size,
            painter: _PlanPainter(
              geo: geo,
              scale: scale,
              pad: _pad,
              equipment: _equipment
                  .map((e) => _PlanItem(
                        id: e['id'] as String,
                        pos: _equipPos(e),
                        symbol: ((e['elec_equipment_types'] as Map?)?['symbol'] ?? '?').toString(),
                        category: ((e['elec_equipment_types'] as Map?)?['category'] ?? '').toString(),
                      ))
                  .toList(),
              routes: _routes
                  .map((r) => _PlanRoute(
                        kind: r['kind'] as String,
                        points: (r['points'] as List).map((p) => PlanPoint.fromJson(Map<String, dynamic>.from(p as Map))).toList(),
                      ))
                  .toList(),
              openings: _openings,
              draft: List<PlanPoint>.of(_draft),
              selectedId: _selectedId,
              panel: (_num(room['panel_x_m']) != null && _num(room['panel_y_m']) != null)
                  ? PlanPoint(_num(room['panel_x_m'])!, _num(room['panel_y_m'])!)
                  : null,
              lineColor: Theme.of(context).colorScheme.outline,
              fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
              textColor: Theme.of(context).colorScheme.onSurface,
            ),
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    if (_rooms.isEmpty) {
      return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Créez d\'abord des pièces (section « Pièces ») pour pouvoir y implanter des équipements.')));
    }
    final room = _room!;
    final selected = _equipment.where((e) => e['id'] == _selectedId).toList();
    final totalRoute = _routes.fold<double>(0, (s, r) => s + ((r['horizontal_length_m'] as num?)?.toDouble() ?? 0));
    return ListView(padding: const EdgeInsets.all(16), children: [
      DropdownButtonFormField<String>(
        value: _roomId,
        decoration: const InputDecoration(labelText: 'Pièce'),
        items: _rooms
            .map((r) => DropdownMenuItem(
                  value: r['id'] as String,
                  child: Text('${r['name']} — ${formatQuantity(r['length_m'] as num)} × ${formatQuantity(r['width_m'] as num)} m'),
                ))
            .toList(),
        onChanged: _selectRoom,
      ),
      const SizedBox(height: 8),
      _toolbar(),
      const SizedBox(height: 8),
      _canvas(room),
      const SizedBox(height: 4),
      const Text('Repère : nord en haut, origine au coin nord-ouest. Les longueurs de cheminement sont celles du tracé réel (horizontales).', style: TextStyle(fontSize: 12)),
      if (selected.isNotEmpty)
        Card(
          child: ListTile(
            title: Text('${selected.first['label'] ?? _typeLabel(selected.first)} — ${_typeLabel(selected.first)}'),
            subtitle: Text('x ${formatQuantity(selected.first['x_m'] as num)} m • y ${formatQuantity(selected.first['y_m'] as num)} m'
                '${selected.first['z_m'] != null ? ' • h ${formatQuantity(selected.first['z_m'] as num)} m' : ' • hauteur à renseigner'}'
                '${selected.first['power_w'] != null ? ' • ${formatQuantity(selected.first['power_w'] as num)} W' : ' • puissance à renseigner'}'),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(tooltip: 'Modifier', icon: const Icon(Icons.edit_outlined), onPressed: () => _editEquipment(selected.first)),
              IconButton(tooltip: 'Supprimer', icon: const Icon(Icons.delete_outline), onPressed: () => _deleteEquipment(selected.first)),
            ]),
          ),
        ),
      const SizedBox(height: 8),
      Text('Équipements (${_equipment.length})', style: Theme.of(context).textTheme.titleSmall),
      if (_equipment.isEmpty) const Text('Aucun équipement implanté dans cette pièce.'),
      ..._equipment.map((e) => ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            selected: e['id'] == _selectedId,
            title: Text('${e['label'] ?? ''} ${_typeLabel(e)}'),
            subtitle: Text('x ${formatQuantity(e['x_m'] as num)} • y ${formatQuantity(e['y_m'] as num)} m'),
            onTap: () => setState(() => _selectedId = e['id'] as String),
          )),
      const SizedBox(height: 8),
      Text('Cheminements (${_routes.length}) • ${formatQuantity(double.parse(totalRoute.toStringAsFixed(3)))} m horizontaux', style: Theme.of(context).textTheme.titleSmall),
      if (_routes.isEmpty) const Text('Aucun cheminement tracé.'),
      ..._routes.map((r) => ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.timeline, color: _routeColors[r['kind']]),
            title: Text(routeKindLabels[r['kind']] ?? r['kind'].toString()),
            subtitle: Text('${formatQuantity(r['horizontal_length_m'] as num)} m • ${(r['points'] as List).length} points'),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _deleteRoute(r)),
          )),
    ]);
  }
}

class _PlanItem {
  const _PlanItem({required this.id, required this.pos, required this.symbol, required this.category});
  final String id;
  final PlanPoint pos;
  final String symbol;
  final String category;
}

class _PlanRoute {
  const _PlanRoute({required this.kind, required this.points});
  final String kind;
  final List<PlanPoint> points;
}

class _PlanPainter extends CustomPainter {
  _PlanPainter({
    required this.geo,
    required this.scale,
    required this.pad,
    required this.equipment,
    required this.routes,
    required this.openings,
    required this.draft,
    required this.selectedId,
    required this.panel,
    required this.lineColor,
    required this.fillColor,
    required this.textColor,
  });

  final RoomGeometry geo;
  final double scale;
  final double pad;
  final List<_PlanItem> equipment;
  final List<_PlanRoute> routes;
  final List<Map<String, dynamic>> openings;
  final List<PlanPoint> draft;
  final String? selectedId;
  final PlanPoint? panel;
  final Color lineColor;
  final Color fillColor;
  final Color textColor;

  Offset _px(PlanPoint p) => Offset(pad + p.x * scale, pad + p.y * scale);

  void _text(Canvas canvas, String s, Offset center, {double size = 11, Color? color, FontWeight? weight}) {
    final tp = TextPainter(
      text: TextSpan(text: s, style: TextStyle(fontSize: size, color: color ?? textColor, fontWeight: weight)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  void paint(Canvas canvas, Size size) {
    final room = Rect.fromPoints(_px(const PlanPoint(0, 0)), _px(PlanPoint(geo.lengthM, geo.widthM)));
    canvas.drawRect(room, Paint()..color = fillColor);

    // Grille : 0,5 m (fine) et 1 m (marquée).
    final fine = Paint()..color = lineColor.withOpacity(0.15)..strokeWidth = 0.5;
    final bold = Paint()..color = lineColor.withOpacity(0.3)..strokeWidth = 0.8;
    for (var x = 0.5; x < geo.lengthM; x += 0.5) {
      canvas.drawLine(_px(PlanPoint(x, 0)), _px(PlanPoint(x, geo.widthM)), x % 1 == 0 ? bold : fine);
    }
    for (var y = 0.5; y < geo.widthM; y += 0.5) {
      canvas.drawLine(_px(PlanPoint(0, y)), _px(PlanPoint(geo.lengthM, y)), y % 1 == 0 ? bold : fine);
    }

    // Murs.
    canvas.drawRect(room, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = lineColor);

    // Portes et fenêtres.
    for (final o in openings) {
      final off = (o['offset_m'] as num).toDouble();
      final w = (o['width_m'] as num).toDouble();
      PlanPoint a;
      PlanPoint b;
      switch (o['wall']) {
        case 'north':
          a = PlanPoint(off, 0);
          b = PlanPoint(off + w, 0);
          break;
        case 'south':
          a = PlanPoint(off, geo.widthM);
          b = PlanPoint(off + w, geo.widthM);
          break;
        case 'west':
          a = PlanPoint(0, off);
          b = PlanPoint(0, off + w);
          break;
        default:
          a = PlanPoint(geo.lengthM, off);
          b = PlanPoint(geo.lengthM, off + w);
      }
      canvas.drawLine(
        _px(a),
        _px(b),
        Paint()
          ..strokeWidth = 6
          ..color = o['kind'] == 'door' ? const Color(0xFF8D6E63) : const Color(0xFF4FC3F7),
      );
    }

    // Cotes.
    _text(canvas, '${geo.lengthM} m', Offset(room.center.dx, pad / 2));
    _text(canvas, '${geo.widthM} m', Offset(pad / 2, room.center.dy));

    // Position du tableau saisie sur la fiche de la pièce.
    if (panel != null) {
      final c = _px(panel!);
      canvas.drawRect(Rect.fromCenter(center: c, width: 22, height: 22),
          Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFFC62828));
    }

    // Cheminements enregistrés.
    for (final r in routes) {
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..strokeWidth = _routeWidths[r.kind] ?? 2
        ..color = (_routeColors[r.kind] ?? Colors.blue).withOpacity(0.85);
      final path = Path();
      for (var i = 0; i < r.points.length; i++) {
        final o = _px(r.points[i]);
        i == 0 ? path.moveTo(o.dx, o.dy) : path.lineTo(o.dx, o.dy);
      }
      canvas.drawPath(path, paint);
    }

    // Tracé en cours.
    if (draft.isNotEmpty) {
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Colors.red;
      final path = Path();
      for (var i = 0; i < draft.length; i++) {
        final o = _px(draft[i]);
        i == 0 ? path.moveTo(o.dx, o.dy) : path.lineTo(o.dx, o.dy);
        canvas.drawCircle(o, 3.5, Paint()..color = Colors.red);
      }
      canvas.drawPath(path, paint);
    }

    // Équipements.
    for (final e in equipment) {
      final c = _px(e.pos);
      final color = _categoryColors[e.category] ?? Colors.grey;
      if (e.id == selectedId) {
        canvas.drawCircle(c, 16, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5..color = Colors.black87);
      }
      canvas.drawCircle(c, 12, Paint()..color = color);
      _text(canvas, e.symbol, c, size: e.symbol.length > 1 ? 9 : 11, color: Colors.white, weight: FontWeight.bold);
    }
  }

  @override
  bool shouldRepaint(covariant _PlanPainter old) => true;
}
