import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/current_calc.dart';
import '../domain/power_balance.dart';
import 'issues_view.dart';
import '../domain/validation.dart';

String _amps(double a) => '${a.toStringAsFixed(2).replaceAll('.', ',')} A';
String _kva(double va) => '${(va / 1000).toStringAsFixed(2).replaceAll('.', ',')} kVA';

/// E21 : courant de chaque équipement et courant d'appel de chaque installation.
class CurrentsSection extends StatefulWidget {
  const CurrentsSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<CurrentsSection> createState() => _CurrentsSectionState();
}

class _CurrentsSectionState extends State<CurrentsSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _rows = [];
  List<InstallationSupply> _installations = [];
  List<DiversityRule> _rules = [];
  String? _usage;
  double _overall = 1;
  double _reserve = 1;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _rows = await _service.listCurrentItems(widget.projectId);
      _installations = (await _service.listInstallations(widget.projectId)).map(InstallationSupply.fromMap).toList();
      _rules = effectiveDiversityRules((await _service.listDiversityRules()).map(DiversityRule.fromMap));
      final settings = await _service.getProjectSettings(widget.projectId);
      _usage = settings?['building_usage'] as String?;
      _overall = (settings?['overall_simultaneity'] as num?)?.toDouble() ?? 1;
      _reserve = (settings?['reserve_factor'] as num?)?.toDouble() ?? 1;
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  InstallationSupply? _inst(String? id) {
    for (final i in _installations) {
      if (i.id == id) return i;
    }
    return null;
  }

  double? _d(dynamic v) => (v as num?)?.toDouble();
  String _label(Map<String, dynamic> r) => (r['label'] ?? (r['elec_equipment_types'] as Map?)?['label'] ?? '?').toString();

  CurrentResult _loadCurrent(Map<String, dynamic> r) => computeLoadCurrent(
        powerW: _d(r['power_w']),
        installation: _inst(r['installation_id'] as String?),
        connection: r['connection'] as String?,
        cosPhi: _d(r['power_factor']),
        efficiency: _d(r['efficiency']),
      );

  Future<void> _edit(Map<String, dynamic> r) async {
    String? installationId = r['installation_id'] as String?;
    String? connection = r['connection'] as String?;
    final pf = TextEditingController(text: r['power_factor'] == null ? '' : formatQuantity(r['power_factor'] as num));
    final eff = TextEditingController(text: r['efficiency'] == null ? '' : formatQuantity(r['efficiency'] as num));
    List<ValidationIssue> issues = [];
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(_label(r)),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String?>(
                value: installationId,
                decoration: const InputDecoration(labelText: 'Installation d\'alimentation'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Non rattaché')),
                  ..._installations.map((i) => DropdownMenuItem<String?>(value: i.id, child: Text(i.name))),
                ],
                onChanged: (v) => setD(() => installationId = v),
              ),
              DropdownButtonFormField<String?>(
                value: connection,
                decoration: const InputDecoration(labelText: 'Raccordement'),
                items: const [
                  DropdownMenuItem<String?>(value: null, child: Text('Non précisé')),
                  DropdownMenuItem<String?>(value: 'single', child: Text('Monophasé')),
                  DropdownMenuItem<String?>(value: 'three', child: Text('Triphasé')),
                ],
                onChanged: (v) => setD(() => connection = v),
              ),
              TextField(controller: pf, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Facteur de puissance cos φ (0 à 1)')),
              TextField(controller: eff, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Rendement η (0 à 1)')),
              const SizedBox(height: 8),
              Align(alignment: Alignment.centerLeft, child: IssuesView(issues)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () {
                final p = parseOptionalNumber(pf.text);
                final e = parseOptionalNumber(eff.text);
                final found = <ValidationIssue>[
                  if (p != null && (p <= 0 || p > 1)) const ValidationIssue(IssueSeverity.error, 'cos φ : entre 0 (exclu) et 1.'),
                  if (e != null && (e <= 0 || e > 1)) const ValidationIssue(IssueSeverity.error, 'Rendement : entre 0 (exclu) et 1.'),
                ];
                if (found.isNotEmpty) {
                  setD(() => issues = found);
                } else {
                  Navigator.pop(c, true);
                }
              },
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await _service.updateEquipment(r['id'] as String, {
        'installation_id': installationId,
        'connection': connection,
        'power_factor': parseOptionalNumber(pf.text),
        'efficiency': parseOptionalNumber(eff.text),
      });
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Widget _installationCard(InstallationSupply inst) {
    final mine = _rows.where((r) => r['installation_id'] == inst.id).toList();
    final items = mine.map((r) {
      final t = r['elec_equipment_types'] as Map?;
      return PowerItem(
        id: r['id'] as String,
        label: _label(r),
        roomId: r['room_id'] as String,
        roomName: ((r['elec_rooms'] as Map?)?['name'] ?? '?').toString(),
        category: (t?['category'] ?? 'specialized').toString(),
        powerW: absorbedPower(_d(r['power_w']), _d(r['efficiency'])),
        powerFactor: _d(r['power_factor']),
      );
    }).toList();
    final b = computePowerBalance(items: items, rules: _rules, usage: _usage, overallSimultaneity: _overall, reserveFactor: _reserve);
    final res = computeInstallationCurrent(inst, apparentVA: b.apparentDemandVA, activeW: b.demandW);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(inst.name, style: Theme.of(context).textTheme.titleSmall),
          Text('${mine.length} équipement(s) rattaché(s) • ${b.itemsWithPower} avec puissance'),
          if (inst.dc) Text('Puissance d\'appel : ${(b.demandW / 1000).toStringAsFixed(2).replaceAll('.', ',')} kW')
          else Text(b.apparentDemandVA == null ? 'Puissance apparente d\'appel : non calculée' : 'Puissance apparente d\'appel : ${_kva(b.apparentDemandVA!)}'),
          const SizedBox(height: 4),
          if (res.currentA != null)
            Text('Courant d\'appel : ${_amps(res.currentA!)} (${res.supply!.label})', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))
          else
            Text(mine.isEmpty ? 'Aucun équipement rattaché.' : 'À compléter : ${res.missing.join(', ')}'),
          for (final a in res.assumptions) Text('• $a', style: const TextStyle(fontSize: 12)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final unattached = _rows.where((r) => r['installation_id'] == null).length;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Calcul des courants', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 4),
      const Text('Monophasé I = P / (U × cos φ × η) • triphasé I = P / (√3 × U × cos φ × η) • continu I = P / (U × η). '
          'Rattachez chaque équipement à une installation (E14) ; les données manquantes sont demandées, jamais supposées.'),
      const SizedBox(height: 8),
      Text('Installations', style: Theme.of(context).textTheme.titleSmall),
      if (_installations.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aucune installation : créez-en dans la section « Installations ».')),
      ..._installations.map(_installationCard),
      const SizedBox(height: 8),
      Text('Équipements (${_rows.length})${unattached > 0 ? ' • $unattached non rattaché(s)' : ''}', style: Theme.of(context).textTheme.titleSmall),
      if (_rows.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aucun équipement : implantez-en dans la section « Implantation ».')),
      ..._rows.map((r) {
        final res = _loadCurrent(r);
        final room = ((r['elec_rooms'] as Map?)?['name'] ?? '?').toString();
        final power = _d(r['power_w']);
        return Card(
          child: ListTile(
            title: Text('${_label(r)} — $room'),
            subtitle: Text([
              power == null ? 'puissance à renseigner' : '${formatQuantity(power)} W',
              if (res.currentA != null) 'I = ${_amps(res.currentA!)} (${res.supply!.label})' else 'à compléter : ${res.missing.join(', ')}',
              ...res.assumptions,
            ].join('\n')),
            isThreeLine: true,
            trailing: const Icon(Icons.edit_outlined),
            onTap: () => _edit(r),
          ),
        );
      }),
    ]);
  }
}
