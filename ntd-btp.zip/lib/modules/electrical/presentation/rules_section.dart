import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/power_balance.dart';
import '../domain/requirements_engine.dart';
import '../domain/rule_validation.dart';
import '../domain/validation.dart';
import 'issues_view.dart';

const Map<String, String> _catLabels = {
  'lighting': 'Éclairage',
  'switch': 'Commande',
  'socket': 'Prises de courant',
  'junction_box': 'Boîtes de dérivation',
  'panel': 'Tableaux',
  'hvac': 'Climatisation',
  'specialized': 'Équipements spécialisés',
  'detector': 'Détecteurs',
  'security': 'Sécurité',
  'communication': 'Communication',
};

String _n(num? v) => v == null ? '' : formatQuantity(v);

/// Gestion des règles de l'organisation : besoins par pièce (E19) et coefficients Ku / Ks (E20).
/// Une règle de l'organisation remplace la règle par défaut de même clé ; les défauts ne sont jamais modifiés.
class RulesSection extends StatefulWidget {
  const RulesSection({super.key, required this.organizationId});

  final String organizationId;

  @override
  State<RulesSection> createState() => _RulesSectionState();
}

class _RulesSectionState extends State<RulesSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  int _tab = 0;
  String? _usageFilter;
  List<RequirementRule> _needRules = [];
  List<DiversityRule> _coefRules = [];
  List<Map<String, dynamic>> _roomTypes = [];
  List<Map<String, dynamic>> _equipTypes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _needRules = (await _service.listRequirementRules()).map(RequirementRule.fromMap).toList();
      _coefRules = (await _service.listDiversityRules()).map(DiversityRule.fromMap).toList();
      _roomTypes = await _service.listRoomTypes();
      _equipTypes = await _service.listEquipmentTypes();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  // ---------------------------------------------------------------- Règles de besoins
  String _needFormula(RequirementRule r) {
    final parts = <String>[];
    if (r.perAreaM2 != null) parts.add('1 par ${_n(r.perAreaM2)} m²');
    parts.add('min. ${r.minCount}');
    if (r.maxCount != null) parts.add('max. ${r.maxCount}');
    if (r.areaMinM2 != null) parts.add('surface > ${_n(r.areaMinM2)} m²');
    if (r.areaMaxM2 != null) parts.add('surface ≤ ${_n(r.areaMaxM2)} m²');
    return parts.join(' • ');
  }

  Future<void> _editNeedRule(RequirementRule? base, {required bool copy}) async {
    String? usage = base?.buildingUsage ?? _usageFilter;
    String? room = base?.roomTypeCode;
    String? equip = base?.equipmentCode;
    String kind = base?.kind ?? 'regulatory';
    bool confirmed = base?.isOrg == true ? base!.isConfirmed : false;
    final perArea = TextEditingController(text: _n(base?.perAreaM2));
    final minC = TextEditingController(text: '${base?.minCount ?? 0}');
    final maxC = TextEditingController(text: base?.maxCount == null ? '' : '${base!.maxCount}');
    final aMin = TextEditingController(text: _n(base?.areaMinM2));
    final aMax = TextEditingController(text: _n(base?.areaMaxM2));
    final ref = TextEditingController(text: copy ? '' : (base?.reference ?? ''));
    List<ValidationIssue> issues = [];

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(base == null ? 'Nouvelle règle de besoin' : copy ? 'Copier pour mon organisation' : 'Modifier la règle'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String?>(
                value: usage,
                decoration: const InputDecoration(labelText: 'Destination du bâtiment'),
                items: buildingUsageLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))).toList(),
                onChanged: (v) => setD(() => usage = v),
              ),
              DropdownButtonFormField<String?>(
                value: room,
                decoration: const InputDecoration(labelText: 'Type de pièce'),
                items: _roomTypes.map((t) => DropdownMenuItem<String?>(value: t['code'] as String, child: Text('${t['label']}'))).toList(),
                onChanged: (v) => setD(() => room = v),
              ),
              DropdownButtonFormField<String?>(
                value: equip,
                decoration: const InputDecoration(labelText: 'Équipement'),
                items: _equipTypes.map((t) => DropdownMenuItem<String?>(value: t['code'] as String, child: Text('${t['label']}'))).toList(),
                onChanged: (v) => setD(() => equip = v),
              ),
              DropdownButtonFormField<String>(
                value: kind,
                decoration: const InputDecoration(labelText: 'Nature'),
                items: const [
                  DropdownMenuItem(value: 'regulatory', child: Text('Minimum réglementaire')),
                  DropdownMenuItem(value: 'design', child: Text('Proposition de conception')),
                ],
                onChanged: (v) => setD(() => kind = v ?? kind),
              ),
              TextField(controller: perArea, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '1 équipement par tranche de (m²) — optionnel')),
              Row(children: [
                Expanded(child: TextField(controller: minC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Minimum'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: maxC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Maximum'))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: aMin, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Surface > (m²)'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: aMax, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Surface ≤ (m²)'))),
              ]),
              TextField(controller: ref, maxLines: 2, decoration: const InputDecoration(labelText: 'Référence (norme, article, texte)')),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Confirmée pour mon organisation'), value: confirmed, onChanged: (v) => setD(() => confirmed = v)),
              Align(alignment: Alignment.centerLeft, child: IssuesView(issues)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () {
                final found = validateRequirementRule(
                  buildingUsage: usage,
                  roomTypeCode: room,
                  equipmentCode: equip,
                  kind: kind,
                  perAreaM2: parseOptionalNumber(perArea.text),
                  minCount: int.tryParse(minC.text.trim()),
                  maxCount: maxC.text.trim().isEmpty ? null : int.tryParse(maxC.text.trim()),
                  areaMinM2: parseOptionalNumber(aMin.text),
                  areaMaxM2: parseOptionalNumber(aMax.text),
                  reference: ref.text,
                );
                if (hasErrors(found)) {
                  setD(() => issues = found);
                } else {
                  Navigator.pop(c, true);
                }
              },
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await _service.saveRequirementRule(
        widget.organizationId,
        {
          'building_usage': usage,
          'room_type_code': room,
          'equipment_type_code': equip,
          'kind': kind,
          'per_area_m2': parseOptionalNumber(perArea.text),
          'min_count': int.parse(minC.text.trim()),
          'max_count': maxC.text.trim().isEmpty ? null : int.parse(maxC.text.trim()),
          'area_min_m2': parseOptionalNumber(aMin.text),
          'area_max_m2': parseOptionalNumber(aMax.text),
          'reference_text': ref.text.trim(),
          'is_confirmed': confirmed,
        },
        id: (base != null && base.isOrg && !copy) ? base.id : null,
      );
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _deleteNeedRule(RequirementRule r) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer cette règle ? La règle par défaut s\'appliquera de nouveau.');
    if (ok != true || r.id == null) return;
    try {
      await _service.deleteRequirementRule(r.id!);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Widget _needs() {
    final overriddenKeys = _needRules
        .where((r) => r.isOrg)
        .map((r) => '${r.buildingUsage}|${r.roomTypeCode.toUpperCase()}|${r.equipmentCode.toUpperCase()}')
        .toSet();
    final shown = _needRules.where((r) => _usageFilter == null || r.buildingUsage == _usageFilter).toList()
      ..sort((a, b) {
        final c = a.roomTypeCode.compareTo(b.roomTypeCode);
        return c != 0 ? c : a.equipmentCode.compareTo(b.equipmentCode);
      });
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      DropdownButtonFormField<String?>(
        value: _usageFilter,
        decoration: const InputDecoration(labelText: 'Destination'),
        items: [
          const DropdownMenuItem<String?>(value: null, child: Text('Toutes')),
          ...buildingUsageLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
        ],
        onChanged: (v) => setState(() => _usageFilter = v),
      ),
      const SizedBox(height: 4),
      Align(
        alignment: Alignment.centerRight,
        child: FilledButton.tonalIcon(onPressed: () => _editNeedRule(null, copy: false), icon: const Icon(Icons.add), label: const Text('Nouvelle règle')),
      ),
      if (shown.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Aucune règle pour cette destination. Ajoutez-en : sans règle, aucune quantité n\'est proposée.')),
      ...shown.map((r) {
        final replaced = !r.isOrg && overriddenKeys.contains('${r.buildingUsage}|${r.roomTypeCode.toUpperCase()}|${r.equipmentCode.toUpperCase()}');
        return Card(
          child: ListTile(
            enabled: !replaced,
            title: Text('${r.roomTypeCode} → ${r.equipmentCode}${r.isRegulatory ? '' : ' (conception)'}'),
            subtitle: Text('${buildingUsageLabels[r.buildingUsage] ?? r.buildingUsage} • ${_needFormula(r)}\n'
                '${r.isOrg ? 'Mon organisation' : replaced ? 'Par défaut — remplacée par ma règle' : 'Par défaut'} • ${r.isConfirmed ? 'confirmée' : 'à confirmer'}'
                '${(r.reference ?? '').isEmpty ? '' : '\n${r.reference}'}'),
            isThreeLine: true,
            trailing: r.isOrg
                ? Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(tooltip: 'Modifier', icon: const Icon(Icons.edit_outlined), onPressed: () => _editNeedRule(r, copy: false)),
                    IconButton(tooltip: 'Supprimer', icon: const Icon(Icons.delete_outline), onPressed: () => _deleteNeedRule(r)),
                  ])
                : IconButton(tooltip: 'Copier pour mon organisation', icon: const Icon(Icons.copy_outlined), onPressed: replaced ? null : () => _editNeedRule(r, copy: true)),
          ),
        );
      }),
    ]);
  }

  // ---------------------------------------------------------------- Règles de coefficients
  Future<void> _editCoefRule(DiversityRule? base, {required bool copy}) async {
    String? usage = base?.buildingUsage;
    String? category = base?.category;
    bool confirmed = base?.isOrg == true ? base!.isConfirmed : false;
    final ku = TextEditingController(text: _n(base?.ku ?? 1));
    final ksBase = TextEditingController(text: _n(base?.ksBase ?? 1));
    final ksN = TextEditingController(text: _n(base?.ksPerN ?? 0));
    final ref = TextEditingController(text: copy ? '' : (base?.reference ?? ''));
    List<ValidationIssue> issues = [];

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) {
          final k = parseOptionalNumber(ksBase.text) ?? 0;
          final kn = parseOptionalNumber(ksN.text) ?? 0;
          final preview = DiversityRule(category: category ?? '-', ksBase: k.clamp(0.0, 1.0).toDouble(), ksPerN: kn < 0 ? 0 : kn);
          return AlertDialog(
            title: Text(base == null ? 'Nouveaux coefficients' : copy ? 'Copier pour mon organisation' : 'Modifier les coefficients'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                DropdownButtonFormField<String?>(
                  value: usage,
                  decoration: const InputDecoration(labelText: 'Destination'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Toutes destinations')),
                    ...buildingUsageLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
                  ],
                  onChanged: (v) => setD(() => usage = v),
                ),
                DropdownButtonFormField<String?>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Catégorie d\'équipements'),
                  items: _catLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))).toList(),
                  onChanged: (v) => setD(() => category = v),
                ),
                TextField(controller: ku, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Ku — utilisation (0 à 1)'), onChanged: (_) => setD(() {})),
                Row(children: [
                  Expanded(child: TextField(controller: ksBase, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Ks de base'), onChanged: (_) => setD(() {}))),
                  const SizedBox(width: 8),
                  Expanded(child: TextField(controller: ksN, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Terme en 1/n'), onChanged: (_) => setD(() {}))),
                ]),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text('Ks = base + terme / n  →  n=1 : ${preview.ks(1).toStringAsFixed(2)} • n=5 : ${preview.ks(5).toStringAsFixed(2)} • n=10 : ${preview.ks(10).toStringAsFixed(2)}',
                        style: const TextStyle(fontSize: 12)),
                  ),
                ),
                TextField(controller: ref, maxLines: 2, decoration: const InputDecoration(labelText: 'Référence / justification')),
                SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Confirmés pour mon organisation'), value: confirmed, onChanged: (v) => setD(() => confirmed = v)),
                Align(alignment: Alignment.centerLeft, child: IssuesView(issues)),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
              FilledButton(
                onPressed: () {
                  final found = validateDiversityRule(
                    category: category,
                    buildingUsage: usage,
                    ku: parseOptionalNumber(ku.text),
                    ksBase: parseOptionalNumber(ksBase.text),
                    ksPerN: parseOptionalNumber(ksN.text),
                    reference: ref.text,
                  );
                  if (hasErrors(found)) {
                    setD(() => issues = found);
                  } else {
                    Navigator.pop(c, true);
                  }
                },
                child: const Text('Enregistrer'),
              ),
            ],
          );
        },
      ),
    );
    if (ok != true) return;
    try {
      await _service.saveDiversityRule(
        widget.organizationId,
        {
          'building_usage': usage,
          'category': category,
          'ku': parseOptionalNumber(ku.text),
          'ks_base': parseOptionalNumber(ksBase.text),
          'ks_per_n': parseOptionalNumber(ksN.text),
          'reference_text': ref.text.trim(),
          'is_confirmed': confirmed,
        },
        id: (base != null && base.isOrg && !copy) ? base.id : null,
      );
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _deleteCoefRule(DiversityRule r) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer ces coefficients ? Les valeurs par défaut s\'appliqueront de nouveau.');
    if (ok != true || r.id == null) return;
    try {
      await _service.deleteDiversityRule(r.id!);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Widget _coefs() {
    final overridden = _coefRules.where((r) => r.isOrg).map((r) => '${r.buildingUsage ?? 'any'}|${r.category}').toSet();
    final shown = [..._coefRules]..sort((a, b) => a.category.compareTo(b.category));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Align(
        alignment: Alignment.centerRight,
        child: FilledButton.tonalIcon(onPressed: () => _editCoefRule(null, copy: false), icon: const Icon(Icons.add), label: const Text('Nouveaux coefficients')),
      ),
      ...shown.map((r) {
        final replaced = !r.isOrg && overridden.contains('${r.buildingUsage ?? 'any'}|${r.category}');
        return Card(
          child: ListTile(
            enabled: !replaced,
            title: Text('${_catLabels[r.category] ?? r.category} — ${r.buildingUsage == null ? 'toutes destinations' : buildingUsageLabels[r.buildingUsage] ?? r.buildingUsage}'),
            subtitle: Text('Ku ${_n(r.ku)} • Ks = ${_n(r.ksBase)}${r.ksPerN > 0 ? ' + ${_n(r.ksPerN)} / n' : ''}\n'
                '${r.isOrg ? 'Mon organisation' : replaced ? 'Par défaut — remplacés par mes coefficients' : 'Par défaut'} • ${r.isConfirmed ? 'confirmés' : 'à confirmer'}'
                '${(r.reference ?? '').isEmpty ? '' : '\n${r.reference}'}'),
            isThreeLine: true,
            trailing: r.isOrg
                ? Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(tooltip: 'Modifier', icon: const Icon(Icons.edit_outlined), onPressed: () => _editCoefRule(r, copy: false)),
                    IconButton(tooltip: 'Supprimer', icon: const Icon(Icons.delete_outline), onPressed: () => _deleteCoefRule(r)),
                  ])
                : IconButton(tooltip: 'Copier pour mon organisation', icon: const Icon(Icons.copy_outlined), onPressed: replaced ? null : () => _editCoefRule(r, copy: true)),
          ),
        );
      }),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Règles de l\'organisation', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 4),
      const Text('Une règle de votre organisation remplace la règle par défaut de même clé ; les valeurs par défaut ne sont jamais modifiées. La modification exige le droit de gestion des projets.'),
      const SizedBox(height: 8),
      SegmentedButton<int>(
        segments: const [
          ButtonSegment(value: 0, label: Text('Besoins par pièce')),
          ButtonSegment(value: 1, label: Text('Coefficients Ku / Ks')),
        ],
        selected: {_tab},
        onSelectionChanged: (s) => setState(() => _tab = s.first),
      ),
      const SizedBox(height: 8),
      _tab == 0 ? _needs() : _coefs(),
    ]);
  }
}
