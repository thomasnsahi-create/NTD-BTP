import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/requirements_engine.dart';
import '../domain/validation.dart';
import 'issues_view.dart';

/// E19 : besoins électriques par pièce, proposés d'après les règles configurées
/// (destination du bâtiment, type de pièce, surface), modifiables puis validés.
class NeedsSection extends StatefulWidget {
  const NeedsSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<NeedsSection> createState() => _NeedsSectionState();
}

class _NeedsSectionState extends State<NeedsSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _rooms = [];
  List<Map<String, dynamic>> _types = [];
  List<RequirementRule> _rules = [];
  List<Map<String, dynamic>> _needs = [];
  List<Map<String, dynamic>> _placed = [];
  String? _usage;
  final _reference = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _reference.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _rooms = await _service.listRooms(widget.projectId);
      _types = await _service.listEquipmentTypes();
      _rules = effectiveRequirementRules((await _service.listRequirementRules()).map(RequirementRule.fromMap));
      _needs = await _service.listRoomNeeds(widget.projectId);
      _placed = await _service.listProjectEquipmentRefs(widget.projectId);
      final settings = await _service.getProjectSettings(widget.projectId);
      _usage = settings?['building_usage'] as String?;
      _reference.text = (settings?['regulatory_reference'] ?? '').toString();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _reloadNeeds() async {
    try {
      _needs = await _service.listRoomNeeds(widget.projectId);
      _placed = await _service.listProjectEquipmentRefs(widget.projectId);
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
    if (mounted) setState(() {});
  }

  Map<String, dynamic>? _typeByCode(String code) {
    for (final t in _types) {
      if ((t['code'] as String).toUpperCase() == code.toUpperCase()) return t;
    }
    return null;
  }

  Map<String, dynamic>? _typeById(String id) {
    for (final t in _types) {
      if (t['id'] == id) return t;
    }
    return null;
  }

  Map<String, dynamic>? _savedNeed(String roomId, String typeId) {
    for (final n in _needs) {
      if (n['room_id'] == roomId && n['equipment_type_id'] == typeId) return n;
    }
    return null;
  }

  int _placedCount(String roomId, String typeId) =>
      _placed.where((p) => p['room_id'] == roomId && p['equipment_type_id'] == typeId).length;

  double _area(Map<String, dynamic> room) => (room['area_m2'] as num).toDouble();

  String? _roomCode(Map<String, dynamic> room) => (room['elec_room_types'] as Map?)?['code'] as String?;

  NeedsResult _compute(Map<String, dynamic> room) =>
      computeNeeds(usage: _usage, roomTypeCode: _roomCode(room), areaM2: _area(room), rules: _rules);

  Future<void> _saveSettings() async {
    try {
      await _service.saveProjectSettings(
        widget.projectId,
        buildingUsage: _usage,
        regulatoryReference: _reference.text.trim().isEmpty ? null : _reference.text.trim(),
      );
      if (mounted) showSnack(context, 'Destination enregistrée.');
      setState(() {});
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _propose(Map<String, dynamic> room) async {
    final result = _compute(room);
    if (result.lines.isEmpty) {
      if (result.issues.isNotEmpty) showSnack(context, result.issues.first.message);
      return;
    }
    try {
      for (final line in result.lines) {
        final type = _typeByCode(line.equipmentCode);
        if (type == null) continue;
        final saved = _savedNeed(room['id'] as String, type['id'] as String);
        if (saved != null && saved['status'] == 'validated') continue; // une validation n'est jamais écrasée
        await _service.upsertNeed({
          'project_id': widget.projectId,
          'room_id': room['id'],
          'equipment_type_id': type['id'],
          'quantity': saved != null ? saved['quantity'] : line.proposed,
          'proposed_quantity': line.proposed,
          'regulatory_min': line.regulatoryMin,
          'rule_references': line.references.isEmpty ? null : line.references.join(' ; '),
          'status': 'proposed',
        });
      }
      await _reloadNeeds();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _editLine(Map<String, dynamic> room, Map<String, dynamic> type, NeedLine? line, Map<String, dynamic>? saved) async {
    final qty = TextEditingController(text: '${saved?['quantity'] ?? line?.proposed ?? 0}');
    final just = TextEditingController(text: (saved?['justification'] ?? '').toString());
    final regMin = (saved?['regulatory_min'] as num?)?.toInt() ?? line?.regulatoryMin ?? 0;
    List<ValidationIssue> issues = [];
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text('${type['label']} — ${room['name']}'),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Minimum réglementaire calculé : $regMin'),
            TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité retenue')),
            TextField(
              controller: just,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'Justification (obligatoire sous le minimum)'),
            ),
            const SizedBox(height: 8),
            IssuesView(issues),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () {
                final q = int.tryParse(qty.text.trim());
                if (q == null) {
                  setD(() => issues = const [ValidationIssue(IssueSeverity.error, 'Quantité entière requise.')]);
                  return;
                }
                final found = validateNeedQuantity(quantity: q, regulatoryMin: regMin, justification: just.text);
                if (hasErrors(found)) {
                  setD(() => issues = found);
                } else {
                  Navigator.pop(c, true);
                }
              },
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await _service.upsertNeed({
        'project_id': widget.projectId,
        'room_id': room['id'],
        'equipment_type_id': type['id'],
        'quantity': int.parse(qty.text.trim()),
        'proposed_quantity': saved?['proposed_quantity'] ?? line?.proposed,
        'regulatory_min': regMin,
        'rule_references': saved?['rule_references'] ?? (line == null || line.references.isEmpty ? null : line.references.join(' ; ')),
        'justification': just.text.trim().isEmpty ? null : just.text.trim(),
        'status': 'proposed', // toute modification demande une nouvelle validation
      });
      await _reloadNeeds();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _validateRoom(Map<String, dynamic> room) async {
    final mine = _needs.where((n) => n['room_id'] == room['id']).toList();
    if (mine.isEmpty) {
      showSnack(context, 'Aucun besoin à valider : lancez d\'abord la proposition.');
      return;
    }
    final errors = <String>[];
    for (final n in mine) {
      final found = validateNeedQuantity(
        quantity: (n['quantity'] as num).toInt(),
        regulatoryMin: (n['regulatory_min'] as num?)?.toInt() ?? 0,
        justification: n['justification'] as String?,
      );
      final label = _typeById(n['equipment_type_id'] as String)?['label'] ?? '?';
      for (final i in found) {
        errors.add('$label : ${i.message}');
      }
    }
    if (errors.isNotEmpty) {
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Validation impossible'),
          content: Text(errors.join('\n\n')),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Fermer'))],
        ),
      );
      return;
    }
    try {
      for (final n in mine) {
        if (n['status'] == 'validated') continue;
        await _service.upsertNeed({
          'project_id': widget.projectId,
          'room_id': n['room_id'],
          'equipment_type_id': n['equipment_type_id'],
          'quantity': n['quantity'],
          'proposed_quantity': n['proposed_quantity'],
          'regulatory_min': n['regulatory_min'],
          'rule_references': n['rule_references'],
          'justification': n['justification'],
          'status': 'validated',
        });
      }
      await _reloadNeeds();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Widget _roomTile(Map<String, dynamic> room) {
    final result = _compute(room);
    final roomId = room['id'] as String;
    final computed = {for (final l in result.lines) l.equipmentCode.toUpperCase(): l};
    // Union : lignes calculées + besoins déjà enregistrés (même si les règles ont changé).
    final typeIds = <String>{};
    for (final l in result.lines) {
      final t = _typeByCode(l.equipmentCode);
      if (t != null) typeIds.add(t['id'] as String);
    }
    for (final n in _needs.where((n) => n['room_id'] == roomId)) {
      typeIds.add(n['equipment_type_id'] as String);
    }
    final rows = typeIds.map(_typeById).whereType<Map<String, dynamic>>().toList()
      ..sort((a, b) => (a['sort_order'] as int).compareTo(b['sort_order'] as int));
    final validated = _needs.where((n) => n['room_id'] == roomId && n['status'] == 'validated').length;
    final total = _needs.where((n) => n['room_id'] == roomId).length;
    final area = formatQuantity(double.parse(_area(room).toStringAsFixed(2)));
    return Card(
      child: ExpansionTile(
        title: Text('${room['name']}'),
        subtitle: Text('${(room['elec_room_types'] as Map?)?['label'] ?? 'Type non précisé'} • $area m² • '
            '${total == 0 ? 'aucun besoin enregistré' : '$validated/$total validé(s)'}'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final t in rows)
            Builder(builder: (context) {
              final saved = _savedNeed(roomId, t['id'] as String);
              final line = computed[(t['code'] as String).toUpperCase()];
              final qty = saved != null ? (saved['quantity'] as num).toInt() : line?.proposed;
              final regMin = saved != null ? (saved['regulatory_min'] as num?)?.toInt() : line?.regulatoryMin;
              final placed = _placedCount(roomId, t['id'] as String);
              final isValidated = saved?['status'] == 'validated';
              return ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(isValidated ? Icons.check_circle : Icons.pending_outlined, color: isValidated ? Colors.green : null),
                title: Text('${t['label']} — retenu : ${qty ?? '-'}'),
                subtitle: Text('Min. réglementaire ${regMin ?? 0} • proposé ${saved?['proposed_quantity'] ?? line?.proposed ?? '-'} • implanté $placed'
                    '${qty != null && placed < qty ? ' (reste ${remainingToPlace(qty, placed)})' : ''}'
                    '${saved == null ? ' • non enregistré' : ''}'
                    '${(saved?['rule_references'] ?? '').toString().isEmpty ? '' : '\n${saved!['rule_references']}'}'),
                trailing: IconButton(
                  tooltip: 'Modifier',
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => _editLine(room, t, line, saved),
                ),
              );
            }),
          if (rows.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('Aucun besoin pour cette pièce.')),
          IssuesView(result.issues),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            FilledButton.tonalIcon(onPressed: () => _propose(room), icon: const Icon(Icons.auto_fix_high), label: const Text('Proposer')),
            FilledButton.icon(onPressed: () => _validateRoom(room), icon: const Icon(Icons.verified_outlined), label: const Text('Valider la pièce')),
          ]),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Besoins électriques par pièce', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Destination du bâtiment : elle détermine les règles appliquées (aucune règle de logement n\'est appliquée à un autre type de bâtiment).'),
            DropdownButtonFormField<String?>(
              value: _usage,
              decoration: const InputDecoration(labelText: 'Destination'),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Non renseignée')),
                ...buildingUsageLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
              ],
              onChanged: (v) => setState(() => _usage = v),
            ),
            TextField(controller: _reference, decoration: const InputDecoration(labelText: 'Référentiel réglementaire du projet')),
            const SizedBox(height: 8),
            Align(alignment: Alignment.centerRight, child: FilledButton(onPressed: _saveSettings, child: const Text('Enregistrer'))),
          ]),
        ),
      ),
      const Padding(
        padding: EdgeInsets.symmetric(vertical: 4),
        child: Text('Les propositions sont des aides à valider par un professionnel habilité. Les règles par défaut (logements) sont à confirmer pour votre projet.', style: TextStyle(fontSize: 12)),
      ),
      if (_rooms.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('Créez d\'abord des pièces (section « Pièces »).')),
      ..._rooms.map(_roomTile),
    ]);
  }
}
