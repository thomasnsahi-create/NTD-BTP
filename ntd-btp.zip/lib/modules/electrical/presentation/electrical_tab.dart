import 'package:flutter/material.dart';
import 'cables_section.dart';
import 'circuits_section.dart';
import 'currents_section.dart';
import 'domains_section.dart';
import 'installations_section.dart';
import 'needs_section.dart';
import 'plan_section.dart';
import 'power_section.dart';
import 'rules_section.dart';
import 'rooms_section.dart';

/// Bureau d'études électriques : référentiels (E14, E15) et saisie des pièces (E16, E17).
class ElectricalTab extends StatefulWidget {
  const ElectricalTab({super.key, required this.projectId, required this.organizationId});

  final String projectId;
  final String organizationId;

  @override
  State<ElectricalTab> createState() => _ElectricalTabState();
}

class _ElectricalTabState extends State<ElectricalTab> {
  int _section = 0;
  static const List<String> _titles = ['Pièces', 'Besoins', 'Implantation', 'Bilan de puissance', 'Courants', 'Circuits', 'Installations', 'Domaines de tension', 'Câbles', 'Règles'];

  Widget _body() {
    switch (_section) {
      case 1:
        return NeedsSection(key: const ValueKey('needs'), projectId: widget.projectId);
      case 2:
        return PlanSection(key: const ValueKey('plan'), projectId: widget.projectId);
      case 3:
        return PowerSection(key: const ValueKey('power'), projectId: widget.projectId);
      case 4:
        return CurrentsSection(key: const ValueKey('currents'), projectId: widget.projectId);
      case 5:
        return CircuitsSection(key: const ValueKey('circuits'), projectId: widget.projectId);
      case 6:
        return InstallationsSection(key: const ValueKey('installations'), projectId: widget.projectId);
      case 7:
        return DomainsSection(key: const ValueKey('domains'), organizationId: widget.organizationId);
      case 8:
        return const CablesSection(key: ValueKey('cables'));
      case 9:
        return RulesSection(key: const ValueKey('rules'), organizationId: widget.organizationId);
      default:
        return RoomsSection(key: const ValueKey('rooms'), projectId: widget.projectId);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: Row(
          children: List<Widget>.generate(_titles.length, (i) {
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(_titles[i]),
                selected: _section == i,
                onSelected: (_) => setState(() => _section = i),
              ),
            );
          }),
        ),
      ),
      Expanded(child: _body()),
    ]);
  }
}
