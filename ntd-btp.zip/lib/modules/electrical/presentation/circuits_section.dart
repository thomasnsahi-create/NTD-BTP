import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/cable_library.dart';
import '../domain/circuit_calc.dart';
import '../domain/current_calc.dart';
import '../domain/power_balance.dart';
import '../domain/validation.dart';
import 'issues_view.dart';

String _amps(double a) => '${a.toStringAsFixed(2).replaceAll('.', ',')} A';

/// Circuits : regroupement des équipements et données nécessaires au dimensionnement des câbles (E22).
class CircuitsSection extends StatefulWidget {
  const CircuitsSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<CircuitsSection> createState() => _CircuitsSectionState();
}

class _CircuitsSectionState extends State<CircuitsSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _circuits = [];
  List<Map<String, dynamic>> _equipment = [];
  List<InstallationSupply> _installations = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _circuits = await _service.listCircuits(widget.projectId);
      _equipment = await _service.listCurrentItems(widget.projectId);
      _installations = (await _service.listInstallations(widget.projectId)).map(InstallationSupply.fromMap).toList();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  double? _d(dynamic v) => (v as num?)?.toDouble();
  String _label(Map<String, dynamic> r) => (r['label'] ?? (r['elec_equipment_types'] as Map?)?['label'] ?? '?').toString();

  InstallationSupply? _inst(String? id) {
    for (final i in _installations) {
      if (i.id == id) return i;
    }
    return null;
  }

  List<Map<String, dynamic>> _members(String circuitId) => _equipment.where((e) => e['circuit_id'] == circuitId).toList();

  CircuitCurrent _current(Map<String, dynamic> c) => computeCircuitCurrent(
        installation: _inst(c['installation_id'] as String?),
        connection: c['connection'] as String?,
        demandCoefficient: _d(c['demand_coefficient']) ?? 1,
        loads: _members(c['id'] as String)
            .map((e) => CircuitLoad(
                  id: e['id'] as String,
                  label: _label(e),
                  powerW: absorbedPower(_d(e['power_w']), _d(e['efficiency'])),
                  powerFactor: _d(e['power_factor']),
                ))
            .toList(),
      );

  Future<void> _edit([Map<String, dynamic>? c]) async {
    final number = TextEditingController(text: (c?['number'] ?? 'C${_circuits.length + 1}').toString());
    final name = TextEditingController(text: (c?['name'] ?? '').toString());
    final origin = TextEditingController(text: (c?['origin_label'] ?? '').toString());
    final ambient = TextEditingController(text: c?['ambient_temp_c'] == null ? '' : formatQuantity(c!['ambient_temp_c'] as num));
    final grouped = TextEditingController(text: c?['grouped_circuits'] == null ? '' : '${c!['grouped_circuits']}');
    final length = TextEditingController(text: c?['length_m'] == null ? '' : formatQuantity(c!['length_m'] as num));
    final coef = TextEditingController(text: c?['demand_coefficient'] == null ? '1' : formatQuantity(c!['demand_coefficient'] as num));
    final drop = TextEditingController(text: c?['max_voltage_drop_pct'] == null ? '' : formatQuantity(c!['max_voltage_drop_pct'] as num));
    final icc = TextEditingController(text: c?['icc_ka'] == null ? '' : formatQuantity(c!['icc_ka'] as num));
    final protection = TextEditingController(text: (c?['protection_type'] ?? '').toString());
    String type = (c?['circuit_type'] ?? 'other') as String;
    String? installationId = c?['installation_id'] as String?;
    String? connection = c?['connection'] as String?;
    String? material = c?['conductor_material'] as String?;
    String? laying = c?['laying_mode'] as String?;
    final envs = <String>{...List<String>.from((c?['environments'] ?? const []) as List)};
    List<ValidationIssue> issues = [];

    int? intOrNull(String t) => t.trim().isEmpty ? null : int.tryParse(t.trim());

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text(c == null ? 'Nouveau circuit' : 'Modifier le circuit'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: TextField(controller: number, decoration: const InputDecoration(labelText: 'Numéro'))),
                const SizedBox(width: 8),
                Expanded(flex: 2, child: TextField(controller: name, decoration: const InputDecoration(labelText: 'Désignation'))),
              ]),
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: 'Nature du circuit'),
                items: circuitTypeLabels.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
                onChanged: (v) => setD(() => type = v ?? type),
              ),
              TextField(controller: origin, decoration: const InputDecoration(labelText: 'Départ (tableau)')),
              DropdownButtonFormField<String?>(
                value: installationId,
                decoration: const InputDecoration(labelText: 'Installation d\'alimentation'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Non précisée')),
                  ..._installations.map((i) => DropdownMenuItem<String?>(value: i.id, child: Text(i.name))),
                ],
                onChanged: (v) => setD(() => installationId = v),
              ),
              DropdownButtonFormField<String?>(
                value: connection,
                decoration: const InputDecoration(labelText: 'Raccordement du circuit'),
                items: const [
                  DropdownMenuItem<String?>(value: null, child: Text('Non précisé')),
                  DropdownMenuItem<String?>(value: 'single', child: Text('Monophasé')),
                  DropdownMenuItem<String?>(value: 'three', child: Text('Triphasé')),
                ],
                onChanged: (v) => setD(() => connection = v),
              ),
              DropdownButtonFormField<String?>(
                value: material,
                decoration: const InputDecoration(labelText: 'Matériau du conducteur'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Non précisé')),
                  ...conductorLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
                ],
                onChanged: (v) => setD(() => material = v),
              ),
              DropdownButtonFormField<String?>(
                value: laying,
                decoration: const InputDecoration(labelText: 'Mode de pose'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Non précisé')),
                  ...layingLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
                ],
                onChanged: (v) => setD(() => laying = v),
              ),
              const SizedBox(height: 8),
              const Text('Environnement'),
              Wrap(spacing: 6, children: [
                for (final e in environmentLabels.entries)
                  FilterChip(
                    label: Text(e.value),
                    selected: envs.contains(e.key),
                    onSelected: (v) => setD(() => v ? envs.add(e.key) : envs.remove(e.key)),
                  ),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: ambient, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Température (°C)'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: grouped, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Circuits regroupés'))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: length, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Longueur (m)'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: coef, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Coef. simultanéité'))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: drop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Chute admissible (%)'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: icc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Icc (kA)'))),
              ]),
              TextField(controller: protection, decoration: const InputDecoration(labelText: 'Type de protection')),
              const SizedBox(height: 8),
              IssuesView(issues),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () {
                final found = validateCircuit(
                  number: number.text,
                  demandCoefficient: parseOptionalNumber(coef.text),
                  lengthM: parseOptionalNumber(length.text),
                  ambientTempC: parseOptionalNumber(ambient.text),
                  groupedCircuits: intOrNull(grouped.text),
                  maxDropPct: parseOptionalNumber(drop.text),
                  iccKa: parseOptionalNumber(icc.text),
                );
                if (hasErrors(found)) {
                  setD(() => issues = found);
                } else {
                  Navigator.pop(ctx, true);
                }
              },
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    String? orNull(TextEditingController t) => t.text.trim().isEmpty ? null : t.text.trim();
    try {
      await _service.saveCircuit(
        widget.projectId,
        {
          'number': number.text.trim(),
          'name': orNull(name),
          'circuit_type': type,
          'origin_label': orNull(origin),
          'installation_id': installationId,
          'connection': connection,
          'conductor_material': material,
          'laying_mode': laying,
          'environments': envs.toList(),
          'ambient_temp_c': parseOptionalNumber(ambient.text),
          'grouped_circuits': intOrNull(grouped.text),
          'length_m': parseOptionalNumber(length.text),
          'demand_coefficient': parseOptionalNumber(coef.text) ?? 1,
          'max_voltage_drop_pct': parseOptionalNumber(drop.text),
          'icc_ka': parseOptionalNumber(icc.text),
          'protection_type': orNull(protection),
        },
        id: c?['id'] as String?,
      );
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _assign(Map<String, dynamic> c) async {
    final cid = c['id'] as String;
    final selected = <String>{for (final e in _members(cid)) e['id'] as String};
    final initial = {...selected};
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text('Équipements du circuit ${c['number']}'),
          content: SizedBox(
            width: double.maxFinite,
            child: _equipment.isEmpty
                ? const Text('Aucun équipement : implantez-en dans la section « Implantation ».')
                : ListView(shrinkWrap: true, children: [
                    for (final e in _equipment)
                      CheckboxListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        value: selected.contains(e['id']),
                        title: Text('${_label(e)} — ${((e['elec_rooms'] as Map?)?['name'] ?? '?')}'),
                        subtitle: Text(e['circuit_id'] != null && e['circuit_id'] != cid
                            ? 'Déjà dans le circuit ${_circuits.firstWhere((x) => x['id'] == e['circuit_id'], orElse: () => {'number': '?'})['number']} (sera déplacé)'
                            : _d(e['power_w']) == null ? 'puissance à renseigner' : '${formatQuantity(_d(e['power_w'])!)} W'),
                        onChanged: (v) => setD(() => v == true ? selected.add(e['id'] as String) : selected.remove(e['id'])),
                      ),
                  ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await _service.assignCircuitEquipment(
        cid,
        add: selected.difference(initial).toList(),
        remove: initial.difference(selected).toList(),
      );
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _delete(Map<String, dynamic> c) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer le circuit ${c['number']} ? Ses équipements sont conservés, simplement détachés.');
    if (ok != true) return;
    try {
      await _service.deleteCircuit(c['id'] as String);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final withoutCircuit = _equipment.where((e) => e['circuit_id'] == null).length;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(child: Text('Circuits (${_circuits.length})', style: Theme.of(context).textTheme.titleMedium)),
        FilledButton.tonalIcon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Ajouter')),
      ]),
      const SizedBox(height: 4),
      Text('Courant d\'emploi Ib = k × S / U (monophasé) ou k × S / (√3 U) (triphasé). '
          '${withoutCircuit > 0 ? '$withoutCircuit équipement(s) sans circuit.' : ''}'),
      if (_circuits.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('Aucun circuit. Créez-en un, puis rattachez-y des équipements.')),
      ..._circuits.map((c) {
        final cur = _current(c);
        final missing = sizingMissingData(
          current: cur,
          conductorMaterial: c['conductor_material'] as String?,
          layingMode: c['laying_mode'] as String?,
          ambientTempC: _d(c['ambient_temp_c']),
          groupedCircuits: (c['grouped_circuits'] as num?)?.toInt(),
          lengthM: _d(c['length_m']),
          maxDropPct: _d(c['max_voltage_drop_pct']),
          iccKa: _d(c['icc_ka']),
          protectionType: c['protection_type'] as String?,
        );
        final inst = _inst(c['installation_id'] as String?);
        final n = _members(c['id'] as String).length;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('${c['number']} — ${(c['name'] ?? circuitTypeLabels[c['circuit_type']] ?? '').toString()}', style: Theme.of(context).textTheme.titleSmall)),
                IconButton(tooltip: 'Équipements', icon: const Icon(Icons.playlist_add_check), onPressed: () => _assign(c)),
                IconButton(tooltip: 'Modifier', icon: const Icon(Icons.edit_outlined), onPressed: () => _edit(c)),
                IconButton(tooltip: 'Supprimer', icon: const Icon(Icons.delete_outline), onPressed: () => _delete(c)),
              ]),
              Text('${circuitTypeLabels[c['circuit_type']] ?? ''} • ${inst?.name ?? 'installation non précisée'} • $n équipement(s)'
                  '${c['origin_label'] != null ? ' • départ ${c['origin_label']}' : ''}'),
              const SizedBox(height: 4),
              if (cur.ibA != null)
                Text('Ib = ${_amps(cur.ibA!)} (${cur.supply!.label})', style: const TextStyle(fontWeight: FontWeight.w700))
              else
                Text('Ib non calculé — à compléter : ${cur.missing.join(', ')}'),
              for (final a in cur.assumptions) Text('• $a', style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 4),
              Row(children: [
                Icon(missing.isEmpty ? Icons.check_circle : Icons.pending_outlined, size: 16, color: missing.isEmpty ? Colors.green : null),
                const SizedBox(width: 6),
                Expanded(child: Text(missing.isEmpty ? 'Prêt pour le dimensionnement' : 'Avant dimensionnement : ${missing.join(', ')}', style: const TextStyle(fontSize: 12))),
              ]),
            ]),
          ),
        );
      }),
    ]);
  }
}
