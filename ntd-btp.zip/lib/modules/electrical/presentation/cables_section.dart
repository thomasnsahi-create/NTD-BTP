import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/cable_library.dart';
import '../domain/validation.dart';
import 'issues_view.dart';

/// E15 : bibliothèque technique des câbles et recherche d'un câble adapté à un usage.
class CablesSection extends StatefulWidget {
  const CablesSection({super.key});

  @override
  State<CablesSection> createState() => _CablesSectionState();
}

class _CablesSectionState extends State<CablesSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<CableType> _cables = [];
  String? _category;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await _service.listCableTypes();
      _cables = rows.map(CableType.fromMap).toList();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  String _list(List<String> keys, Map<String, String> labels) =>
      keys.isEmpty ? 'non précisé' : keys.map((k) => labels[k] ?? k).join(', ');

  Future<void> _finder() async {
    final voltage = TextEditingController(text: '230');
    String? conductor;
    String? laying;
    String? env;
    bool dc = false;
    bool fire = false;
    bool halogen = false;
    await showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) {
          final usage = CableUsage(
            voltageV: parseNumber(voltage.text),
            dc: dc,
            conductor: conductor,
            laying: laying,
            environments: env == null ? const [] : [env!],
            requiresFireResistance: fire,
            requiresHalogenFree: halogen,
          );
          final found = suitableCables(_cables, usage);
          return AlertDialog(
            title: const Text('Câble adapté à l\'usage'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                TextField(
                  controller: voltage,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Tension du circuit (V)'),
                  onChanged: (_) => setD(() {}),
                ),
                SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Courant continu'), value: dc, onChanged: (v) => setD(() => dc = v)),
                DropdownButtonFormField<String?>(
                  value: conductor,
                  decoration: const InputDecoration(labelText: 'Conducteur'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Indifférent')),
                    ...conductorLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
                  ],
                  onChanged: (v) => setD(() => conductor = v),
                ),
                DropdownButtonFormField<String?>(
                  value: laying,
                  decoration: const InputDecoration(labelText: 'Mode de pose'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Indifférent')),
                    ...layingLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
                  ],
                  onChanged: (v) => setD(() => laying = v),
                ),
                DropdownButtonFormField<String?>(
                  value: env,
                  decoration: const InputDecoration(labelText: 'Environnement'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Indifférent')),
                    ...environmentLabels.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
                  ],
                  onChanged: (v) => setD(() => env = v),
                ),
                CheckboxListTile(contentPadding: EdgeInsets.zero, title: const Text('Résistant au feu exigé'), value: fire, onChanged: (v) => setD(() => fire = v ?? false)),
                CheckboxListTile(contentPadding: EdgeInsets.zero, title: const Text('Sans halogène exigé'), value: halogen, onChanged: (v) => setD(() => halogen = v ?? false)),
                const Divider(),
                Text('${found.length} référence(s) adaptée(s)', style: Theme.of(c).textTheme.titleSmall),
                for (final f in found) Text('• ${f.code} — ${f.label}'),
                if (found.isEmpty) const Text('Aucune référence de la bibliothèque ne convient : ajustez les critères.'),
              ]),
            ),
            actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Fermer'))],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final shown = _category == null ? _cables : _cables.where((c) => c.category == _category).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(child: Text('Bibliothèque de câbles (${shown.length})', style: Theme.of(context).textTheme.titleMedium)),
        FilledButton.tonalIcon(onPressed: _finder, icon: const Icon(Icons.search), label: const Text('Trouver')),
      ]),
      const SizedBox(height: 8),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(label: const Text('Tous'), selected: _category == null, onSelected: (_) => setState(() => _category = null)),
          ),
          for (final e in categoryLabels.entries)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: FilterChip(label: Text(e.value), selected: _category == e.key, onSelected: (_) => setState(() => _category = e.key)),
            ),
        ]),
      ),
      ...shown.map((c) {
        final issues = c.dataConfirmed
            ? const <ValidationIssue>[]
            : const [ValidationIssue(IssueSeverity.warning, 'Caractéristiques typiques à confirmer avec la fiche du fabricant.')];
        return Card(
          child: ExpansionTile(
            title: Text(c.code),
            subtitle: Text('${c.label}\n${categoryLabels[c.category] ?? c.category} • ${c.conductorMaterials.map((m) => conductorLabels[m]).join('/')} • ${c.insulation} • ${formatQuantity(c.ratedUV)} V'),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Courant : ${c.currentType == 'ac' ? 'alternatif' : c.currentType == 'dc' ? 'continu' : 'alternatif et continu'}'),
              Text('Poses : ${_list(c.allowedLaying, layingLabels)}'),
              Text('Environnements : ${_list(c.allowedEnvironments, environmentLabels)}'),
              Text('Sections (mm²) : ${c.availableSections.map(formatQuantity).join(' ; ')}'),
              Text('Nombre de conducteurs : ${c.availableCores.join(', ')}'),
              if (c.isFireResistant) const Text('Résistant au feu'),
              if (c.isHalogenFree) const Text('Sans halogène'),
              IssuesView(issues),
            ],
          ),
        );
      }),
    ]);
  }
}
