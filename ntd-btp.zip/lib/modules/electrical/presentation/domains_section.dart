import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/voltage_domain.dart';

/// E14 : référentiel configurable des domaines de tension.
/// Modifier un domaine crée une copie propre à l'organisation ; le défaut reste intact.
class DomainsSection extends StatefulWidget {
  const DomainsSection({super.key, required this.organizationId});

  final String organizationId;

  @override
  State<DomainsSection> createState() => _DomainsSectionState();
}

class _DomainsSectionState extends State<DomainsSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _domains = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _domains = await _service.listVoltageDomains();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  String _txt(dynamic v) => v == null ? '' : formatQuantity(v as num);

  Future<void> _edit(Map<String, dynamic> d) async {
    final minAc = TextEditingController(text: _txt(d['min_ac_v']));
    final maxAc = TextEditingController(text: _txt(d['max_ac_v']));
    final minDc = TextEditingController(text: _txt(d['min_dc_v']));
    final maxDc = TextEditingController(text: _txt(d['max_dc_v']));
    final ref = TextEditingController(text: (d['reference_standard'] ?? '').toString());
    bool confirmed = d['is_confirmed'] == true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text('${d['code']} — limites'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('Selon la réglementation nationale, le distributeur et le contrat. Laissez vide si non défini.'),
              Row(children: [
                Expanded(child: TextField(controller: minAc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'c.a. min (V)'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: maxAc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'c.a. max (V)'))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: minDc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'c.c. min (V)'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: maxDc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'c.c. max (V)'))),
              ]),
              TextField(controller: ref, decoration: const InputDecoration(labelText: 'Référentiel / source')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Limites confirmées pour mon organisation'),
                value: confirmed,
                onChanged: (v) => setD(() => confirmed = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Enregistrer')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await _service.saveVoltageDomain(widget.organizationId, {
        ...d,
        'min_ac_v': parseOptionalNumber(minAc.text),
        'max_ac_v': parseOptionalNumber(maxAc.text),
        'min_dc_v': parseOptionalNumber(minDc.text),
        'max_dc_v': parseOptionalNumber(maxDc.text),
        'reference_standard': ref.text.trim().isEmpty ? null : ref.text.trim(),
        'is_confirmed': confirmed,
      });
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Domaines de tension', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 4),
      const Text('Appellations, limites et équivalences configurables. MTA et MTB ne sont pas des subdivisions définies par la NF C 15-100 : leurs limites sont à fixer selon le référentiel du projet.'),
      const SizedBox(height: 8),
      ..._domains.map((raw) {
        final d = VoltageDomain.fromMap(raw);
        final own = raw['organization_id'] != null;
        return Card(
          child: ListTile(
            title: Text('${d.code} — ${d.label}'),
            subtitle: Text('c.a. ${d.limitsLabel()}\nc.c. ${d.limitsLabel(dc: true)}\n'
                '${d.isConfirmed ? 'Confirmé' : 'À confirmer'} • ${own ? 'Personnalisé' : 'Valeur par défaut'}'),
            isThreeLine: true,
            trailing: const Icon(Icons.edit_outlined),
            onTap: () => _edit(raw),
          ),
        );
      }),
    ]);
  }
}
