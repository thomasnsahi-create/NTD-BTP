import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/room_geometry.dart';
import '../domain/validation.dart';
import 'issues_view.dart';

/// E16/E17 : saisie des pièces ; surface, périmètre et volume calculés automatiquement.
class RoomsSection extends StatefulWidget {
  const RoomsSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<RoomsSection> createState() => _RoomsSectionState();
}

class _RoomsSectionState extends State<RoomsSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _rooms = [];
  List<Map<String, dynamic>> _types = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _rooms = await _service.listRooms(widget.projectId);
      _types = await _service.listRoomTypes();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  double _d(dynamic v) => (v as num).toDouble();
  String _t(dynamic v) => v == null ? '' : formatQuantity(v as num);

  RoomGeometry _geo(Map<String, dynamic> r) =>
      RoomGeometry(lengthM: _d(r['length_m']), widthM: _d(r['width_m']), heightM: _d(r['height_m']));

  Future<void> _edit([Map<String, dynamic>? room]) async {
    final name = TextEditingController(text: (room?['name'] ?? '').toString());
    final building = TextEditingController(text: (room?['building'] ?? '').toString());
    final floor = TextEditingController(text: (room?['floor_label'] ?? '').toString());
    final length = TextEditingController(text: _t(room?['length_m']));
    final width = TextEditingController(text: _t(room?['width_m']));
    final height = TextEditingController(text: _t(room?['height_m'] ?? 2.5));
    final ceiling = TextEditingController(text: _t(room?['ceiling_height_m']));
    final socket = TextEditingController(text: _t(room?['socket_height_m']));
    final sw = TextEditingController(text: _t(room?['switch_height_m']));
    final lum = TextEditingController(text: _t(room?['luminaire_height_m']));
    final px = TextEditingController(text: _t(room?['panel_x_m']));
    final py = TextEditingController(text: _t(room?['panel_y_m']));
    String? typeId = room?['room_type_id'] as String?;
    List<ValidationIssue> issues = [];

    RoomInput input() => RoomInput(
          name: name.text,
          lengthM: parseOptionalNumber(length.text),
          widthM: parseOptionalNumber(width.text),
          heightM: parseOptionalNumber(height.text),
          ceilingHeightM: parseOptionalNumber(ceiling.text),
          socketHeightM: parseOptionalNumber(socket.text),
          switchHeightM: parseOptionalNumber(sw.text),
          luminaireHeightM: parseOptionalNumber(lum.text),
          panelXM: parseOptionalNumber(px.text),
          panelYM: parseOptionalNumber(py.text),
        );

    void applyDefaults(String? id) {
      final t = _types.where((x) => x['id'] == id).toList();
      if (t.isEmpty) return;
      if (name.text.trim().isEmpty) name.text = t.first['label'] as String;
      ceiling.text = _t(t.first['default_ceiling_height_m']);
      socket.text = _t(t.first['default_socket_height_m']);
      sw.text = _t(t.first['default_switch_height_m']);
      lum.text = _t(t.first['default_luminaire_height_m']);
    }

    Widget field(String label, TextEditingController c, StateSetter setD, {bool number = true}) => TextField(
          controller: c,
          keyboardType: number ? TextInputType.number : TextInputType.text,
          decoration: InputDecoration(labelText: label),
          onChanged: (_) => setD(() {}),
        );

    final saved = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) {
          final l = parseOptionalNumber(length.text);
          final w = parseOptionalNumber(width.text);
          final h = parseOptionalNumber(height.text);
          final geo = (l != null && w != null && h != null && l > 0 && w > 0 && h > 0)
              ? RoomGeometry(lengthM: l, widthM: w, heightM: h)
              : null;
          return AlertDialog(
            title: Text(room == null ? 'Nouvelle pièce' : 'Modifier la pièce'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                DropdownButtonFormField<String?>(
                  value: typeId,
                  decoration: const InputDecoration(labelText: 'Type de pièce'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Non précisé')),
                    ..._types.map((t) => DropdownMenuItem<String?>(value: t['id'] as String, child: Text(t['label'] as String))),
                  ],
                  onChanged: (v) => setD(() {
                    typeId = v;
                    if (room == null) applyDefaults(v);
                  }),
                ),
                field('Nom de la pièce', name, setD, number: false),
                field('Bâtiment', building, setD, number: false),
                field('Étage / niveau', floor, setD, number: false),
                Row(children: [
                  Expanded(child: field('Longueur (m)', length, setD)),
                  const SizedBox(width: 8),
                  Expanded(child: field('Largeur (m)', width, setD)),
                  const SizedBox(width: 8),
                  Expanded(child: field('Hauteur (m)', height, setD)),
                ]),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    geo == null
                        ? 'Surface, périmètre et volume : renseignez les trois dimensions.'
                        : 'Surface ${formatQuantity(double.parse(geo.areaM2.toStringAsFixed(3)))} m² • Périmètre ${formatQuantity(double.parse(geo.perimeterM.toStringAsFixed(3)))} m • Volume ${formatQuantity(double.parse(geo.volumeM3.toStringAsFixed(3)))} m³',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                field('Hauteur du plafond (m)', ceiling, setD),
                Row(children: [
                  Expanded(child: field('Prises (m)', socket, setD)),
                  const SizedBox(width: 8),
                  Expanded(child: field('Interrupt. (m)', sw, setD)),
                  const SizedBox(width: 8),
                  Expanded(child: field('Luminaires (m)', lum, setD)),
                ]),
                Row(children: [
                  Expanded(child: field('Tableau X (m)', px, setD)),
                  const SizedBox(width: 8),
                  Expanded(child: field('Tableau Y (m)', py, setD)),
                ]),
                const SizedBox(height: 8),
                Align(alignment: Alignment.centerLeft, child: IssuesView(issues)),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
              FilledButton(
                onPressed: () {
                  final found = validateRoom(input());
                  if (hasErrors(found)) {
                    setD(() => issues = found);
                  } else {
                    Navigator.pop(c, true);
                  }
                },
                child: const Text('Enregistrer'),
              ),
            ],
          );
        },
      ),
    );
    if (saved != true) return;
    String? orNull(TextEditingController c) => c.text.trim().isEmpty ? null : c.text.trim();
    try {
      await _service.saveRoom(
        widget.projectId,
        {
          'room_type_id': typeId,
          'name': name.text.trim(),
          'building': orNull(building),
          'floor_label': orNull(floor),
          'length_m': parseNumber(length.text),
          'width_m': parseNumber(width.text),
          'height_m': parseNumber(height.text),
          'ceiling_height_m': parseOptionalNumber(ceiling.text),
          'socket_height_m': parseOptionalNumber(socket.text),
          'switch_height_m': parseOptionalNumber(sw.text),
          'luminaire_height_m': parseOptionalNumber(lum.text),
          'panel_x_m': parseOptionalNumber(px.text),
          'panel_y_m': parseOptionalNumber(py.text),
        },
        id: room?['id'] as String?,
      );
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _openings(Map<String, dynamic> room) async {
    final geo = _geo(room);
    await showDialog<void>(
      context: context,
      builder: (c) {
        List<Map<String, dynamic>>? items;
        String? error;
        bool started = false;
        String kind = 'door';
        String wall = 'north';
        final offset = TextEditingController(text: '0');
        final width = TextEditingController(text: '0,9');
        return StatefulBuilder(
          builder: (c, setD) {
            Future<void> reload() async {
              try {
                items = await _service.listOpenings(room['id'] as String);
                error = null;
              } catch (e) {
                error = cleanError(e);
              }
              if (c.mounted) setD(() {});
            }

            if (!started) {
              started = true;
              reload();
            }
            return AlertDialog(
              title: Text('Portes et fenêtres — ${room['name']}'),
              content: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (items == null && error == null) const Center(child: CircularProgressIndicator()),
                  if (error != null) Text(error!),
                  for (final o in items ?? const <Map<String, dynamic>>[])
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(o['kind'] == 'door' ? Icons.door_front_door_outlined : Icons.window_outlined),
                      title: Text('${o['kind'] == 'door' ? 'Porte' : 'Fenêtre'} — mur ${wallLabels[o['wall']]}'),
                      subtitle: Text('à ${_t(o['offset_m'])} m, largeur ${_t(o['width_m'])} m'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await _service.deleteOpening(o['id'] as String);
                          await reload();
                        },
                      ),
                    ),
                  const Divider(),
                  DropdownButtonFormField<String>(
                    value: kind,
                    decoration: const InputDecoration(labelText: 'Type'),
                    items: const [
                      DropdownMenuItem(value: 'door', child: Text('Porte')),
                      DropdownMenuItem(value: 'window', child: Text('Fenêtre')),
                    ],
                    onChanged: (v) => setD(() => kind = v ?? kind),
                  ),
                  DropdownButtonFormField<String>(
                    value: wall,
                    decoration: const InputDecoration(labelText: 'Mur'),
                    items: wallNames
                        .map((w) => DropdownMenuItem(value: w, child: Text('${wallLabels[w]} (${formatQuantity(geo.wallLengthM(w))} m)')))
                        .toList(),
                    onChanged: (v) => setD(() => wall = v ?? wall),
                  ),
                  Row(children: [
                    Expanded(child: TextField(controller: offset, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Décalage (m)'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: width, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Largeur (m)'))),
                  ]),
                ]),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(c), child: const Text('Fermer')),
                FilledButton(
                  onPressed: () async {
                    final o = parseNumber(offset.text);
                    final w = parseNumber(width.text);
                    final issues = validateOpening(geo, wall: wall, offsetM: o, widthM: w);
                    if (hasErrors(issues)) {
                      showSnack(context, issues.first.message);
                      return;
                    }
                    try {
                      await _service.addOpening({'room_id': room['id'], 'kind': kind, 'wall': wall, 'offset_m': o, 'width_m': w});
                      await reload();
                    } catch (e) {
                      if (context.mounted) showSnack(context, cleanError(e));
                    }
                  },
                  child: const Text('Ajouter'),
                ),
              ],
            );
          },
        );
      },
    );
    await _load();
  }

  Future<void> _delete(Map<String, dynamic> room) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer la pièce « ${room['name']} » ?');
    if (ok != true) return;
    try {
      await _service.deleteRoom(room['id'] as String);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final totals = totalsOf(_rooms.map(_geo));
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(child: Text('Pièces (${_rooms.length})', style: Theme.of(context).textTheme.titleMedium)),
        FilledButton.tonalIcon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Ajouter')),
      ]),
      if (_rooms.isNotEmpty)
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Text('Total : ${formatQuantity(double.parse(totals.areaM2.toStringAsFixed(2)))} m² • ${formatQuantity(double.parse(totals.volumeM3.toStringAsFixed(2)))} m³'),
          ),
        ),
      if (_rooms.isEmpty)
        const Padding(padding: EdgeInsets.all(24), child: Text('Aucune pièce. Saisissez les dimensions : la surface, le périmètre et le volume sont calculés automatiquement.')),
      ..._rooms.map((r) {
        final place = [r['building'], r['floor_label']].where((e) => e != null && e.toString().isNotEmpty).join(' • ');
        return Card(
          child: ListTile(
            title: Text('${r['name']}'),
            subtitle: Text('${(r['elec_room_types'] as Map?)?['label'] ?? 'Type non précisé'}${place.isEmpty ? '' : ' • $place'}\n'
                '${_t(r['length_m'])} × ${_t(r['width_m'])} × ${_t(r['height_m'])} m • ${formatQuantity(double.parse(_d(r['area_m2']).toStringAsFixed(3)))} m² • '
                'Périm. ${formatQuantity(double.parse(_d(r['perimeter_m']).toStringAsFixed(3)))} m • ${formatQuantity(double.parse(_d(r['volume_m3']).toStringAsFixed(3)))} m³\n'
                '${r['doors_count']} porte(s) • ${r['windows_count']} fenêtre(s)'),
            isThreeLine: true,
            onTap: () => _edit(r),
            trailing: PopupMenuButton<String>(
              onSelected: (v) => v == 'openings' ? _openings(r) : _delete(r),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'openings', child: Text('Portes et fenêtres')),
                PopupMenuItem(value: 'delete', child: Text('Supprimer')),
              ],
            ),
          ),
        );
      }),
    ]);
  }
}
