import 'package:flutter/material.dart';
import '../../../core/utils/format.dart';
import '../../projects/presentation/execution/common.dart';
import '../data/electrical_service.dart';
import '../domain/power_balance.dart';
import '../domain/requirements_engine.dart';
import '../domain/validation.dart';
import 'issues_view.dart';

const Map<String, String> _categoryLabels = {
  'lighting': 'Éclairage',
  'switch': 'Commande',
  'socket': 'Prises de courant',
  'junction_box': 'Boîtes de dérivation',
  'panel': 'Tableaux',
  'hvac': 'Climatisation',
  'specialized': 'Équipements spécialisés',
  'detector': 'Détecteurs',
  'security': 'Sécurité',
  'communication': 'Communication',
};

String _kw(double w) => '${(w / 1000).toStringAsFixed(2).replaceAll('.', ',')} kW';
String _kva(double va) => '${(va / 1000).toStringAsFixed(2).replaceAll('.', ',')} kVA';
String _coef(double v) => v.toStringAsFixed(3).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'[.,]$'), '').replaceAll('.', ',');

/// E20 : bilan de puissance par catégorie, avec coefficients Ku et Ks configurables.
class PowerSection extends StatefulWidget {
  const PowerSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<PowerSection> createState() => _PowerSectionState();
}

class _PowerSectionState extends State<PowerSection> {
  final _service = ElectricalService.instance;
  bool _loading = true;
  String? _error;
  List<PowerItem> _items = [];
  List<DiversityRule> _rules = [];
  List<Map<String, dynamic>> _saved = [];
  String? _usage;
  final _overall = TextEditingController(text: '1');
  final _reserve = TextEditingController(text: '1');

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _overall.dispose();
    _reserve.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await _service.listPowerItems(widget.projectId);
      _items = rows.map((r) {
        final t = r['elec_equipment_types'] as Map?;
        return PowerItem(
          id: r['id'] as String,
          label: (r['label'] ?? t?['label'] ?? '?').toString(),
          roomId: r['room_id'] as String,
          roomName: ((r['elec_rooms'] as Map?)?['name'] ?? '?').toString(),
          category: (t?['category'] ?? 'specialized').toString(),
          // Puissance absorbée : la puissance utile saisie est divisée par le rendement s'il est renseigné.
          powerW: absorbedPower((r['power_w'] as num?)?.toDouble(), (r['efficiency'] as num?)?.toDouble()),
          powerFactor: (r['power_factor'] as num?)?.toDouble(),
        );
      }).toList();
      _rules = effectiveDiversityRules((await _service.listDiversityRules()).map(DiversityRule.fromMap));
      _saved = await _service.listPowerBalances(widget.projectId);
      final settings = await _service.getProjectSettings(widget.projectId);
      _usage = settings?['building_usage'] as String?;
      _overall.text = _coef((settings?['overall_simultaneity'] as num?)?.toDouble() ?? 1);
      _reserve.text = _coef((settings?['reserve_factor'] as num?)?.toDouble() ?? 1);
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  double get _overallValue => parseOptionalNumber(_overall.text) ?? 1;
  double get _reserveValue => parseOptionalNumber(_reserve.text) ?? 1;

  PowerBalance _balance() => computePowerBalance(
        items: _items,
        rules: _rules,
        usage: _usage,
        overallSimultaneity: _overallValue,
        reserveFactor: _reserveValue,
      );

  Future<void> _saveFactors() async {
    final o = _overallValue;
    final r = _reserveValue;
    if (o <= 0 || o > 1 || r < 1) {
      showSnack(context, 'Coefficient général entre 0 (exclu) et 1 ; réserve supérieure ou égale à 1.');
      return;
    }
    try {
      await _service.saveBalanceFactors(widget.projectId, overall: o, reserve: r);
      if (mounted) showSnack(context, 'Coefficients enregistrés.');
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _saveBalance(PowerBalance b) async {
    if (hasErrors(b.issues)) {
      showSnack(context, 'Corrigez les erreurs avant d\'enregistrer le bilan.');
      return;
    }
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Enregistrer le bilan'),
        content: TextField(controller: note, maxLines: 2, decoration: const InputDecoration(labelText: 'Note (hypothèses, version...)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _service.savePowerBalance({
        'project_id': widget.projectId,
        'building_usage': _usage,
        'overall_simultaneity': b.overallSimultaneity,
        'reserve_factor': b.reserveFactor,
        'installed_w': double.parse(b.installedW.toStringAsFixed(2)),
        'demand_w': double.parse(b.demandW.toStringAsFixed(2)),
        'apparent_demand_va': b.apparentDemandVA == null ? null : double.parse(b.apparentDemandVA!.toStringAsFixed(2)),
        'equipment_count': b.itemsWithPower,
        'equipment_without_power': b.itemsWithoutPower.length,
        'details': b.toJson(),
        'note': note.text.trim().isEmpty ? null : note.text.trim(),
      });
      _saved = await _service.listPowerBalances(widget.projectId);
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _deleteSaved(Map<String, dynamic> row) async {
    final ok = await confirmDialog(context, 'Supprimer', 'Supprimer ce bilan enregistré ?');
    if (ok != true) return;
    try {
      await _service.deletePowerBalance(row['id'] as String);
      _saved = await _service.listPowerBalances(widget.projectId);
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final b = _balance();
    final rooms = installedByRoom(_items);
    final roomNames = {for (final i in _items) i.roomId: i.roomName};
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Bilan de puissance', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 4),
      Text('Destination : ${_usage == null ? 'non renseignée (section « Besoins »)' : buildingUsageLabels[_usage] ?? _usage}. '
          'Appel par catégorie = installé × Ku × Ks, puis × coefficient général × réserve.'),
      const SizedBox(height: 8),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: TextField(controller: _overall, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Coefficient général (≤ 1)'), onChanged: (_) => setState(() {}))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: _reserve, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Réserve (≥ 1)'), onChanged: (_) => setState(() {}))),
            ]),
            Align(alignment: Alignment.centerRight, child: TextButton(onPressed: _saveFactors, child: const Text('Mémoriser pour le projet'))),
          ]),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Puissance installée : ${_kw(b.installedW)}'),
            Text('Puissance d\'appel : ${_kw(b.demandW)}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            Text(b.apparentDemandVA == null ? 'Puissance apparente : non calculée (cos φ manquants)' : 'Puissance apparente d\'appel : ${_kva(b.apparentDemandVA!)}'),
            Text('${b.itemsWithPower} équipement(s) pris en compte • ${b.itemsWithoutPower.length} sans puissance'),
            const SizedBox(height: 4),
            IssuesView(b.issues),
          ]),
        ),
      ),
      if (b.itemsWithoutPower.isNotEmpty)
        ExpansionTile(
          title: Text('Équipements sans puissance (${b.itemsWithoutPower.length})'),
          subtitle: const Text('Renseignez-la depuis « Implantation » (modifier l\'équipement).'),
          children: [for (final i in b.itemsWithoutPower) ListTile(dense: true, title: Text(i.label), subtitle: Text(i.roomName))],
        ),
      const SizedBox(height: 8),
      Text('Par catégorie', style: Theme.of(context).textTheme.titleSmall),
      if (b.categories.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aucun équipement avec puissance. Implantez des équipements et renseignez leur puissance.')),
      ...b.categories.map((c) => Card(
            child: ListTile(
              title: Text('${_categoryLabels[c.category] ?? c.category} — ${c.count} équipement(s)'),
              subtitle: Text('Installé ${_kw(c.installedW)} • Ku ${_coef(c.ku)} • Ks ${_coef(c.ks)}\nAppel ${_kw(c.demandW)}'
                  '${!c.ruleFound ? '\nAucun coefficient défini (1 appliqué)' : !c.ruleConfirmed ? '\nCoefficients à confirmer' : ''}'
                  '${(c.reference ?? '').isEmpty ? '' : '\n${c.reference}'}'),
              isThreeLine: true,
            ),
          )),
      if (rooms.isNotEmpty)
        ExpansionTile(
          title: const Text('Puissance installée par pièce'),
          children: [for (final e in rooms.entries) ListTile(dense: true, title: Text(roomNames[e.key] ?? '?'), trailing: Text(_kw(e.value)))],
        ),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: () => _saveBalance(b), icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer ce bilan')),
      const SizedBox(height: 4),
      const Text('Résultat à valider par un professionnel habilité. Les coefficients par défaut sont à confirmer pour votre projet.', style: TextStyle(fontSize: 12)),
      if (_saved.isNotEmpty) ...[
        const SizedBox(height: 12),
        Text('Bilans enregistrés', style: Theme.of(context).textTheme.titleSmall),
        ..._saved.map((r) => ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('Appel ${_kw((r['demand_w'] as num).toDouble())} • installé ${_kw((r['installed_w'] as num).toDouble())}'),
              subtitle: Text('${(r['created_at'] as String).substring(0, 10)} • coef. ${_coef((r['overall_simultaneity'] as num).toDouble())} • réserve ${_coef((r['reserve_factor'] as num).toDouble())}'
                  '${(r['note'] ?? '').toString().isEmpty ? '' : '\n${r['note']}'}'),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _deleteSaved(r)),
            )),
      ],
    ]);
  }
}
