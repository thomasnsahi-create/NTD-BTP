import 'package:flutter/material.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Vue générale', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 6),
        const Text('Votre espace de pilotage des projets BTP.'),
        const SizedBox(height: 20),
        const Wrap(spacing: 12, runSpacing: 12, children: [
          _MetricCard(label: 'Projets actifs', value: '—', icon: Icons.apartment),
          _MetricCard(label: 'Budget engagé', value: '— FCFA', icon: Icons.account_balance_wallet),
          _MetricCard(label: 'Tâches en cours', value: '—', icon: Icons.task_alt),
          _MetricCard(label: 'Alertes', value: '—', icon: Icons.notifications_active),
        ]),
        const SizedBox(height: 20),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('Bienvenue dans BTP MANAGER', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Commencez par créer votre organisation, puis ajoutez un projet et '
                'sélectionnez les corps de métiers concernés. Les indicateurs seront '
                'alimentés par les données réelles dans les prochaines étapes.'),
          ]),
        )),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.label, required this.value, required this.icon});
  final String label, value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 220,
    child: Card(child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: const Color(0xFF176B45)),
        const SizedBox(height: 12),
        Text(value, style: Theme.of(context).textTheme.headlineSmall),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ]),
    )),
  );
}
