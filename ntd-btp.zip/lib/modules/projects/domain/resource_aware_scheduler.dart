/// Planification en jours ouvrés avec contrôle des capacités de ressources.
/// Les jours de semaine utilisent ISO-8601 : lundi=1 ... dimanche=7.
class WorkCalendarConfig {
  const WorkCalendarConfig({this.workingDays = const {1,2,3,4,5,6}, this.holidays = const {}, this.workingOverrides = const {}, this.hoursPerDay = 8});
  final Set<int> workingDays;
  final Set<DateTime> holidays;
  final Set<DateTime> workingOverrides;
  final double hoursPerDay;
  DateTime day(DateTime d) => DateTime(d.year,d.month,d.day);
  bool isWorkingDay(DateTime date) => workingOverrides.contains(day(date)) || (workingDays.contains(date.weekday) && !holidays.contains(day(date)));
  DateTime nextWorkingDay(DateTime date) { var d=day(date); while(!isWorkingDay(d)){d=d.add(const Duration(days:1));} return d; }
  DateTime nextWorkingDayAfter(DateTime date) => nextWorkingDay(day(date).add(const Duration(days:1)));
  DateTime addWorkingDays(DateTime start,int count) {
    if(count<0)return subtractWorkingDays(start,-count);
    var d=nextWorkingDay(start); var left=count-1;
    while(left>0){d=d.add(const Duration(days:1));if(isWorkingDay(d))left--;}
    return d;
  }
  DateTime subtractWorkingDays(DateTime start,int count) {
    if(count==0)return nextWorkingDay(start);
    var d=day(start).subtract(const Duration(days:1));
    while(!isWorkingDay(d))d=d.subtract(const Duration(days:1));
    var left=count-1;
    while(left>0){d=d.subtract(const Duration(days:1));if(isWorkingDay(d))left--;}
    return d;
  }
  int workingDaysBetween(DateTime start,DateTime end) {
    if(end.isBefore(start))return 0; var count=0; var d=day(start); final last=day(end);
    while(!d.isAfter(last)){if(isWorkingDay(d))count++;d=d.add(const Duration(days:1));}
    return count;
  }
}

class ResourceCapacity {
  const ResourceCapacity({required this.id,required this.capacity, this.unavailable = const []});
  final String id;
  final double capacity;
  final List<DateRange> unavailable;
}
class DateRange {
  const DateRange(this.start,this.end);
  final DateTime start,end;
  bool contains(DateTime d) => !d.isBefore(DateTime(start.year,start.month,start.day)) && !d.isAfter(DateTime(end.year,end.month,end.day));
}
class ResourceRequirement {
  const ResourceRequirement({required this.resourceId,required this.quantity});
  final String resourceId;
  final double quantity;
}
class ResourceScheduleResult {
  const ResourceScheduleResult({required this.start,required this.end,required this.changedIds,required this.conflicts});
  final Map<String,DateTime> start,end;
  final Set<String> changedIds;
  final List<String> conflicts;
  DateTime get finish => end.values.isEmpty ? DateTime.now() : end.values.reduce((a,b)=>a.isAfter(b)?a:b);
}

class ResourceAwareScheduler {
  static DateTime _day(DateTime d)=>DateTime(d.year,d.month,d.day);
  static DateTime _max(DateTime a,DateTime b)=>a.isAfter(b)?a:b;

  /// Recalcule les tâches actives en respectant calendrier, liens et capacités.
  /// [requirementsByTask] décrit les ressources requises par tâche.
  /// [existingReservations] contient les réservations à conserver (autres tâches ou engagements).
  static ResourceScheduleResult simulate({
    required List<Map<String,dynamic>> tasks,
    required List<Map<String,dynamic>> dependencies,
    required WorkCalendarConfig calendar,
    required Map<String,ResourceCapacity> resources,
    Map<String,List<ResourceRequirement>> requirementsByTask = const {},
    Map<String,List<DateRange>> existingReservations = const {},
    DateTime? today,
  }) {
    final active=tasks.where((t)=>t['status']!='cancelled' && t['planned_start']!=null && t['planned_end']!=null).toList();
    if(active.isEmpty)throw Exception('Aucune tâche datée à planifier.');
    final byId={for(final t in active)t['id'].toString():t}; final ids=byId.keys.toSet();
    final outgoing=<String,List<Map<String,dynamic>>>{for(final id in ids)id:[]}; final indegree=<String,int>{for(final id in ids)id:0};
    final edges=<Map<String,dynamic>>[];
    for(final d in dependencies){final to=d['task_id']?.toString(),from=d['depends_on_task_id']?.toString();if(!ids.contains(to)||!ids.contains(from))continue;final type=d['dependency_type']?.toString()??'finish_to_start';final e={'from':from!,'to':to!,'type':type};edges.add(e);outgoing[from]!.add(e);indegree[to]=indegree[to]!+1;}
    final queue=ids.where((id)=>indegree[id]==0).toList();final order=<String>[];
    while(queue.isNotEmpty){final id=queue.removeAt(0);order.add(id);for(final e in outgoing[id]!){final n=e['to'] as String;indegree[n]=indegree[n]!-1;if(indegree[n]==0)queue.add(n);}}
    if(order.length!=ids.length)throw Exception('Cycle de dépendances détecté.');

    final now=calendar.nextWorkingDay(_day(today??DateTime.now()));
    final starts=<String,DateTime>{},ends=<String,DateTime>{};
    final booked=<String,Map<DateTime,double>>{};
    for(final entry in existingReservations.entries){booked[entry.key]={};for(final range in entry.value){var d=_day(range.start);while(!d.isAfter(_day(range.end))){booked[entry.key]![d]=(booked[entry.key]![d]??0)+ (resources[entry.key]?.capacity??0);d=d.add(const Duration(days:1));}}}

    bool fits(String taskId,DateTime start,int duration){
      final reqs=requirementsByTask[taskId]??const <ResourceRequirement>[];
      for(var i=0;i<duration;i++){
        final date=calendar.addWorkingDays(start,i);
        for(final req in reqs){final resource=resources[req.resourceId];if(resource==null)throw Exception('Ressource ${req.resourceId} inconnue pour la tâche $taskId.');if(resource.unavailable.any((r)=>r.contains(date)))return false;final used=booked[req.resourceId]?[date]??0;if(used+req.quantity>resource.capacity+0.000001)return false;}
      }
      return true;
    }
    void reserve(String taskId,DateTime start,int duration){for(var i=0;i<duration;i++){final date=calendar.addWorkingDays(start,i);for(final req in requirementsByTask[taskId]??const <ResourceRequirement>[]){booked.putIfAbsent(req.resourceId,()=>{});booked[req.resourceId]![date]=(booked[req.resourceId]![date]??0)+req.quantity;}}}

    for(final id in order){
      final task=byId[id]!;final pct=((task['progress_percent'] as num?)?.toDouble()??0).clamp(0,100);
      final oldS=_day(DateTime.parse(task['planned_start'].toString()));final oldE=_day(DateTime.parse(task['planned_end'].toString()));
      final completed=task['status']=='completed'||pct>=100;
      if(completed){final s=task['actual_start']==null?oldS:_day(DateTime.parse(task['actual_start'].toString()));final e=task['actual_end']==null?oldE:_day(DateTime.parse(task['actual_end'].toString()));starts[id]=s;ends[id]=e;final completedDuration=calendar.workingDaysBetween(s,e).clamp(1,3650).toInt();reserve(id,calendar.nextWorkingDay(s),completedDuration);continue;}
      final fullDuration=calendar.workingDaysBetween(oldS,oldE).clamp(1,3650).toInt();
      final duration=((fullDuration*(100-pct)/100).ceil()).clamp(1,3650).toInt();
      var candidate=calendar.nextWorkingDay(_max(_max(oldS,now),oldS));
      for(final edge in edges.where((e)=>e['to']==id)){
        final pred=edge['from'] as String;final type=edge['type'];DateTime bound;
        if(type=='start_to_start')bound=starts[pred]!;
        else if(type=='finish_to_finish')bound=calendar.subtractWorkingDays(calendar.nextWorkingDay(ends[pred]!),duration-1);
        else if(type=='start_to_finish')bound=calendar.subtractWorkingDays(calendar.nextWorkingDay(starts[pred]!),duration-1);
        else bound=calendar.nextWorkingDayAfter(ends[pred]!);
        candidate=calendar.nextWorkingDay(_max(candidate,bound));
      }
      var attempts=0;
      while(!fits(id,candidate,duration)){candidate=calendar.addWorkingDays(candidate,2);attempts++;if(attempts>3650)throw Exception('Aucune capacité disponible pour la tâche « ${task['name']} » dans les dix prochaines années.');}
      final actualEnd=calendar.addWorkingDays(candidate,duration-1);
      starts[id]=candidate;ends[id]=actualEnd;reserve(id,candidate,duration);
    }
    // Vérification finale des dépendances, notamment si une tâche achevée bloque un successeur.
    final conflicts=<String>[];
    for(final e in edges){final p=e['from'] as String,s=e['to'] as String;final type=e['type'];final violated=switch(type){'start_to_start'=>starts[s]!.isBefore(starts[p]!), 'finish_to_finish'=>ends[s]!.isBefore(ends[p]!), 'start_to_finish'=>ends[s]!.isBefore(starts[p]!), _=>starts[s]!.isBefore(calendar.nextWorkingDayAfter(ends[p]!))};if(violated)conflicts.add('Dépendance non respectée : ${byId[s]!['name']} après ${byId[p]!['name']}');}
    if(conflicts.isNotEmpty)throw Exception(conflicts.join('\n'));
    final changed=<String>{};for(final id in ids){if(starts[id]!=_day(DateTime.parse(byId[id]!['planned_start'].toString()))||ends[id]!=_day(DateTime.parse(byId[id]!['planned_end'].toString())))changed.add(id);}
    return ResourceScheduleResult(start:starts,end:ends,changedIds:changed,conflicts:conflicts);
  }
}
