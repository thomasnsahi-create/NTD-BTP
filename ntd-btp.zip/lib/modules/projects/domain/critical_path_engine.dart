/// Calcul CPM en jours calendaires (dates inclusives), sans dépendance externe.
/// Les quatre types de liens sont convertis en contraintes sur les dates de début.
class CriticalPathResult {
  const CriticalPathResult({required this.orderedIds, required this.earlyStart, required this.lateStart, required this.durationDays, required this.slackDays, required this.criticalIds, required this.projectStart, required this.projectFinish});
  final List<String> orderedIds;
  final Map<String, DateTime> earlyStart;
  final Map<String, DateTime> lateStart;
  final Map<String, int> durationDays;
  final Map<String, int> slackDays;
  final Set<String> criticalIds;
  final DateTime projectStart;
  final DateTime projectFinish;
  int get totalDurationDays => projectFinish.difference(projectStart).inDays + 1;
}

class ScheduleProposal {
  const ScheduleProposal({required this.start, required this.end, required this.changedIds, required this.finish, required this.delayDays});
  final Map<String, DateTime> start;
  final Map<String, DateTime> end;
  final Set<String> changedIds;
  final DateTime finish;
  final int delayDays;
}

class CriticalPathEngine {
  static DateTime day(DateTime d) => DateTime(d.year, d.month, d.day);
  static DateTime _max(DateTime a, DateTime b) => a.isAfter(b) ? a : b;
  static DateTime _min(DateTime a, DateTime b) => a.isBefore(b) ? a : b;

  static CriticalPathResult analyze(List<Map<String, dynamic>> tasks, List<Map<String, dynamic>> dependencies) {
    final dated = tasks.where((t) => t['planned_start'] != null && t['planned_end'] != null && t['status'] != 'cancelled').toList();
    if (dated.isEmpty) throw Exception('Aucune tâche active ne possède deux dates prévisionnelles.');
    final byId = {for (final t in dated) t['id'].toString(): t};
    final ids = byId.keys.toList();
    final duration = <String, int>{};
    final baseline = <String, DateTime>{};
    for (final id in ids) {
      final t = byId[id]!;
      final s = day(DateTime.parse(t['planned_start'].toString()));
      final e = day(DateTime.parse(t['planned_end'].toString()));
      if (e.isBefore(s)) throw Exception('Dates invalides pour ${t['name']}.');
      baseline[id] = s;
      duration[id] = e.difference(s).inDays + 1;
    }
    final edges = <Map<String, dynamic>>[];
    final outgoing = <String, List<Map<String, dynamic>>>{for (final id in ids) id: []};
    final indegree = <String, int>{for (final id in ids) id: 0};
    for (final d in dependencies) {
      final successor = d['task_id']?.toString();
      final predecessor = d['depends_on_task_id']?.toString();
      if (!byId.containsKey(successor) || !byId.containsKey(predecessor)) continue;
      final type = d['dependency_type']?.toString() ?? 'finish_to_start';
      final weight = switch (type) {
        'start_to_start' => 0,
        'finish_to_finish' => duration[predecessor]! - duration[successor]!,
        'start_to_finish' => 1 - duration[successor]!,
        _ => duration[predecessor]!,
      };
      final edge = {'from': predecessor!, 'to': successor!, 'weight': weight, 'type': type};
      edges.add(edge); outgoing[predecessor]!.add(edge); indegree[successor] = indegree[successor]! + 1;
    }
    final queue = ids.where((id) => indegree[id] == 0).toList();
    final order = <String>[];
    while (queue.isNotEmpty) {
      final id = queue.removeAt(0); order.add(id);
      for (final e in outgoing[id]!) { final next = e['to'] as String; indegree[next] = indegree[next]! - 1; if (indegree[next] == 0) queue.add(next); }
    }
    if (order.length != ids.length) throw Exception('Le réseau de dépendances contient une boucle. Corrigez les liaisons avant le calcul.');
    final origin = baseline.values.reduce(_min);
    final esOffset = <String, int>{};
    for (final id in order) {
      var value = baseline[id]!.difference(origin).inDays;
      for (final e in edges.where((x) => x['to'] == id)) {
        final p = e['from'] as String;
        final candidate = esOffset[p]! + (e['weight'] as int);
        if (candidate > value) value = candidate;
      }
      esOffset[id] = value;
    }
    var finishOffset = 0;
    for (final id in ids) { final f = esOffset[id]! + duration[id]!; if (f > finishOffset) finishOffset = f; }
    final lsOffset = <String, int>{};
    for (final id in order.reversed) {
      final successors = edges.where((e) => e['from'] == id).toList();
      var latest = finishOffset - duration[id]!;
      for (final e in successors) {
        final s = e['to'] as String;
        final bound = lsOffset[s]! - (e['weight'] as int);
        if (bound < latest) latest = bound;
      }
      lsOffset[id] = latest;
    }
    final early = <String, DateTime>{}, late = <String, DateTime>{}, slack = <String, int>{};
    final critical = <String>{};
    for (final id in ids) {
      early[id] = origin.add(Duration(days: esOffset[id]!));
      late[id] = origin.add(Duration(days: lsOffset[id]!));
      slack[id] = lsOffset[id]! - esOffset[id]!;
      if (slack[id]! <= 0) critical.add(id);
    }
    return CriticalPathResult(orderedIds: order, earlyStart: early, lateStart: late, durationDays: duration, slackDays: slack, criticalIds: critical, projectStart: origin, projectFinish: origin.add(Duration(days: finishOffset - 1)));
  }

  /// Simulation: les tâches non terminées ne redémarrent pas avant aujourd'hui.
  /// La durée restante est proportionnelle à l'avancement déclaré (minimum 1 jour).
  /// Les tâches terminées restent fixes. Les contraintes sont propagées en avant.
  static ScheduleProposal simulate(List<Map<String, dynamic>> tasks, List<Map<String, dynamic>> dependencies, {DateTime? today, DateTime? baselineFinish}) {
    final active = tasks.where((t) => t['status'] != 'cancelled' && t['planned_start'] != null && t['planned_end'] != null).toList();
    if (active.isEmpty) throw Exception('Aucune tâche datée à reprogrammer.');
    final ids = active.map((t) => t['id'].toString()).toSet();
    final byId = {for (final t in active) t['id'].toString(): t};
    final remaining = <String, int>{};
    final oldStart = <String, DateTime>{}, oldEnd = <String, DateTime>{};
    final fixed = <String>{};
    for (final id in ids) {
      final t = byId[id]!;
      final plannedS = day(DateTime.parse(t['planned_start'].toString()));
      final plannedE = day(DateTime.parse(t['planned_end'].toString()));
      final pct = ((t['progress_percent'] as num?)?.toDouble() ?? 0).clamp(0, 100);
      final isComplete = t['status'] == 'completed' || pct >= 100;
      final s = isComplete && t['actual_start'] != null ? day(DateTime.parse(t['actual_start'].toString())) : plannedS;
      final e = isComplete && t['actual_end'] != null ? day(DateTime.parse(t['actual_end'].toString())) : plannedE;
      oldStart[id] = plannedS; oldEnd[id] = plannedE;
      if (isComplete) { remaining[id] = 0; fixed.add(id); oldStart[id] = s; oldEnd[id] = e; }
      else { final total = e.difference(s).inDays + 1; remaining[id] = ((total * (100 - pct) / 100).ceil()).clamp(1, 3650).toInt(); }
    }
    final outgoing = <String, List<Map<String, dynamic>>>{for (final id in ids) id: []};
    final indegree = <String, int>{for (final id in ids) id: 0};
    final edges = <Map<String, dynamic>>[];
    for (final d in dependencies) {
      final to = d['task_id']?.toString(), from = d['depends_on_task_id']?.toString();
      if (!ids.contains(to) || !ids.contains(from)) continue;
      final type = d['dependency_type']?.toString() ?? 'finish_to_start';
      final w = switch(type) { 'start_to_start' => 0, 'finish_to_finish' => remaining[from]! - remaining[to]!, 'start_to_finish' => 1 - remaining[to]!, _ => remaining[from]! };
      final edge = {'from':from!, 'to':to!, 'weight':w, 'type':type}; edges.add(edge); outgoing[from]!.add(edge); indegree[to] = indegree[to]! + 1;
    }
    final queue = ids.where((id)=>indegree[id]==0).toList(); final order=<String>[];
    while(queue.isNotEmpty){final id=queue.removeAt(0);order.add(id);for(final e in outgoing[id]!){final n=e['to'] as String;indegree[n]=indegree[n]!-1;if(indegree[n]==0)queue.add(n);}}
    if(order.length!=ids.length)throw Exception('Boucle détectée dans les dépendances : reprogrammation impossible.');
    final now = day(today ?? DateTime.now());
    final starts=<String,DateTime>{}, ends=<String,DateTime>{};
    for(final id in order){
      if(fixed.contains(id)){starts[id]=oldStart[id]!;ends[id]=oldEnd[id]!;continue;}
      var proposed=_max(oldStart[id]!.isBefore(now)?now:oldStart[id]!, now);
      for(final e in edges.where((x)=>x['to']==id)){
        final p=e['from'] as String; final type=e['type']; DateTime bound;
        if(type=='start_to_start')bound=starts[p]!;
        else if(type=='finish_to_finish')bound=ends[p]!.subtract(Duration(days:remaining[id]!-1));
        else if(type=='start_to_finish')bound=starts[p]!.subtract(Duration(days:remaining[id]!-1));
        else bound=ends[p]!.add(const Duration(days:1));
        proposed=_max(proposed,bound);
      }
      starts[id]=proposed; ends[id]=proposed.add(Duration(days:remaining[id]!-1));
    }
    for (final e in edges) {
      final from = e['from'] as String, to = e['to'] as String, type = e['type'];
      final violated = switch (type) {
        'start_to_start' => starts[to]!.isBefore(starts[from]!),
        'finish_to_finish' => ends[to]!.isBefore(ends[from]!),
        'start_to_finish' => ends[to]!.isBefore(starts[from]!),
        _ => starts[to]!.isBefore(ends[from]!.add(const Duration(days: 1))),
      };
      if (violated) throw Exception('La tâche terminée « ${byId[to]!['name']} » entre en conflit avec une dépendance. Une validation manuelle est nécessaire.');
    }
    final changed=<String>{}; for(final id in ids){if(starts[id]!=oldStart[id]||ends[id]!=oldEnd[id])changed.add(id);}
    final oldFinish=baselineFinish == null ? oldEnd.values.reduce(_max) : day(baselineFinish), newFinish=ends.values.reduce(_max);
    return ScheduleProposal(start:starts,end:ends,changedIds:changed,finish:newFinish,delayDays:newFinish.difference(oldFinish).inDays);
  }
}
