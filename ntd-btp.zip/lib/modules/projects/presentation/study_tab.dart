import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../core/utils/format.dart';
import '../data/study_service.dart';

const Map<String, String> _kindLabels = {
  'material': 'Matériaux',
  'labor': 'Main-d’œuvre',
  'equipment': 'Matériel',
  'machine': 'Engins',
  'service': 'Prestations',
  'subcontract': 'Sous-traitance',
};

const Map<String, String> _statusLabels = {
  'draft': 'Brouillon',
  'approved': 'Validé',
  'superseded': 'Remplacé',
};

const Map<String, String> _unitLabels = {
  'm': 'm',
  'ml': 'ml',
  'm2': 'm²',
  'm3': 'm³',
  'kg': 'kg',
  't': 't',
  'u': 'u',
  'forfait': 'forfait',
};

/// Module Étude : devis estimatif, fiches de métrés et bibliothèque des prix.
class StudyTab extends StatefulWidget {
  const StudyTab({
    super.key,
    required this.projectId,
    required this.organizationId,
    this.currency = 'XAF',
    this.onChanged,
  });

  final String projectId;
  final String organizationId;
  final String currency;
  final VoidCallback? onChanged;

  @override
  State<StudyTab> createState() => _StudyTabState();
}

class _StudyTabState extends State<StudyTab> {
  final _service = StudyService.instance;
  bool _loading = true;
  String? _error;
  int _section = 0;
  List<Map<String, dynamic>> _estimates = [];
  List<Map<String, dynamic>> _items = [];
  List<Map<String, dynamic>> _lots = [];
  List<Map<String, dynamic>> _prices = [];
  List<Map<String, dynamic>> _measurements = [];
  final Map<String, List<Map<String, dynamic>>> _measureItems = {};
  String? _selectedEstimate;

  @override
  void initState() {
    super.initState();
    _load();
  }

  // ------------------------------------------------------------------ utilitaires
  String _clean(Object e) => e is PostgrestException ? e.message : e.toString();

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  String _money(num? value) => '${formatAmount(value)} ${widget.currency}';

  Map<String, dynamic>? get _current {
    for (final e in _estimates) {
      if (e['id'] == _selectedEstimate) return e;
    }
    return null;
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        _service.listEstimates(widget.projectId),
        _service.listLots(widget.projectId),
        _service.listPrices(widget.organizationId),
        _service.listMeasurements(widget.projectId),
      ]);
      _estimates = results[0];
      _lots = results[1];
      _prices = results[2];
      _measurements = results[3];
      if (_estimates.isEmpty) {
        _selectedEstimate = null;
      } else if (!_estimates.any((e) => e['id'] == _selectedEstimate)) {
        _selectedEstimate = _estimates.first['id'] as String;
      }
      final selected = _selectedEstimate;
      _items = selected == null ? <Map<String, dynamic>>[] : await _service.listEstimateItems(selected);
    } catch (e) {
      _error = _clean(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _run(Future<void> Function() action, {String? ok, bool notify = false}) async {
    try {
      await action();
      if (ok != null) _snack(ok);
      await _load();
      if (notify) widget.onChanged?.call();
    } catch (e) {
      _snack(_clean(e));
    }
  }

  Future<bool?> _confirm(String title, String message) {
    return showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Confirmer')),
        ],
      ),
    );
  }

  Future<double?> _askNumber(String title, String label, {String initial = ''}) async {
    final controller = TextEditingController(text: initial);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: label),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Valider')),
        ],
      ),
    );
    if (ok != true) return null;
    return parseNumber(controller.text);
  }

  // ------------------------------------------------------------------ interface
  @override
  Widget build(BuildContext context) {
    if (_loading && _estimates.isEmpty && _prices.isEmpty && _measurements.isEmpty && _error == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_error!),
            const SizedBox(height: 12),
            FilledButton(onPressed: _load, child: const Text('Réessayer')),
          ]),
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<int>(
            segments: const <ButtonSegment<int>>[
              ButtonSegment<int>(value: 0, label: Text('Devis'), icon: Icon(Icons.request_quote_outlined)),
              ButtonSegment<int>(value: 1, label: Text('Métrés'), icon: Icon(Icons.straighten)),
              ButtonSegment<int>(value: 2, label: Text('Prix'), icon: Icon(Icons.sell_outlined)),
            ],
            selected: {_section},
            onSelectionChanged: (s) => setState(() => _section = s.first),
          ),
          const SizedBox(height: 12),
          if (_section == 0) ..._estimateSection(),
          if (_section == 1) ..._measureSection(),
          if (_section == 2) ..._priceSection(),
        ],
      ),
    );
  }

  // ================================================================== DEVIS
  List<Widget> _estimateSection() {
    if (_estimates.isEmpty) {
      return [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Aucun devis estimatif', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              const Text(
                'Créez le devis, ajoutez les lignes par lot, puis validez-le : '
                'le budget initial est alors créé automatiquement.',
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _createEstimate,
                icon: const Icon(Icons.add),
                label: const Text('Créer le devis estimatif'),
              ),
            ]),
          ),
        ),
      ];
    }
    final cur = _current;
    return [
      Wrap(
        spacing: 8,
        children: _estimates
            .map((e) => ChoiceChip(
                  label: Text('v${e['version']} • ${_statusLabels[e['status']] ?? e['status']}'),
                  selected: e['id'] == _selectedEstimate,
                  onSelected: (_) => _selectEstimate(e['id'] as String),
                ))
            .toList(),
      ),
      const SizedBox(height: 8),
      if (cur != null) _estimateHeader(cur),
      if (cur != null) ..._itemWidgets(cur),
    ];
  }

  Future<void> _selectEstimate(String id) async {
    setState(() => _selectedEstimate = id);
    try {
      final rows = await _service.listEstimateItems(id);
      if (!mounted) return;
      setState(() => _items = rows);
    } catch (e) {
      _snack(_clean(e));
    }
  }

  Widget _estimateHeader(Map<String, dynamic> cur) {
    final draft = cur['status'] == 'draft';
    final hasDraft = _estimates.any((e) => e['status'] == 'draft');
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(cur['title'].toString(), style: theme.textTheme.titleMedium)),
            Chip(label: Text(_statusLabels[cur['status']] ?? cur['status'].toString())),
          ]),
          const SizedBox(height: 8),
          Text('Sous-total : ${_money(cur['subtotal'] as num?)}'),
          Text('Frais retenus (${formatQuantity(cur['fees_percent'] as num?)} %) : ${_money(cur['fees_amount'] as num?)}'),
          const SizedBox(height: 4),
          Text('TOTAL : ${_money(cur['total_amount'] as num?)}',
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          if (draft)
            Wrap(spacing: 8, runSpacing: 4, children: [
              OutlinedButton.icon(onPressed: _addItem, icon: const Icon(Icons.add), label: const Text('Ajouter une ligne')),
              OutlinedButton.icon(onPressed: _editFees, icon: const Icon(Icons.percent), label: const Text('Frais')),
              FilledButton.icon(onPressed: _approve, icon: const Icon(Icons.verified_outlined), label: const Text('Valider le devis')),
              TextButton.icon(onPressed: _deleteEstimate, icon: const Icon(Icons.delete_outline), label: const Text('Supprimer')),
            ])
          else ...[
            const Text('Devis verrouillé : il ne peut plus être modifié. Pour le changer, créez un avenant.',
                style: TextStyle(fontSize: 12)),
            if (cur['status'] == 'approved' && !hasDraft)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: FilledButton.tonalIcon(
                  onPressed: _createEstimate,
                  icon: const Icon(Icons.edit_note),
                  label: const Text('Créer un avenant'),
                ),
              ),
          ],
        ]),
      ),
    );
  }

  List<Widget> _itemWidgets(Map<String, dynamic> cur) {
    final editable = cur['status'] == 'draft';
    if (_items.isEmpty) {
      return [const Padding(padding: EdgeInsets.all(16), child: Text('Aucune ligne dans ce devis.'))];
    }
    final groups = <String, List<Map<String, dynamic>>>{};
    for (final it in _items) {
      final key = (it['work_package_id'] as String?) ?? '';
      groups.putIfAbsent(key, () => <Map<String, dynamic>>[]).add(it);
    }
    final widgets = <Widget>[];
    groups.forEach((key, list) {
      final name = key.isEmpty ? 'Sans lot' : ((list.first['work_packages'] as Map?)?['name']?.toString() ?? 'Lot');
      final sum = list.fold<double>(0, (s, x) => s + ((x['total'] as num?)?.toDouble() ?? 0));
      widgets.add(Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 4),
        child: Row(children: [
          Expanded(child: Text(name, style: Theme.of(context).textTheme.titleSmall)),
          Text(_money(sum), style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
      ));
      for (final it in list) {
        widgets.add(Card(
          margin: const EdgeInsets.symmetric(vertical: 2),
          child: ListTile(
            dense: true,
            title: Text(it['designation'].toString()),
            subtitle: Text(
              '${formatQuantity(it['quantity'] as num?)} ${it['unit']} × ${formatAmount(it['unit_price'] as num?)} = ${_money(it['total'] as num?)}',
            ),
            onTap: editable ? () => _editItem(it) : null,
            trailing: editable
                ? IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => _run(() => _service.deleteEstimateItem(it['id'] as String)),
                  )
                : null,
          ),
        ));
      }
    });
    return widgets;
  }

  Future<void> _createEstimate() async {
    await _run(() async {
      final id = await _service.createEstimateVersion(widget.projectId);
      _selectedEstimate = id;
    }, ok: 'Devis créé');
  }

  Future<void> _addItem() async {
    final values = await _itemDialog();
    final estimateId = _selectedEstimate;
    if (values == null || estimateId == null) return;
    await _run(() => _service.addEstimateItem(estimateId, values, _items.length + 1));
  }

  Future<void> _editItem(Map<String, dynamic> item) async {
    final values = await _itemDialog(existing: item);
    if (values == null) return;
    await _run(() => _service.updateEstimateItem(item['id'] as String, values));
  }

  Future<void> _editFees() async {
    final cur = _current;
    if (cur == null) return;
    final value = await _askNumber('Frais retenus', 'Pourcentage (0 à 100)', initial: formatQuantity(cur['fees_percent'] as num?));
    if (value == null) return;
    final percent = value < 0 ? 0.0 : (value > 100 ? 100.0 : value);
    await _run(() => _service.setEstimateFees(cur['id'] as String, percent));
  }

  Future<void> _approve() async {
    final cur = _current;
    if (cur == null) return;
    final isRevision = _estimates.any((e) => e['status'] == 'approved');
    final ok = await _confirm(
      isRevision ? 'Valider cet avenant ?' : 'Valider le devis ?',
      isRevision
          ? 'L’avenant sera enregistré avec son historique. Le budget initial reste inchangé.'
          : 'Le budget initial sera créé à partir de ce devis (quantités et prix de référence conservés). '
              'Après validation, le devis ne pourra plus être modifié.',
    );
    if (ok != true) return;
    await _run(
      () async {
        await _service.approveEstimate(cur['id'] as String);
      },
      ok: isRevision ? 'Avenant validé' : 'Devis validé — budget initial créé',
      notify: true,
    );
  }

  Future<void> _deleteEstimate() async {
    final cur = _current;
    if (cur == null) return;
    final ok = await _confirm('Supprimer ce brouillon ?', 'Le devis brouillon et ses lignes seront supprimés.');
    if (ok != true) return;
    await _run(() => _service.deleteEstimate(cur['id'] as String));
  }

  Future<Map<String, dynamic>?> _pickPrice() {
    return showDialog<Map<String, dynamic>>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Bibliothèque des prix'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: _prices
                .map((p) => ListTile(
                      dense: true,
                      title: Text(p['designation'].toString()),
                      subtitle: Text('${_kindLabels[p['kind']] ?? ''} • ${formatAmount(p['unit_price'] as num?)} / ${p['unit']}'),
                      onTap: () => Navigator.pop(c, p),
                    ))
                .toList(),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Fermer'))],
      ),
    );
  }

  Future<Map<String, dynamic>?> _itemDialog({Map<String, dynamic>? existing}) async {
    String? lot = existing?['work_package_id'] as String?;
    String kind = (existing?['kind'] as String?) ?? 'material';
    String? priceId = existing?['price_id'] as String?;
    final designation = TextEditingController(text: existing?['designation']?.toString() ?? '');
    final unit = TextEditingController(text: existing?['unit']?.toString() ?? '');
    final qty = TextEditingController(text: existing == null ? '' : formatQuantity(existing['quantity'] as num?));
    final price = TextEditingController(text: existing == null ? '' : (existing['unit_price'] ?? '').toString());
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(existing == null ? 'Nouvelle ligne' : 'Modifier la ligne'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String?>(
                value: lot,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Lot'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Sans lot')),
                  ..._lots.map((l) => DropdownMenuItem<String?>(
                        value: l['id'] as String,
                        child: Text('${l['code'] ?? ''} ${l['name']}'.trim(), overflow: TextOverflow.ellipsis),
                      )),
                ],
                onChanged: (v) => setD(() => lot = v),
              ),
              DropdownButtonFormField<String>(
                value: kind,
                decoration: const InputDecoration(labelText: 'Nature'),
                items: _kindLabels.entries
                    .map((e) => DropdownMenuItem<String>(value: e.key, child: Text(e.value)))
                    .toList(),
                onChanged: (v) => setD(() => kind = v ?? kind),
              ),
              if (_prices.isNotEmpty)
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: () async {
                      final p = await _pickPrice();
                      if (p == null) return;
                      setD(() {
                        priceId = p['id'] as String;
                        kind = p['kind'] as String;
                        designation.text = p['designation'].toString();
                        unit.text = p['unit'].toString();
                        price.text = p['unit_price'].toString();
                      });
                    },
                    icon: const Icon(Icons.sell_outlined),
                    label: const Text('Choisir dans la bibliothèque des prix'),
                  ),
                ),
              TextField(controller: designation, decoration: const InputDecoration(labelText: 'Désignation *')),
              TextField(controller: unit, decoration: const InputDecoration(labelText: 'Unité * (m², m³, u, kg…)')),
              TextField(
                controller: qty,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Quantité'),
              ),
              TextField(
                controller: price,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: 'Prix unitaire (${widget.currency})'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () => Navigator.pop(c, designation.text.trim().isNotEmpty && unit.text.trim().isNotEmpty),
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return null;
    return {
      'work_package_id': lot,
      'kind': kind,
      'designation': designation.text.trim(),
      'unit': unit.text.trim(),
      'quantity': parseNumber(qty.text),
      'unit_price': parseNumber(price.text),
      'price_id': priceId,
    };
  }

  // ================================================================== MÉTRÉS
  List<Widget> _measureSection() {
    return [
      Row(children: [
        Expanded(child: Text('Fiches de métrés (${_measurements.length})', style: Theme.of(context).textTheme.titleMedium)),
        FilledButton.tonalIcon(onPressed: _addMeasurement, icon: const Icon(Icons.add), label: const Text('Nouvelle fiche')),
      ]),
      if (_measurements.isEmpty)
        const Padding(padding: EdgeInsets.all(16), child: Text('Aucune fiche de métrés. Créez une fiche par ouvrage ou par lot.')),
      ..._measurements.map(_measureCard),
    ];
  }

  Widget _measureCard(Map<String, dynamic> m) {
    final id = m['id'] as String;
    final items = _measureItems[id];
    final lotName = (m['work_packages'] as Map?)?['name']?.toString();
    return Card(
      child: ExpansionTile(
        key: PageStorageKey<String>('fiche-$id'),
        title: Text(m['title'].toString()),
        subtitle: Text(lotName == null ? 'Sans lot' : 'Lot : $lotName'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        onExpansionChanged: (open) {
          if (open && _measureItems[id] == null) _loadMeasureItems(id);
        },
        children: [
          if (items == null)
            const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator()))
          else ...[
            if (items.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aucune ligne de métré.')),
            ...items.map((it) => ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text('${it['number']}. ${it['designation']}'),
                  subtitle: Text(_measureSubtitle(it)),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => _deleteMeasureItem(id, it['id'] as String),
                  ),
                )),
          ],
          Wrap(spacing: 8, runSpacing: 4, children: [
            OutlinedButton.icon(
              onPressed: () => _addMeasureItem(id, items?.length ?? 0),
              icon: const Icon(Icons.add),
              label: const Text('Ajouter une ligne'),
            ),
            OutlinedButton.icon(
              onPressed: () => _measureToEstimate(m),
              icon: const Icon(Icons.request_quote_outlined),
              label: const Text('Ajouter au devis'),
            ),
            TextButton.icon(
              onPressed: () => _deleteMeasurement(id),
              icon: const Icon(Icons.delete_outline),
              label: const Text('Supprimer la fiche'),
            ),
          ]),
        ],
      ),
    );
  }

  String _measureSubtitle(Map<String, dynamic> it) {
    final dims = <String>[];
    final values = <String, dynamic>{
      'L': it['length'],
      'l': it['width'],
      'H': it['height'],
      'Ép': it['thickness'],
    };
    values.forEach((key, value) {
      if (value != null) dims.add('$key ${formatQuantity(value as num?)}');
    });
    final loc = (it['location'] as String?)?.trim();
    final parts = <String>[
      if (loc != null && loc.isNotEmpty) loc,
      if (dims.isNotEmpty) dims.join(' × '),
      'N ${formatQuantity(it['count'] as num?)}',
      '= ${formatQuantity(it['quantity'] as num?)} ${_unitLabels[it['unit']] ?? it['unit']}',
    ];
    return parts.join(' • ');
  }

  Future<void> _loadMeasureItems(String id) async {
    try {
      final rows = await _service.listMeasurementItems(id);
      if (!mounted) return;
      setState(() => _measureItems[id] = rows);
    } catch (e) {
      _snack(_clean(e));
    }
  }

  Future<void> _addMeasurement() async {
    final title = TextEditingController();
    String? lot;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Nouvelle fiche de métrés'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Intitulé *')),
            DropdownButtonFormField<String?>(
              value: lot,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Lot'),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Sans lot')),
                ..._lots.map((l) => DropdownMenuItem<String?>(
                      value: l['id'] as String,
                      child: Text('${l['code'] ?? ''} ${l['name']}'.trim(), overflow: TextOverflow.ellipsis),
                    )),
              ],
              onChanged: (v) => setD(() => lot = v),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(c, title.text.trim().isNotEmpty), child: const Text('Créer')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await _run(() => _service.createMeasurement(widget.projectId, title.text, lot));
  }

  Future<void> _deleteMeasurement(String id) async {
    final ok = await _confirm('Supprimer cette fiche ?', 'La fiche et toutes ses lignes seront supprimées.');
    if (ok != true) return;
    _measureItems.remove(id);
    await _run(() => _service.deleteMeasurement(id));
  }

  Future<void> _deleteMeasureItem(String measurementId, String itemId) async {
    try {
      await _service.deleteMeasurementItem(itemId);
      await _loadMeasureItems(measurementId);
    } catch (e) {
      _snack(_clean(e));
    }
  }

  Future<void> _addMeasureItem(String measurementId, int existingCount) async {
    final designation = TextEditingController();
    final location = TextEditingController();
    final length = TextEditingController();
    final width = TextEditingController();
    final height = TextEditingController();
    final thickness = TextEditingController();
    final count = TextEditingController(text: '1');
    final plan = TextEditingController();
    final formula = TextEditingController();
    String unit = 'm2';
    const numberKeyboard = TextInputType.numberWithOptions(decimal: true);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Ligne de métré'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: designation, decoration: const InputDecoration(labelText: 'Désignation *')),
              TextField(controller: location, decoration: const InputDecoration(labelText: 'Localisation')),
              DropdownButtonFormField<String>(
                value: unit,
                decoration: const InputDecoration(labelText: 'Unité'),
                items: _unitLabels.entries
                    .map((e) => DropdownMenuItem<String>(value: e.key, child: Text(e.value)))
                    .toList(),
                onChanged: (v) => setD(() => unit = v ?? unit),
              ),
              Row(children: [
                Expanded(child: TextField(controller: length, keyboardType: numberKeyboard, decoration: const InputDecoration(labelText: 'Longueur'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: width, keyboardType: numberKeyboard, decoration: const InputDecoration(labelText: 'Largeur'))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: height, keyboardType: numberKeyboard, decoration: const InputDecoration(labelText: 'Hauteur'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: thickness, keyboardType: numberKeyboard, decoration: const InputDecoration(labelText: 'Épaisseur'))),
              ]),
              TextField(controller: count, keyboardType: numberKeyboard, decoration: const InputDecoration(labelText: 'Nombre')),
              TextField(controller: formula, decoration: const InputDecoration(labelText: 'Formule / remarque de calcul')),
              TextField(controller: plan, decoration: const InputDecoration(labelText: 'Référence du plan')),
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  'm : nombre × longueur • m² : nombre × longueur × largeur • m³ : nombre × L × l × hauteur (ou épaisseur) • autres unités : nombre.',
                  style: TextStyle(fontSize: 11),
                ),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(c, designation.text.trim().isNotEmpty), child: const Text('Ajouter')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await _service.addMeasurementItem(measurementId, {
        'number': existingCount + 1,
        'designation': designation.text.trim(),
        'location': location.text.trim().isEmpty ? null : location.text.trim(),
        'unit': unit,
        'length': parseOptionalNumber(length.text),
        'width': parseOptionalNumber(width.text),
        'height': parseOptionalNumber(height.text),
        'thickness': parseOptionalNumber(thickness.text),
        'count': parseOptionalNumber(count.text) ?? 1,
        'formula': formula.text.trim().isEmpty ? null : formula.text.trim(),
        'plan_ref': plan.text.trim().isEmpty ? null : plan.text.trim(),
      });
      await _loadMeasureItems(measurementId);
    } catch (e) {
      _snack(_clean(e));
    }
  }

  Future<void> _measureToEstimate(Map<String, dynamic> m) async {
    final drafts = _estimates.where((e) => e['status'] == 'draft').toList();
    if (drafts.isEmpty) {
      _snack('Créez d’abord un devis brouillon (onglet Devis).');
      return;
    }
    final id = m['id'] as String;
    List<Map<String, dynamic>> items;
    try {
      items = _measureItems[id] ?? await _service.listMeasurementItems(id);
    } catch (e) {
      _snack(_clean(e));
      return;
    }
    if (items.isEmpty) {
      _snack('La fiche ne contient aucune ligne.');
      return;
    }
    final units = items.map((x) => x['unit'].toString()).toSet();
    if (units.length != 1) {
      _snack('La fiche mélange plusieurs unités : séparez-la en fiches homogènes.');
      return;
    }
    final total = items.fold<double>(0, (s, x) => s + ((x['quantity'] as num?)?.toDouble() ?? 0));
    final unit = units.first;
    final unitPrice = await _askNumber(
      'Prix unitaire',
      'Prix par ${_unitLabels[unit] ?? unit} (${widget.currency}) pour ${formatQuantity(total)} ${_unitLabels[unit] ?? unit}',
    );
    if (unitPrice == null) return;
    final estimateId = drafts.first['id'] as String;
    final values = <String, dynamic>{
      'work_package_id': m['work_package_id'],
      'kind': 'material',
      'designation': m['title'].toString(),
      'unit': _unitLabels[unit] ?? unit,
      'quantity': total,
      'unit_price': unitPrice,
    };
    await _run(() async {
      await _service.addEstimateItem(estimateId, values, _items.length + 1);
      _selectedEstimate = estimateId;
      _section = 0;
    }, ok: 'Ligne ajoutée au devis');
  }

  // ================================================================== PRIX
  List<Widget> _priceSection() {
    final widgets = <Widget>[
      Row(children: [
        Expanded(child: Text('Bibliothèque des prix (${_prices.length})', style: Theme.of(context).textTheme.titleMedium)),
        FilledButton.tonalIcon(onPressed: _addPrice, icon: const Icon(Icons.add), label: const Text('Nouveau prix')),
      ]),
    ];
    if (_prices.isEmpty) {
      widgets.add(const Padding(
        padding: EdgeInsets.all(16),
        child: Text('Aucun prix enregistré. Ajoutez vos matériaux, main-d’œuvre, matériel, engins et prestations.'),
      ));
    }
    for (final kind in _kindLabels.keys) {
      final list = _prices.where((p) => p['kind'] == kind).toList();
      if (list.isEmpty) continue;
      widgets.add(Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 4),
        child: Text(_kindLabels[kind] ?? kind, style: Theme.of(context).textTheme.titleSmall),
      ));
      for (final p in list) {
        widgets.add(Card(
          margin: const EdgeInsets.symmetric(vertical: 2),
          child: ListTile(
            dense: true,
            title: Text(p['designation'].toString()),
            subtitle: Text('${_money(p['unit_price'] as num?)} / ${p['unit']}${_priceExtra(p)}'),
            trailing: PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'edit') _editPrice(p);
                if (v == 'history') _showPriceHistory(p);
                if (v == 'archive') _run(() => _service.archivePrice(p['id'] as String));
              },
              itemBuilder: (_) => const [
                PopupMenuItem<String>(value: 'edit', child: Text('Modifier le prix')),
                PopupMenuItem<String>(value: 'history', child: Text('Historique')),
                PopupMenuItem<String>(value: 'archive', child: Text('Archiver')),
              ],
            ),
          ),
        ));
      }
    }
    return widgets;
  }

  String _priceExtra(Map<String, dynamic> p) {
    final extra = <String>[];
    final region = p['region']?.toString() ?? '';
    final supplier = p['supplier']?.toString() ?? '';
    if (region.isNotEmpty) extra.add(region);
    if (supplier.isNotEmpty) extra.add(supplier);
    return extra.isEmpty ? '' : ' • ${extra.join(' • ')}';
  }

  Future<void> _addPrice() async {
    String kind = 'material';
    final code = TextEditingController();
    final designation = TextEditingController();
    final unit = TextEditingController();
    final price = TextEditingController();
    final region = TextEditingController();
    final supplier = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Nouveau prix'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String>(
                value: kind,
                decoration: const InputDecoration(labelText: 'Catégorie'),
                items: _kindLabels.entries
                    .map((e) => DropdownMenuItem<String>(value: e.key, child: Text(e.value)))
                    .toList(),
                onChanged: (v) => setD(() => kind = v ?? kind),
              ),
              TextField(controller: code, decoration: const InputDecoration(labelText: 'Code')),
              TextField(controller: designation, decoration: const InputDecoration(labelText: 'Désignation *')),
              TextField(controller: unit, decoration: const InputDecoration(labelText: 'Unité * (sac, m³, jour, h…)')),
              TextField(
                controller: price,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: 'Prix unitaire * (${widget.currency})'),
              ),
              TextField(controller: region, decoration: const InputDecoration(labelText: 'Région')),
              TextField(controller: supplier, decoration: const InputDecoration(labelText: 'Fournisseur')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () => Navigator.pop(c, designation.text.trim().isNotEmpty && unit.text.trim().isNotEmpty),
              child: const Text('Ajouter'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await _run(() => _service.addPrice(widget.organizationId, {
          'kind': kind,
          'code': code.text.trim().isEmpty ? null : code.text.trim(),
          'designation': designation.text.trim(),
          'unit': unit.text.trim(),
          'unit_price': parseNumber(price.text),
          'currency': widget.currency,
          'region': region.text.trim().isEmpty ? null : region.text.trim(),
          'supplier': supplier.text.trim().isEmpty ? null : supplier.text.trim(),
        }));
  }

  Future<void> _editPrice(Map<String, dynamic> p) async {
    final value = await _askNumber(
      'Modifier le prix',
      'Nouveau prix unitaire (${widget.currency})',
      initial: (p['unit_price'] ?? '').toString(),
    );
    if (value == null) return;
    await _run(() => _service.updatePrice(p['id'] as String, value), ok: 'Prix mis à jour (historique conservé)');
  }

  Future<void> _showPriceHistory(Map<String, dynamic> p) async {
    List<Map<String, dynamic>> rows;
    try {
      rows = await _service.listPriceHistory(p['id'] as String);
    } catch (e) {
      _snack(_clean(e));
      return;
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Historique : ${p['designation']}'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: rows
                .map((r) => ListTile(
                      dense: true,
                      title: Text(_money(r['unit_price'] as num?)),
                      subtitle: Text(r['effective_date'].toString()),
                    ))
                .toList(),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Fermer'))],
      ),
    );
  }
}
