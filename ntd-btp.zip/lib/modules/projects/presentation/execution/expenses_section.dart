import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/utils/format.dart';
import '../../data/execution_service.dart';
import '../../data/study_service.dart';
import 'common.dart';

const Map<String, String> _methodLabels = {
  'cash': 'Espèces',
  'transfer': 'Virement',
  'mobile_money': 'Mobile money',
  'cheque': 'Chèque',
  'card': 'Carte',
  'other': 'Autre',
};

const Map<String, String> _payLabels = {
  'committed': 'Engagée',
  'partial': 'Partiellement payée',
  'paid': 'Payée',
};

/// Dépenses réelles : engagées, payées et reste à payer, avec justificatif.
class ExpensesSection extends StatefulWidget {
  const ExpensesSection({super.key, required this.projectId, this.currency = 'XAF'});

  final String projectId;
  final String currency;

  @override
  State<ExpensesSection> createState() => _ExpensesSectionState();
}

class _ExpensesSectionState extends State<ExpensesSection> {
  final _service = ExecutionService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _expenses = [];
  List<Map<String, dynamic>> _lots = [];
  List<Map<String, dynamic>> _trades = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  String _money(num? v) => '${formatAmount(v)} ${widget.currency}';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _expenses = await _service.listExpenses(widget.projectId);
      _lots = await StudyService.instance.listLots(widget.projectId);
      _trades = await _service.listTrades();
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _guard(Future<void> Function() action, {String? ok}) async {
    try {
      await action();
      if (ok != null && mounted) showSnack(context, ok);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _edit({Map<String, dynamic>? existing}) async {
    DateTime date = existing == null ? DateTime.now() : (DateTime.tryParse(existing['expense_date'].toString()) ?? DateTime.now());
    String? lot = existing?['work_package_id'] as String?;
    String? trade = existing?['trade_id'] as String?;
    String method = (existing?['payment_method'] as String?) ?? 'cash';
    String? receipt = existing?['receipt_path'] as String?;
    bool uploading = false;
    final designation = TextEditingController(text: existing?['designation']?.toString() ?? '');
    final qty = TextEditingController(text: existing == null ? '1' : formatQuantity(existing['quantity'] as num?));
    final price = TextEditingController(text: existing == null ? '' : (existing['unit_price'] ?? '').toString());
    final supplier = TextEditingController(text: existing?['supplier']?.toString() ?? '');
    final paid = TextEditingController(text: existing == null ? '0' : (existing['paid_amount'] ?? 0).toString());
    const numberKeyboard = TextInputType.numberWithOptions(decimal: true);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) {
          final amount = parseNumber(qty.text) * parseNumber(price.text);
          return AlertDialog(
            title: Text(existing == null ? 'Nouvelle dépense' : 'Modifier la dépense'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.event),
                  title: Text('Date : ${displayDate(isoDate(date))}'),
                  onTap: () async {
                    final picked = await pickDate(c, date);
                    if (picked != null) setD(() => date = picked);
                  },
                ),
                DropdownButtonFormField<String?>(
                  value: lot,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Lot'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Sans lot')),
                    ..._lots.map((l) => DropdownMenuItem<String?>(
                          value: l['id'] as String,
                          child: Text('${l['code'] ?? ''} ${l['name']}'.trim(), overflow: TextOverflow.ellipsis),
                        )),
                  ],
                  onChanged: (v) => setD(() => lot = v),
                ),
                DropdownButtonFormField<String?>(
                  value: trade,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Corps de métier'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Selon le lot')),
                    ..._trades.map((t) => DropdownMenuItem<String?>(
                          value: t['id'] as String,
                          child: Text(t['name'].toString(), overflow: TextOverflow.ellipsis),
                        )),
                  ],
                  onChanged: (v) => setD(() => trade = v),
                ),
                TextField(controller: designation, decoration: const InputDecoration(labelText: 'Désignation *')),
                Row(children: [
                  Expanded(child: TextField(controller: qty, keyboardType: numberKeyboard, onChanged: (_) => setD(() {}), decoration: const InputDecoration(labelText: 'Quantité'))),
                  const SizedBox(width: 8),
                  Expanded(child: TextField(controller: price, keyboardType: numberKeyboard, onChanged: (_) => setD(() {}), decoration: InputDecoration(labelText: 'Prix unitaire (${widget.currency})'))),
                ]),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Montant : ${_money(amount)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                TextField(controller: supplier, decoration: const InputDecoration(labelText: 'Fournisseur ou bénéficiaire')),
                DropdownButtonFormField<String>(
                  value: method,
                  decoration: const InputDecoration(labelText: 'Mode de paiement'),
                  items: _methodLabels.entries.map((e) => DropdownMenuItem<String>(value: e.key, child: Text(e.value))).toList(),
                  onChanged: (v) => setD(() => method = v ?? method),
                ),
                TextField(controller: paid, keyboardType: numberKeyboard, decoration: InputDecoration(labelText: 'Déjà payé (${widget.currency})')),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: uploading
                        ? null
                        : () async {
                            final source = await showModalBottomSheet<ImageSource>(
                              context: c,
                              builder: (s) => SafeArea(
                                child: Column(mainAxisSize: MainAxisSize.min, children: [
                                  ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Prendre une photo'), onTap: () => Navigator.pop(s, ImageSource.camera)),
                                  ListTile(leading: const Icon(Icons.photo_library), title: const Text('Choisir dans la galerie'), onTap: () => Navigator.pop(s, ImageSource.gallery)),
                                ]),
                              ),
                            );
                            if (source == null) return;
                            setD(() => uploading = true);
                            try {
                              final file = await ImagePicker().pickImage(source: source, maxWidth: 1600, imageQuality: 80);
                              if (file != null) {
                                final bytes = await file.readAsBytes();
                                final path = await _service.uploadFile(widget.projectId, 'receipts', bytes);
                                setD(() => receipt = path);
                              }
                            } catch (e) {
                              if (mounted) showSnack(context, cleanError(e));
                            }
                            setD(() => uploading = false);
                          },
                    icon: Icon(receipt == null ? Icons.attach_file : Icons.check_circle_outline),
                    label: Text(uploading ? 'Envoi en cours…' : (receipt == null ? 'Joindre un justificatif' : 'Justificatif joint (changer)')),
                  ),
                ),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
              FilledButton(onPressed: () => Navigator.pop(c, designation.text.trim().isNotEmpty), child: const Text('Enregistrer')),
            ],
          );
        },
      ),
    );
    if (ok != true) return;
    final total = parseNumber(qty.text) * parseNumber(price.text);
    var paidAmount = parseNumber(paid.text);
    if (paidAmount > total) paidAmount = total;
    final values = <String, dynamic>{
      'expense_date': isoDate(date),
      'work_package_id': lot,
      'trade_id': trade,
      'designation': designation.text.trim(),
      'quantity': parseNumber(qty.text),
      'unit_price': parseNumber(price.text),
      'supplier': supplier.text.trim().isEmpty ? null : supplier.text.trim(),
      'payment_method': method,
      'paid_amount': paidAmount,
      'receipt_path': receipt,
    };
    if (existing == null) {
      await _guard(() => _service.addExpense(widget.projectId, values), ok: 'Dépense enregistrée');
    } else {
      await _guard(() => _service.updateExpense(existing['id'] as String, values), ok: 'Dépense mise à jour');
    }
  }

  Future<void> _pay(Map<String, dynamic> e) async {
    final remaining = (e['remaining'] as num?)?.toDouble() ?? 0;
    final controller = TextEditingController(text: formatQuantity(remaining));
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Enregistrer un paiement'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: 'Montant payé (${widget.currency}) — reste ${formatAmount(remaining)}'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Valider')),
        ],
      ),
    );
    if (ok != true) return;
    var add = parseNumber(controller.text);
    if (add > remaining) add = remaining;
    if (add <= 0) return;
    final newPaid = ((e['paid_amount'] as num?)?.toDouble() ?? 0) + add;
    await _guard(() => _service.updateExpense(e['id'] as String, {'paid_amount': newPaid}), ok: 'Paiement enregistré');
  }

  Future<void> _showReceipt(String path) async {
    try {
      final url = await _service.signedUrl(path);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (c) => Dialog(
          child: InteractiveViewer(child: Image.network(url, errorBuilder: (_, __, ___) => const Padding(padding: EdgeInsets.all(24), child: Text('Justificatif illisible')))),
        ),
      );
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _expenses.isEmpty) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    var committed = 0.0, paid = 0.0, remaining = 0.0;
    for (final e in _expenses) {
      committed += (e['amount'] as num?)?.toDouble() ?? 0;
      paid += (e['paid_amount'] as num?)?.toDouble() ?? 0;
      remaining += (e['remaining'] as num?)?.toDouble() ?? 0;
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            Expanded(child: Text('Dépenses réelles (${_expenses.length})', style: Theme.of(context).textTheme.titleMedium)),
            FilledButton.tonalIcon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Nouvelle')),
          ]),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(children: [
                Row(children: [const Expanded(child: Text('Engagées')), Text(_money(committed))]),
                Row(children: [const Expanded(child: Text('Payées')), Text(_money(paid))]),
                Row(children: [const Expanded(child: Text('Reste à payer', style: TextStyle(fontWeight: FontWeight.bold))), Text(_money(remaining), style: const TextStyle(fontWeight: FontWeight.bold))]),
              ]),
            ),
          ),
          if (_expenses.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Aucune dépense enregistrée.')),
          ..._expenses.map((e) {
            final status = e['payment_status'].toString();
            final lot = (e['work_packages'] as Map?)?['name']?.toString();
            final receipt = e['receipt_path'] as String?;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 3),
              child: ListTile(
                title: Text(e['designation'].toString()),
                subtitle: Text(
                  '${displayDate(e['expense_date'])} • ${_money(e['amount'] as num?)} • ${_payLabels[status] ?? status}'
                  '${(e['supplier'] ?? '').toString().isEmpty ? '' : ' • ${e['supplier']}'}'
                  '${lot == null ? '' : ' • $lot'}',
                ),
                isThreeLine: true,
                leading: Icon(status == 'paid' ? Icons.check_circle : (status == 'partial' ? Icons.timelapse : Icons.pending_outlined)),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'edit') _edit(existing: e);
                    if (v == 'pay') _pay(e);
                    if (v == 'receipt' && receipt != null) _showReceipt(receipt);
                    if (v == 'delete') {
                      confirmDialog(context, 'Supprimer cette dépense ?', 'Cette action est définitive.').then((ok) {
                        if (ok == true) _guard(() => _service.deleteExpense(e['id'] as String));
                      });
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem<String>(value: 'edit', child: Text('Modifier')),
                    if (status != 'paid') const PopupMenuItem<String>(value: 'pay', child: Text('Enregistrer un paiement')),
                    if (receipt != null) const PopupMenuItem<String>(value: 'receipt', child: Text('Voir le justificatif')),
                    const PopupMenuItem<String>(value: 'delete', child: Text('Supprimer')),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
