import 'package:flutter/material.dart';
import '../../../../core/utils/format.dart';
import '../../data/execution_service.dart';
import '../../data/study_service.dart';
import 'common.dart';

const Map<String, String> _severityLabels = {
  'low': 'Mineur',
  'medium': 'Moyen',
  'high': 'Grave',
  'critical': 'Critique',
};

const Map<String, String> _statusLabels = {
  'open': 'Ouvert',
  'in_progress': 'En cours',
  'resolved': 'Résolu',
};

/// Gestion des incidents de chantier.
class IncidentsSection extends StatefulWidget {
  const IncidentsSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<IncidentsSection> createState() => _IncidentsSectionState();
}

class _IncidentsSectionState extends State<IncidentsSection> {
  final _service = ExecutionService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _incidents = [];
  List<Map<String, dynamic>> _lots = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _incidents = await _service.listIncidents(widget.projectId);
      _lots = await StudyService.instance.listLots(widget.projectId);
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _add() async {
    final title = TextEditingController();
    final description = TextEditingController();
    String severity = 'medium';
    String? lot;
    DateTime date = DateTime.now();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Nouvel incident'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: title, decoration: const InputDecoration(labelText: 'Titre *')),
              TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'Description')),
              DropdownButtonFormField<String>(
                value: severity,
                decoration: const InputDecoration(labelText: 'Gravité'),
                items: _severityLabels.entries.map((e) => DropdownMenuItem<String>(value: e.key, child: Text(e.value))).toList(),
                onChanged: (v) => setD(() => severity = v ?? severity),
              ),
              DropdownButtonFormField<String?>(
                value: lot,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Lot concerné'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Aucun')),
                  ..._lots.map((l) => DropdownMenuItem<String?>(
                        value: l['id'] as String,
                        child: Text('${l['code'] ?? ''} ${l['name']}'.trim(), overflow: TextOverflow.ellipsis),
                      )),
                ],
                onChanged: (v) => setD(() => lot = v),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event),
                title: Text('Date : ${displayDate(isoDate(date))}'),
                onTap: () async {
                  final picked = await pickDate(c, date);
                  if (picked != null) setD(() => date = picked);
                },
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(c, title.text.trim().isNotEmpty), child: const Text('Déclarer')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await _guard(() => _service.addIncident(widget.projectId, {
          'title': title.text.trim(),
          'description': description.text.trim().isEmpty ? null : description.text.trim(),
          'severity': severity,
          'work_package_id': lot,
          'incident_date': isoDate(date),
        }));
  }

  Future<void> _guard(Future<void> Function() action) async {
    try {
      await action();
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _incidents.isEmpty) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final open = _incidents.where((i) => i['status'] != 'resolved').length;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            Expanded(child: Text('Incidents ($open ouvert(s) sur ${_incidents.length})', style: Theme.of(context).textTheme.titleMedium)),
            FilledButton.tonalIcon(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Déclarer')),
          ]),
          if (_incidents.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Aucun incident déclaré.')),
          ..._incidents.map((i) {
            final severity = i['severity'].toString();
            final status = i['status'].toString();
            final lot = (i['work_packages'] as Map?)?['name']?.toString();
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 3),
              child: ListTile(
                leading: Icon(Icons.report_problem_outlined, color: severityColor(context, severity)),
                title: Text(i['title'].toString()),
                subtitle: Text(
                  '${displayDate(i['incident_date'])} • ${_severityLabels[severity] ?? severity} • ${_statusLabels[status] ?? status}'
                  '${lot == null ? '' : ' • $lot'}'
                  '${(i['description'] ?? '').toString().isEmpty ? '' : '\n${i['description']}'}',
                ),
                isThreeLine: (i['description'] ?? '').toString().isNotEmpty,
                trailing: PopupMenuButton<String>(
                  onSelected: (v) => _guard(() => _service.setIncidentStatus(i['id'] as String, v)),
                  itemBuilder: (_) => _statusLabels.entries
                      .where((e) => e.key != status)
                      .map((e) => PopupMenuItem<String>(value: e.key, child: Text('Passer à : ${e.value}')))
                      .toList(),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
