import 'package:flutter/material.dart';
import '../../../../core/utils/format.dart';
import '../../data/execution_service.dart';
import 'common.dart';

/// Écarts budgétaires, avancement physique/financier et alertes automatiques.
class VarianceSection extends StatefulWidget {
  const VarianceSection({super.key, required this.projectId, this.currency = 'XAF'});

  final String projectId;
  final String currency;

  @override
  State<VarianceSection> createState() => _VarianceSectionState();
}

class _VarianceSectionState extends State<VarianceSection> {
  final _service = ExecutionService.instance;
  bool _loading = true;
  String? _error;
  String? _financeError;
  Map<String, dynamic>? _variance;
  List<Map<String, dynamic>> _alerts = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
      _financeError = null;
    });
    try {
      await _service.refreshAlerts(widget.projectId);
      _alerts = await _service.listAlerts(widget.projectId);
      _alerts.sort((a, b) => _rank(a['severity']).compareTo(_rank(b['severity'])));
    } catch (e) {
      _error = cleanError(e);
    }
    try {
      _variance = await _service.getVariance(widget.projectId);
    } catch (e) {
      _variance = null;
      _financeError = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  int _rank(dynamic severity) {
    switch (severity) {
      case 'critical':
        return 0;
      case 'warning':
        return 1;
      default:
        return 2;
    }
  }

  String _money(dynamic value) => '${formatAmount(value as num?)} ${widget.currency}';

  String _pct(dynamic value) => value == null ? '—' : '${formatQuantity(value as num?)} %';

  @override
  Widget build(BuildContext context) {
    if (_loading && _variance == null && _alerts.isEmpty) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final v = _variance;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Alertes (${_alerts.length})', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          if (_alerts.isEmpty)
            const Card(
              child: ListTile(
                leading: Icon(Icons.check_circle_outline),
                title: Text('Aucune alerte active'),
                subtitle: Text('Les alertes se calculent automatiquement à chaque dépense, quantité ou incident.'),
              ),
            ),
          ..._alerts.map((a) {
            final severity = a['severity'].toString();
            final color = severityColor(context, severity);
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 3),
              child: ListTile(
                leading: Icon(severity == 'critical' ? Icons.error : (severity == 'warning' ? Icons.warning_amber : Icons.info_outline), color: color),
                title: Text(a['title'].toString()),
                subtitle: Text((a['message'] ?? '').toString()),
              ),
            );
          }),
          const SizedBox(height: 16),
          if (v == null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.lock_outline),
                title: const Text('Données financières non accessibles'),
                subtitle: Text(_financeError ?? ''),
              ),
            )
          else
            ..._financeWidgets(v),
        ],
      ),
    );
  }

  List<Widget> _financeWidgets(Map<String, dynamic> v) {
    final theme = Theme.of(context);
    final physical = (v['physical_pct'] as num?)?.toDouble() ?? 0;
    final financial = (v['consumption_pct'] as num?)?.toDouble();
    final gap = financial == null ? null : financial - physical;
    final source = v['physical_source'] == 'quantities' ? 'quantités validées' : 'avancement des tâches';
    final lots = List<Map<String, dynamic>>.from(v['lots'] as List);
    final trades = List<Map<String, dynamic>>.from(v['trades'] as List);
    return [
      Text('Synthèse financière', style: theme.textTheme.titleMedium),
      const SizedBox(height: 4),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(children: [
            _row('Budget initial', _money(v['budget_initial'])),
            _row('Budget révisé', _money(v['budget'])),
            _row('Dépenses engagées', _money(v['committed'])),
            _row('Dépenses payées', _money(v['paid'])),
            _row('Reste à payer', _money(v['remaining_to_pay'])),
            _row('Solde budgétaire', _money(v['balance']), bold: true),
            _row('Consommation du budget', _pct(v['consumption_pct'])),
            _row('Coût final prévisionnel', v['forecast_final_cost'] == null ? 'Données insuffisantes' : _money(v['forecast_final_cost'])),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      Text('Avancement physique et financier', style: theme.textTheme.titleMedium),
      const SizedBox(height: 4),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Physique ($source) : ${_pct(v['physical_pct'])}'),
            const SizedBox(height: 4),
            LinearProgressIndicator(value: (physical / 100).clamp(0.0, 1.0).toDouble()),
            const SizedBox(height: 12),
            Text('Financier : ${_pct(v['consumption_pct'])}'),
            const SizedBox(height: 4),
            LinearProgressIndicator(value: financial == null ? 0 : (financial / 100).clamp(0.0, 1.0).toDouble()),
            if (gap != null) ...[
              const SizedBox(height: 8),
              Text(
                gap > 15
                    ? 'Attention : les dépenses avancent plus vite que les travaux.'
                    : (gap < -15 ? 'Les travaux avancent plus vite que les dépenses enregistrées.' : 'Avancement financier cohérent avec le physique.'),
                style: theme.textTheme.bodySmall,
              ),
            ],
          ]),
        ),
      ),
      const SizedBox(height: 12),
      Text('Écarts par lot', style: theme.textTheme.titleMedium),
      if (lots.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aucun lot.')),
      ...lots.map(_varianceTile),
      const SizedBox(height: 12),
      Text('Écarts par corps de métier', style: theme.textTheme.titleMedium),
      if (trades.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aucune donnée.')),
      ...trades.map(_varianceTile),
    ];
  }

  Widget _row(String label, String value, {bool bold = false}) {
    final style = bold ? const TextStyle(fontWeight: FontWeight.bold) : null;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Expanded(child: Text(label, style: style)),
        Text(value, style: style),
      ]),
    );
  }

  Widget _varianceTile(Map<String, dynamic> x) {
    final consumption = (x['consumption_pct'] as num?)?.toDouble();
    final color = consumption == null
        ? Theme.of(context).colorScheme.outline
        : (consumption > 100 ? severityColor(context, 'critical') : (consumption >= 90 ? severityColor(context, 'warning') : Theme.of(context).colorScheme.primary));
    final physical = x['physical_pct'] as num?;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 3),
      child: ListTile(
        dense: true,
        title: Text(x['name'].toString()),
        subtitle: Text(
          'Budget ${formatAmount(x['budget'] as num?)} • Engagé ${formatAmount(x['committed'] as num?)} • Solde ${formatAmount(x['balance'] as num?)}'
          '${physical == null ? '' : ' • Physique ${formatQuantity(physical)} %'}',
        ),
        trailing: Text(
          consumption == null ? '—' : '${formatQuantity(consumption)} %',
          style: TextStyle(color: color, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
