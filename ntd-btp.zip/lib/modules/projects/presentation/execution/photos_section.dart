import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/utils/format.dart';
import '../../data/execution_service.dart';
import '../../data/study_service.dart';
import 'common.dart';

const Map<String, String> _categoryLabels = {
  'before': 'Avant',
  'during': 'Pendant',
  'after': 'Après',
  'anomaly': 'Anomalie',
};

/// Photos de chantier classées par catégorie, lot et date, avec comparaison avant/après.
class PhotosSection extends StatefulWidget {
  const PhotosSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<PhotosSection> createState() => _PhotosSectionState();
}

class _PhotosSectionState extends State<PhotosSection> {
  final _service = ExecutionService.instance;
  bool _loading = true;
  bool _uploading = false;
  String? _error;
  String _filter = 'all';
  List<Map<String, dynamic>> _photos = [];
  List<Map<String, dynamic>> _lots = [];
  final Map<String, String> _urls = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _photos = await _service.listPhotos(widget.projectId);
      _lots = await StudyService.instance.listLots(widget.projectId);
      for (final p in _photos) {
        final path = p['storage_path'] as String;
        if (_urls.containsKey(path)) continue;
        try {
          _urls[path] = await _service.signedUrl(path);
        } catch (_) {
          // la photo restera sans aperçu
        }
      }
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _add(ImageSource source) async {
    try {
      final file = await ImagePicker().pickImage(source: source, maxWidth: 1800, imageQuality: 80);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      if (!mounted) return;
      String category = 'during';
      String? lot;
      final caption = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => StatefulBuilder(
          builder: (c, setD) => AlertDialog(
            title: const Text('Nouvelle photo'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.memory(bytes, height: 140, fit: BoxFit.cover),
                ),
                DropdownButtonFormField<String>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Catégorie'),
                  items: _categoryLabels.entries.map((e) => DropdownMenuItem<String>(value: e.key, child: Text(e.value))).toList(),
                  onChanged: (v) => setD(() => category = v ?? category),
                ),
                DropdownButtonFormField<String?>(
                  value: lot,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Lot'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Sans lot')),
                    ..._lots.map((l) => DropdownMenuItem<String?>(
                          value: l['id'] as String,
                          child: Text('${l['code'] ?? ''} ${l['name']}'.trim(), overflow: TextOverflow.ellipsis),
                        )),
                  ],
                  onChanged: (v) => setD(() => lot = v),
                ),
                TextField(controller: caption, decoration: const InputDecoration(labelText: 'Description')),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
              FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Enregistrer')),
            ],
          ),
        ),
      );
      if (ok != true) return;
      setState(() => _uploading = true);
      final path = await _service.uploadFile(widget.projectId, 'photos', bytes);
      await _service.addPhoto(widget.projectId, path, category, caption.text.trim().isEmpty ? null : caption.text.trim(), lot);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
    if (mounted) setState(() => _uploading = false);
  }

  Future<void> _open(Map<String, dynamic> p) async {
    final url = _urls[p['storage_path']];
    final lot = (p['work_packages'] as Map?)?['name']?.toString();
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        contentPadding: const EdgeInsets.all(8),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (url != null)
              InteractiveViewer(child: Image.network(url, errorBuilder: (_, __, ___) => const Text('Image illisible')))
            else
              const Padding(padding: EdgeInsets.all(24), child: Text('Aperçu indisponible')),
            const SizedBox(height: 8),
            Text('${_categoryLabels[p['category']] ?? ''} • ${displayDate(p['taken_at'].toString().substring(0, 10))}${lot == null ? '' : ' • $lot'}'),
            if ((p['caption'] ?? '').toString().isNotEmpty) Text(p['caption'].toString()),
          ]),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(c);
              final ok = await confirmDialog(context, 'Supprimer cette photo ?', 'Cette action est définitive.');
              if (ok != true) return;
              try {
                await _service.deletePhoto(p['id'] as String, p['storage_path'] as String);
                await _load();
              } catch (e) {
                if (mounted) showSnack(context, cleanError(e));
              }
            },
            child: const Text('Supprimer'),
          ),
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Fermer')),
        ],
      ),
    );
  }

  String _label(Map<String, dynamic> p) {
    final caption = (p['caption'] ?? '').toString();
    final date = displayDate(p['taken_at'].toString().substring(0, 10));
    return '${_categoryLabels[p['category']] ?? ''} • $date${caption.isEmpty ? '' : ' • $caption'}';
  }

  Future<void> _compare() async {
    if (_photos.length < 2) {
      showSnack(context, 'Ajoutez au moins deux photos pour comparer.');
      return;
    }
    final befores = _photos.where((p) => p['category'] == 'before').toList();
    final afters = _photos.where((p) => p['category'] == 'after').toList();
    String? first = befores.isNotEmpty ? befores.first['id'] as String : _photos.first['id'] as String;
    String? second = afters.isNotEmpty ? afters.first['id'] as String : _photos[1]['id'] as String;
    Map<String, dynamic>? byId(String? id) {
      for (final p in _photos) {
        if (p['id'] == id) return p;
      }
      return null;
    }

    await showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) {
          final a = byId(first);
          final b = byId(second);
          Widget preview(Map<String, dynamic>? p) {
            final url = p == null ? null : _urls[p['storage_path']];
            if (url == null) return const SizedBox(height: 120, child: Center(child: Text('—')));
            return Image.network(url, height: 160, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox(height: 120, child: Center(child: Text('Illisible'))));
          }

          return AlertDialog(
            title: const Text('Comparaison avant / après'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                DropdownButtonFormField<String>(
                  value: first,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Photo 1 (avant)'),
                  items: _photos.map((p) => DropdownMenuItem<String>(value: p['id'] as String, child: Text(_label(p), overflow: TextOverflow.ellipsis))).toList(),
                  onChanged: (v) => setD(() => first = v),
                ),
                preview(a),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: second,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Photo 2 (après)'),
                  items: _photos.map((p) => DropdownMenuItem<String>(value: p['id'] as String, child: Text(_label(p), overflow: TextOverflow.ellipsis))).toList(),
                  onChanged: (v) => setD(() => second = v),
                ),
                preview(b),
              ]),
            ),
            actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Fermer'))],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _photos.isEmpty) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    final shown = _filter == 'all' ? _photos : _photos.where((p) => p['category'] == _filter).toList();
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(spacing: 8, runSpacing: 4, children: [
            FilledButton.icon(
              onPressed: _uploading ? null : () => _add(ImageSource.camera),
              icon: const Icon(Icons.photo_camera),
              label: const Text('Prendre une photo'),
            ),
            OutlinedButton.icon(
              onPressed: _uploading ? null : () => _add(ImageSource.gallery),
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('Galerie'),
            ),
            OutlinedButton.icon(onPressed: _compare, icon: const Icon(Icons.compare), label: const Text('Avant / après')),
          ]),
          if (_uploading) const Padding(padding: EdgeInsets.only(top: 8), child: LinearProgressIndicator()),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            ChoiceChip(label: const Text('Toutes'), selected: _filter == 'all', onSelected: (_) => setState(() => _filter = 'all')),
            ..._categoryLabels.entries.map((e) => ChoiceChip(
                  label: Text(e.value),
                  selected: _filter == e.key,
                  onSelected: (_) => setState(() => _filter = e.key),
                )),
          ]),
          const SizedBox(height: 8),
          if (shown.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Aucune photo.')),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            children: shown.map((p) {
              final url = _urls[p['storage_path']];
              return InkWell(
                onTap: () => _open(p),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Stack(fit: StackFit.expand, children: [
                    if (url != null)
                      Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined)))
                    else
                      const Center(child: Icon(Icons.image_not_supported_outlined)),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        color: Colors.black54,
                        padding: const EdgeInsets.all(4),
                        child: Text(_label(p), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 11)),
                      ),
                    ),
                  ]),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
