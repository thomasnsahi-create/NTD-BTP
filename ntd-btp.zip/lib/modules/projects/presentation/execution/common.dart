import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Message d'erreur lisible (sans le préfixe technique de l'exception).
String cleanError(Object e) => e is PostgrestException ? e.message : e.toString();

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

Future<bool?> confirmDialog(BuildContext context, String title, String message) {
  return showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Confirmer')),
      ],
    ),
  );
}

Future<DateTime?> pickDate(BuildContext context, DateTime initial) {
  return showDatePicker(
    context: context,
    initialDate: initial,
    firstDate: DateTime(2000),
    lastDate: DateTime(2100),
  );
}

/// Message centré avec bouton « Réessayer ».
Widget errorView(String message, VoidCallback retry) {
  return Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(message),
        const SizedBox(height: 12),
        FilledButton(onPressed: retry, child: const Text('Réessayer')),
      ]),
    ),
  );
}

/// Couleur associée à la gravité d'une alerte ou d'un incident.
Color severityColor(BuildContext context, String severity) {
  switch (severity) {
    case 'critical':
      return Theme.of(context).colorScheme.error;
    case 'high':
      return Colors.deepOrange.shade700;
    case 'warning':
    case 'medium':
      return Colors.orange.shade800;
    default:
      return Theme.of(context).colorScheme.primary;
  }
}
