import 'package:flutter/material.dart';
import '../../../../core/utils/format.dart';
import '../../data/execution_service.dart';
import 'common.dart';

const List<String> _weatherOptions = ['Ensoleillé', 'Nuageux', 'Pluie légère', 'Forte pluie', 'Orage', 'Vent fort'];

/// Journal de chantier quotidien.
class DiarySection extends StatefulWidget {
  const DiarySection({super.key, required this.projectId});

  final String projectId;

  @override
  State<DiarySection> createState() => _DiarySectionState();
}

class _DiarySectionState extends State<DiarySection> {
  final _service = ExecutionService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _diaries = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _diaries = await _service.listDiaries(widget.projectId);
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _edit({Map<String, dynamic>? existing}) async {
    DateTime date = existing == null ? DateTime.now() : (DateTime.tryParse(existing['diary_date'].toString()) ?? DateTime.now());
    String? weather = existing?['weather'] as String?;
    if (weather != null && !_weatherOptions.contains(weather)) weather = null;
    String textOf(String key) => existing?[key]?.toString() ?? '';
    final workforce = TextEditingController(text: textOf('workforce_count'));
    final trades = TextEditingController(text: textOf('trades_mobilized'));
    final teams = TextEditingController(text: textOf('teams'));
    final equipment = TextEditingController(text: textOf('equipment'));
    final work = TextEditingController(text: textOf('work_done'));
    final materials = TextEditingController(text: textOf('materials_used'));
    final incidents = TextEditingController(text: textOf('incidents_note'));
    final delays = TextEditingController(text: textOf('delays_note'));
    final observations = TextEditingController(text: textOf('observations'));
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(existing == null ? 'Journal de chantier' : 'Modifier le journal'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event),
                title: Text('Date : ${displayDate(isoDate(date))}'),
                onTap: existing != null
                    ? null
                    : () async {
                        final picked = await pickDate(c, date);
                        if (picked != null) setD(() => date = picked);
                      },
              ),
              DropdownButtonFormField<String?>(
                value: weather,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Conditions météorologiques'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Non renseignées')),
                  ..._weatherOptions.map((w) => DropdownMenuItem<String?>(value: w, child: Text(w))),
                ],
                onChanged: (v) => setD(() => weather = v),
              ),
              TextField(controller: workforce, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Effectif présent')),
              TextField(controller: trades, decoration: const InputDecoration(labelText: 'Corps de métier mobilisés')),
              TextField(controller: teams, decoration: const InputDecoration(labelText: 'Équipes')),
              TextField(controller: equipment, decoration: const InputDecoration(labelText: 'Engins')),
              TextField(controller: work, maxLines: 3, decoration: const InputDecoration(labelText: 'Travaux réalisés')),
              TextField(controller: materials, maxLines: 2, decoration: const InputDecoration(labelText: 'Matériaux consommés')),
              TextField(controller: incidents, maxLines: 2, decoration: const InputDecoration(labelText: 'Incidents')),
              TextField(controller: delays, maxLines: 2, decoration: const InputDecoration(labelText: 'Retards')),
              TextField(controller: observations, maxLines: 2, decoration: const InputDecoration(labelText: 'Observations')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Enregistrer')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    String? clean(TextEditingController t) => t.text.trim().isEmpty ? null : t.text.trim();
    try {
      await _service.saveDiary(widget.projectId, isoDate(date), {
        'weather': weather,
        'workforce_count': int.tryParse(workforce.text.trim()),
        'trades_mobilized': clean(trades),
        'teams': clean(teams),
        'equipment': clean(equipment),
        'work_done': clean(work),
        'materials_used': clean(materials),
        'incidents_note': clean(incidents),
        'delays_note': clean(delays),
        'observations': clean(observations),
      });
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  Future<void> _delete(Map<String, dynamic> d) async {
    final ok = await confirmDialog(context, 'Supprimer ce journal ?', 'Le journal du ${displayDate(d['diary_date'])} sera supprimé.');
    if (ok != true) return;
    try {
      await _service.deleteDiary(d['id'] as String);
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  List<Widget> _details(Map<String, dynamic> d) {
    const labels = <String, String>{
      'trades_mobilized': 'Corps de métier',
      'teams': 'Équipes',
      'equipment': 'Engins',
      'work_done': 'Travaux réalisés',
      'materials_used': 'Matériaux consommés',
      'incidents_note': 'Incidents',
      'delays_note': 'Retards',
      'observations': 'Observations',
    };
    final widgets = <Widget>[];
    labels.forEach((key, label) {
      final value = d[key]?.toString() ?? '';
      if (value.isEmpty) return;
      widgets.add(Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text.rich(TextSpan(children: [
            TextSpan(text: '$label : ', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: value),
          ])),
        ),
      ));
    });
    widgets.add(Row(mainAxisAlignment: MainAxisAlignment.end, children: [
      TextButton.icon(onPressed: () => _edit(existing: d), icon: const Icon(Icons.edit_outlined), label: const Text('Modifier')),
      TextButton.icon(onPressed: () => _delete(d), icon: const Icon(Icons.delete_outline), label: const Text('Supprimer')),
    ]));
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _diaries.isEmpty) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            Expanded(child: Text('Journal de chantier (${_diaries.length})', style: Theme.of(context).textTheme.titleMedium)),
            FilledButton.tonalIcon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Nouveau')),
          ]),
          if (_diaries.isEmpty)
            const Padding(padding: EdgeInsets.all(16), child: Text('Aucun journal. Rédigez le journal du jour : météo, effectif, travaux, incidents.')),
          ..._diaries.map((d) {
            final workforce = d['workforce_count'];
            final parts = <String>[
              if ((d['weather'] ?? '').toString().isNotEmpty) d['weather'].toString(),
              if (workforce != null) '$workforce personne(s)',
            ];
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 3),
              child: ExpansionTile(
                key: PageStorageKey<String>('diary-${d['id']}'),
                title: Text(displayDate(d['diary_date'])),
                subtitle: Text(
                  parts.isEmpty ? (d['work_done'] ?? '').toString() : parts.join(' • '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                children: _details(d),
              ),
            );
          }),
        ],
      ),
    );
  }
}
