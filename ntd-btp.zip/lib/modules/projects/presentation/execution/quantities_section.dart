import 'package:flutter/material.dart';
import '../../../../core/utils/format.dart';
import '../../data/execution_service.dart';
import 'common.dart';

/// Quantités exécutées par ligne du budget initial : déclaration puis validation.
class QuantitiesSection extends StatefulWidget {
  const QuantitiesSection({super.key, required this.projectId});

  final String projectId;

  @override
  State<QuantitiesSection> createState() => _QuantitiesSectionState();
}

class _QuantitiesSectionState extends State<QuantitiesSection> {
  final _service = ExecutionService.instance;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _lines = [];
  List<Map<String, dynamic>> _records = [];

  static const Map<String, String> _statusLabels = {
    'declared': 'À valider',
    'validated': 'Validée',
    'rejected': 'Refusée',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _lines = await _service.listBaselineLines(widget.projectId);
      _records = await _service.listProgressRecords(widget.projectId);
    } catch (e) {
      _error = cleanError(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  double _validated(String lineId) {
    var sum = 0.0;
    for (final r in _records) {
      if (r['budget_line_id'] == lineId && r['status'] == 'validated') {
        sum += (r['quantity'] as num).toDouble();
      }
    }
    return sum;
  }

  double _declared(String lineId) {
    var sum = 0.0;
    for (final r in _records) {
      if (r['budget_line_id'] == lineId && r['status'] == 'declared') {
        sum += (r['quantity'] as num).toDouble();
      }
    }
    return sum;
  }

  Future<void> _declare(Map<String, dynamic> line) async {
    final qty = TextEditingController();
    final notes = TextEditingController();
    DateTime date = DateTime.now();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('Déclarer une quantité exécutée'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(line['designation'].toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextField(
                controller: qty,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: 'Quantité exécutée (${line['unit']})'),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event),
                title: Text('Date : ${displayDate(isoDate(date))}'),
                onTap: () async {
                  final picked = await pickDate(c, date);
                  if (picked != null) setD(() => date = picked);
                },
              ),
              TextField(controller: notes, decoration: const InputDecoration(labelText: 'Observation')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(c, parseNumber(qty.text) > 0), child: const Text('Déclarer')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await _guard(() => _service.addProgressRecord(
          widget.projectId,
          line['id'] as String,
          parseNumber(qty.text),
          isoDate(date),
          notes.text.trim().isEmpty ? null : notes.text.trim(),
        ));
  }

  Future<void> _guard(Future<void> Function() action) async {
    try {
      await action();
      await _load();
    } catch (e) {
      if (mounted) showSnack(context, cleanError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _lines.isEmpty) return const Center(child: CircularProgressIndicator());
    if (_error != null) return errorView(_error!, _load);
    if (_lines.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Aucune ligne de budget initial.\nValidez d’abord le devis estimatif (onglet Étude) : les quantités prévues serviront de référence.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    final pending = _records.where((r) => r['status'] == 'declared').toList();
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (pending.isNotEmpty) ...[
            Text('Déclarations à valider (${pending.length})', style: Theme.of(context).textTheme.titleMedium),
            ...pending.map((r) {
              final line = r['project_budget_lines'] as Map?;
              return Card(
                margin: const EdgeInsets.symmetric(vertical: 3),
                child: ListTile(
                  dense: true,
                  title: Text('${line?['designation'] ?? 'Ligne'}'),
                  subtitle: Text('${formatQuantity(r['quantity'] as num?)} ${line?['unit'] ?? ''} • ${displayDate(r['record_date'])}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                      tooltip: 'Valider',
                      icon: const Icon(Icons.check_circle_outline),
                      onPressed: () => _guard(() => _service.reviewProgress(r['id'] as String, true)),
                    ),
                    IconButton(
                      tooltip: 'Refuser',
                      icon: const Icon(Icons.cancel_outlined),
                      onPressed: () => _guard(() => _service.reviewProgress(r['id'] as String, false)),
                    ),
                  ]),
                ),
              );
            }),
            const SizedBox(height: 12),
          ],
          Text('Avancement par ligne du budget initial', style: Theme.of(context).textTheme.titleMedium),
          const Text('Avancement (%) = quantité validée ÷ quantité prévue × 100', style: TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          ..._lines.map((l) {
            final id = l['id'] as String;
            final planned = (l['quantity'] as num).toDouble();
            final done = _validated(id);
            final waiting = _declared(id);
            final pct = planned > 0 ? done / planned * 100 : 0.0;
            final lot = (l['work_packages'] as Map?)?['name']?.toString();
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 3),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(l['designation'].toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
                  if (lot != null) Text('Lot : $lot', style: const TextStyle(fontSize: 12)),
                  const SizedBox(height: 4),
                  LinearProgressIndicator(value: (pct / 100).clamp(0.0, 1.0).toDouble()),
                  const SizedBox(height: 4),
                  Text(
                    'Validé ${formatQuantity(done)} / ${formatQuantity(planned)} ${l['unit']} (${formatQuantity(double.parse(pct.toStringAsFixed(1)))} %)'
                    '${waiting > 0 ? ' • en attente ${formatQuantity(waiting)}' : ''}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: () => _declare(l),
                      icon: const Icon(Icons.add),
                      label: const Text('Déclarer'),
                    ),
                  ),
                ]),
              ),
            );
          }),
          const SizedBox(height: 12),
          Text('Historique des déclarations', style: Theme.of(context).textTheme.titleMedium),
          ..._records.take(40).map((r) {
            final line = r['project_budget_lines'] as Map?;
            final status = r['status'].toString();
            return ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${line?['designation'] ?? 'Ligne'} — ${formatQuantity(r['quantity'] as num?)} ${line?['unit'] ?? ''}'),
              subtitle: Text('${displayDate(r['record_date'])} • ${_statusLabels[status] ?? status}'),
              trailing: status == 'declared'
                  ? IconButton(
                      tooltip: 'Supprimer',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _guard(() => _service.deleteProgress(r['id'] as String)),
                    )
                  : null,
            );
          }),
        ],
      ),
    );
  }
}
