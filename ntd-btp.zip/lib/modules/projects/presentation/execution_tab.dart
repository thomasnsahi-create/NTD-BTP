import 'package:flutter/material.dart';
import 'execution/diary_section.dart';
import 'execution/expenses_section.dart';
import 'execution/incidents_section.dart';
import 'execution/photos_section.dart';
import 'execution/quantities_section.dart';
import 'execution/variance_section.dart';

/// Suivi d'exécution : écarts et alertes, journal, quantités, dépenses, photos, incidents.
class ExecutionTab extends StatefulWidget {
  const ExecutionTab({super.key, required this.projectId, this.currency = 'XAF'});

  final String projectId;
  final String currency;

  @override
  State<ExecutionTab> createState() => _ExecutionTabState();
}

class _ExecutionTabState extends State<ExecutionTab> {
  int _section = 0;

  static const List<String> _titles = ['Écarts', 'Journal', 'Quantités', 'Dépenses', 'Photos', 'Incidents'];

  Widget _body() {
    switch (_section) {
      case 1:
        return DiarySection(key: const ValueKey('diary'), projectId: widget.projectId);
      case 2:
        return QuantitiesSection(key: const ValueKey('quantities'), projectId: widget.projectId);
      case 3:
        return ExpensesSection(key: const ValueKey('expenses'), projectId: widget.projectId, currency: widget.currency);
      case 4:
        return PhotosSection(key: const ValueKey('photos'), projectId: widget.projectId);
      case 5:
        return IncidentsSection(key: const ValueKey('incidents'), projectId: widget.projectId);
      default:
        return VarianceSection(key: const ValueKey('variance'), projectId: widget.projectId, currency: widget.currency);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: Row(
          children: List<Widget>.generate(_titles.length, (i) {
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(_titles[i]),
                selected: _section == i,
                onSelected: (_) => setState(() => _section = i),
              ),
            );
          }),
        ),
      ),
      Expanded(child: _body()),
    ]);
  }
}
