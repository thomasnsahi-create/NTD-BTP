import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../data/project_service.dart';
import '../domain/critical_path_engine.dart';
import '../domain/resource_aware_scheduler.dart';
import 'resource_planning_tab.dart';
import 'lifecycle_tab.dart';
import 'study_tab.dart';
import 'execution_tab.dart';
import '../../../core/ui/immersive.dart';

class ProjectDetailPage extends StatefulWidget {
  const ProjectDetailPage({super.key, required this.projectId});
  final String projectId;
  @override
  State<ProjectDetailPage> createState() => _ProjectDetailPageState();
}

class _ProjectDetailPageState extends State<ProjectDetailPage> with SingleTickerProviderStateMixin {
  final _service = ProjectService.instance;
  late final TabController _tabs;
  Map<String, dynamic>? _project;
  List<Map<String, dynamic>> _sectors = [], _members = [], _orgMembers = [], _lots = [], _phases = [], _tasks = [], _budgets = [], _progress = [], _dependencies = [];
  bool _loading = true;
  bool _fullscreen = true;
  bool _budgetAllowed = false, _budgetManageAllowed = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 12, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) immersiveMode.value = _fullscreen; });
    _load();
  }

  void _toggleFullscreen() {
    setState(() => _fullscreen = !_fullscreen);
    immersiveMode.value = _fullscreen;
  }

  void _goBack() {
    if (context.canPop()) { context.pop(); } else { context.go('/projects'); }
  }
  @override
  void dispose() {
    _tabs.dispose();
    WidgetsBinding.instance.addPostFrameCallback((_) { immersiveMode.value = false; });
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final p = await _service.getProject(widget.projectId);
      final budgetAllowed = await _service.canViewProjectBudget(widget.projectId);
      final budgetManageAllowed = budgetAllowed && await _service.canEditProjectBudget(widget.projectId);
      final results = await Future.wait([
        _service.listProjectSectors(widget.projectId),
        _service.listProjectMembers(widget.projectId),
        _service.listOrganizationMembers(p['organization_id'] as String),
        _service.listLots(widget.projectId),
        _service.listPhases(widget.projectId),
        _service.listTasks(widget.projectId),
        budgetAllowed ? _service.listBudgetLines(widget.projectId) : Future.value(<Map<String,dynamic>>[]),
        _service.listProgress(widget.projectId),
        _service.listTaskDependencies(widget.projectId),
      ]);
      if (!mounted) return;
      setState(() { _project=p; _sectors=results[0]; _members=results[1]; _orgMembers=results[2]; _lots=results[3]; _phases=results[4]; _tasks=results[5]; _budgets=results[6]; _progress=results[7]; _dependencies=results[8]; _budgetAllowed=budgetAllowed; _budgetManageAllowed=budgetManageAllowed; _loading=false; });
    } catch (e) { if (mounted) setState(() { _error=e.toString(); _loading=false; }); }
  }

  void _errorSnack(Object e) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Échec : $e')));
  String _personLabel(Map<String, dynamic> m) { final p=m['profiles'] as Map<String,dynamic>? ?? {}; final n=(p['full_name'] ?? '${p['first_name'] ?? ''} ${p['last_name'] ?? ''}').toString().trim(); return n.isEmpty ? (m['user_id'] as String).substring(0,8) : n; }
  String _date(dynamic value) { if (value == null) return '—'; if (value is DateTime) return '${value.year.toString().padLeft(4,'0')}-${value.month.toString().padLeft(2,'0')}-${value.day.toString().padLeft(2,'0')}'; return value.toString(); }
  String _taskResponsibleLabel(Map<String,dynamic> task) { final id=task['responsible_user_id']; if(id==null)return 'Sans responsable'; for(final member in _orgMembers){if(member['user_id']==id)return _personLabel(member);} return 'Responsable non disponible'; }
  String _projectResponsibleLabel() { final id = _project?['responsible_user_id']; if (id == null) return 'Non désigné'; for (final member in _orgMembers) { if (member['user_id'] == id) return _personLabel(member); } return 'Membre non disponible'; }
  String _money(dynamic value) => '${((value as num?)?.toDouble() ?? 0).toStringAsFixed(0)} ${_project?['currency'] ?? 'XAF'}';

  Future<void> _editProject() async {
    final p = _project!;
    String status = p['status'] as String;
    String priority = p['priority'] as String;
    String? responsible = p['responsible_user_id'] as String?;
    DateTime? start = p['planned_start'] == null ? null : DateTime.tryParse(p['planned_start'].toString());
    DateTime? end = p['planned_end'] == null ? null : DateTime.tryParse(p['planned_end'].toString());
    final ok = await showDialog<bool>(context: context, builder: (c) => StatefulBuilder(builder: (c, setD) => AlertDialog(
      title: const Text('Paramètres du projet'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(value: status, decoration: const InputDecoration(labelText: 'Statut'), items: const [
          DropdownMenuItem(value: 'draft', child: Text('Brouillon')), DropdownMenuItem(value: 'study', child: Text('Étude')),
          DropdownMenuItem(value: 'planned', child: Text('Planifié')), DropdownMenuItem(value: 'in_progress', child: Text('En cours')),
          DropdownMenuItem(value: 'on_hold', child: Text('En pause')), DropdownMenuItem(value: 'completed', child: Text('Terminé')),
          DropdownMenuItem(value: 'cancelled', child: Text('Annulé')),
        ], onChanged: (v) => setD(() => status = v ?? status)),
        DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'Priorité'), items: const [
          DropdownMenuItem(value: 'low', child: Text('Basse')), DropdownMenuItem(value: 'normal', child: Text('Normale')),
          DropdownMenuItem(value: 'high', child: Text('Haute')), DropdownMenuItem(value: 'critical', child: Text('Critique')),
        ], onChanged: (v) => setD(() => priority = v ?? priority)),
        DropdownButtonFormField<String>(value: responsible, decoration: const InputDecoration(labelText: 'Responsable'), items: _orgMembers.map((m) => DropdownMenuItem(value: m['user_id'] as String, child: Text(_personLabel(m)))).toList(), onChanged: (v) => setD(() => responsible = v)),
        Row(children: [Expanded(child: TextButton(onPressed: () async { final d = await showDatePicker(context: c, initialDate: start ?? DateTime.now(), firstDate: DateTime(2000), lastDate: DateTime(2100)); if (d != null) setD(() => start = d); }, child: Text(start == null ? 'Début prévu' : 'Début ${_date(start)}'))), Expanded(child: TextButton(onPressed: () async { final d = await showDatePicker(context: c, initialDate: end ?? start ?? DateTime.now(), firstDate: DateTime(2000), lastDate: DateTime(2100)); if (d != null) setD(() => end = d); }, child: Text(end == null ? 'Fin prévue' : 'Fin ${_date(end)}')))]),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Enregistrer'))],
    )));
    if (ok != true) return;
    if (start != null && end != null && end!.isBefore(start!)) { _errorSnack('La date de fin doit être postérieure à la date de début.'); return; }
    try { await _service.updateProject(id: widget.projectId, status: status, priority: priority, start: start, end: end, responsibleUserId: responsible); await _load(); } catch (e) { _errorSnack(e); }
  }

  Future<void> _addLot() async {
    final name=TextEditingController(), code=TextEditingController(), desc=TextEditingController();
    DateTime? start, end; String? responsible;
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Nouveau lot de travaux'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:code,decoration:const InputDecoration(labelText:'Code du lot')),TextField(controller:name,decoration:const InputDecoration(labelText:'Nom du lot *')),TextField(controller:desc,decoration:const InputDecoration(labelText:'Description'),maxLines:2),DropdownButtonFormField<String>(value:responsible,decoration:const InputDecoration(labelText:'Responsable du lot'),items:_orgMembers.map((m)=>DropdownMenuItem(value:m['user_id'] as String,child:Text(_personLabel(m)))).toList(),onChanged:(v)=>setD(()=>responsible=v)),Row(children:[Expanded(child:TextButton(onPressed:() async {final d=await showDatePicker(context:c,initialDate:start??DateTime.now(),firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>start=d);},child:Text(start==null?'Début prévu':_date(start)))),Expanded(child:TextButton(onPressed:() async {final d=await showDatePicker(context:c,initialDate:end??start??DateTime.now(),firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>end=d);},child:Text(end==null?'Fin prévue':_date(end))))])])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(c,name.text.trim().isNotEmpty),child:const Text('Ajouter'))])));
    if(ok!=true)return; try { await _service.createLot(widget.projectId,name.text,code.text,desc.text,start,end,responsible); await _load(); } catch(e){_errorSnack(e);}
  }

  Future<void> _addPhase() async {
    final name=TextEditingController(), desc=TextEditingController(); String? responsible; DateTime? start,end;
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Nouvelle phase'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Nom de la phase *')),TextField(controller:desc,decoration:const InputDecoration(labelText:'Description'),maxLines:2),DropdownButtonFormField<String>(value:responsible,decoration:const InputDecoration(labelText:'Responsable'),items:_orgMembers.map((m)=>DropdownMenuItem(value:m['user_id'] as String,child:Text(_personLabel(m)))).toList(),onChanged:(v)=>setD(()=>responsible=v)),Row(children:[Expanded(child:TextButton(onPressed:() async {final d=await showDatePicker(context:c,initialDate:start??DateTime.now(),firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>start=d);},child:Text(start==null?'Début prévu':_date(start)))),Expanded(child:TextButton(onPressed:() async {final d=await showDatePicker(context:c,initialDate:end??start??DateTime.now(),firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>end=d);},child:Text(end==null?'Fin prévue':_date(end))))])])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(c,name.text.trim().isNotEmpty),child:const Text('Ajouter'))])));
    if(ok!=true)return; try{await _service.createPhase(widget.projectId,name.text,desc.text,start,end,responsible);await _load();}catch(e){_errorSnack(e);}
  }

  Future<void> _addTask() async {
    final name=TextEditingController(), desc=TextEditingController(), weight=TextEditingController(text:'1');
    String? phaseId, lotId, responsible; String priority='normal'; DateTime? start,end;
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Nouvelle tâche'),content:SizedBox(width:520,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Intitulé de la tâche *')),TextField(controller:desc,decoration:const InputDecoration(labelText:'Description'),maxLines:2),DropdownButtonFormField<String>(value:phaseId,decoration:const InputDecoration(labelText:'Phase'),items:_phases.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v)=>setD(()=>phaseId=v)),DropdownButtonFormField<String>(value:lotId,decoration:const InputDecoration(labelText:'Lot'),items:_lots.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v)=>setD(()=>lotId=v)),DropdownButtonFormField<String>(value:responsible,decoration:const InputDecoration(labelText:'Responsable'),items:_orgMembers.map((m)=>DropdownMenuItem(value:m['user_id'] as String,child:Text(_personLabel(m)))).toList(),onChanged:(v)=>setD(()=>responsible=v)),DropdownButtonFormField<String>(value:priority,decoration:const InputDecoration(labelText:'Priorité'),items:const [DropdownMenuItem(value:'low',child:Text('Basse')),DropdownMenuItem(value:'normal',child:Text('Normale')),DropdownMenuItem(value:'high',child:Text('Haute')),DropdownMenuItem(value:'critical',child:Text('Critique'))],onChanged:(v)=>setD(()=>priority=v??'normal')),TextField(controller:weight,decoration:const InputDecoration(labelText:'Pondération (poids)'),keyboardType:TextInputType.number),Row(children:[Expanded(child:TextButton(onPressed:() async {final d=await showDatePicker(context:c,initialDate:start??DateTime.now(),firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>start=d);},child:Text(start==null?'Début prévu':_date(start)))),Expanded(child:TextButton(onPressed:() async {final d=await showDatePicker(context:c,initialDate:end??start??DateTime.now(),firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>end=d);},child:Text(end==null?'Fin prévue':_date(end))))])]))),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(c,name.text.trim().isNotEmpty),child:const Text('Ajouter'))])));
    if(ok!=true)return; try{await _service.createTask(projectId:widget.projectId,name:name.text,description:desc.text,phaseId:phaseId,lotId:lotId,responsibleUserId:responsible,start:start,end:end,priority:priority,weight:double.tryParse(weight.text.replaceAll(',','.'))??1);await _load();}catch(e){_errorSnack(e);}
  }

  Future<void> _addBudget() async {
    final designation=TextEditingController(), code=TextEditingController(), unit=TextEditingController(), qty=TextEditingController(text:'1'), price=TextEditingController(text:'0'), actual=TextEditingController(text:'0'), notes=TextEditingController(); String category='material'; String? phaseId, lotId;
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Ligne budgétaire'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:code,decoration:const InputDecoration(labelText:'Référence')),TextField(controller:designation,decoration:const InputDecoration(labelText:'Désignation *')),DropdownButtonFormField<String>(value:category,decoration:const InputDecoration(labelText:'Catégorie'),items:const [DropdownMenuItem(value:'material',child:Text('Matériel')),DropdownMenuItem(value:'labor',child:Text('Main-d’œuvre')),DropdownMenuItem(value:'equipment',child:Text('Équipement')),DropdownMenuItem(value:'subcontracting',child:Text('Sous-traitance')),DropdownMenuItem(value:'other',child:Text('Autre'))],onChanged:(v)=>setD(()=>category=v??'other')),DropdownButtonFormField<String>(value:phaseId,decoration:const InputDecoration(labelText:'Phase associée'),items:_phases.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v)=>setD(()=>phaseId=v)),DropdownButtonFormField<String>(value:lotId,decoration:const InputDecoration(labelText:'Lot associé'),items:_lots.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v)=>setD(()=>lotId=v)),TextField(controller:unit,decoration:const InputDecoration(labelText:'Unité (u, m, m², kg...)')),TextField(controller:qty,decoration:const InputDecoration(labelText:'Quantité'),keyboardType:TextInputType.number),TextField(controller:price,decoration:const InputDecoration(labelText:'Prix unitaire'),keyboardType:TextInputType.number),TextField(controller:actual,decoration:const InputDecoration(labelText:'Dépense réelle'),keyboardType:TextInputType.number),TextField(controller:notes,decoration:const InputDecoration(labelText:'Notes'),maxLines:2)])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(c,designation.text.trim().isNotEmpty),child:const Text('Ajouter'))])));
    if(ok!=true)return; try{await _service.createBudgetLine(projectId:widget.projectId,designation:designation.text,category:category,code:code.text,unit:unit.text,phaseId:phaseId,lotId:lotId,quantity:double.tryParse(qty.text.replaceAll(',','.'))??0,unitPrice:double.tryParse(price.text.replaceAll(',','.'))??0,actualAmount:double.tryParse(actual.text.replaceAll(',','.'))??0,currency:(_project?['currency']??'XAF') as String,notes:notes.text);await _load();}catch(e){_errorSnack(e);}
  }

  Future<void> _addMember() async {
    final existing=_members.map((m)=>m['user_id']).toSet(); final candidates=_orgMembers.where((m)=>!existing.contains(m['user_id'])).toList();
    if(candidates.isEmpty){_errorSnack('Tous les membres actifs de l’organisation sont déjà affectés à ce projet.');return;}
    String? userId; final role=TextEditingController(text:'Membre du projet'); final allocation=TextEditingController(text:'100');
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Affecter un membre'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<String>(value:userId,decoration:const InputDecoration(labelText:'Utilisateur'),items:candidates.map((m)=>DropdownMenuItem(value:m['user_id'] as String,child:Text(_personLabel(m)))).toList(),onChanged:(v)=>setD(()=>userId=v)),TextField(controller:role,decoration:const InputDecoration(labelText:'Rôle dans le projet')),TextField(controller:allocation,decoration:const InputDecoration(labelText:'Affectation (%)'),keyboardType:TextInputType.number)]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(c,userId!=null),child:const Text('Affecter'))])));
    if(ok!=true||userId==null)return;try{await _service.addProjectMember(widget.projectId,userId!,role.text,double.tryParse(allocation.text.replaceAll(',','.'))??100);await _load();}catch(e){_errorSnack(e);}
  }

  Future<void> _reportTask(Map<String,dynamic> task) async {
    double progress=(task['progress_percent'] as num?)?.toDouble()??0; String status=task['status'] as String; final report=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:Text('Avancement : ${task['name']}'),content:Column(mainAxisSize:MainAxisSize.min,children:[Text('${progress.toStringAsFixed(0)} %'),Slider(value:progress,min:0,max:100,divisions:20,label:'${progress.toStringAsFixed(0)} %',onChanged:(v)=>setD(()=>progress=v)),DropdownButtonFormField<String>(value:status,decoration:const InputDecoration(labelText:'Statut'),items:const [DropdownMenuItem(value:'not_started',child:Text('Non démarrée')),DropdownMenuItem(value:'in_progress',child:Text('En cours')),DropdownMenuItem(value:'blocked',child:Text('Bloquée')),DropdownMenuItem(value:'on_hold',child:Text('En pause')),DropdownMenuItem(value:'completed',child:Text('Terminée')),DropdownMenuItem(value:'cancelled',child:Text('Annulée'))],onChanged:(v)=>setD(()=>status=v??status)),TextField(controller:report,decoration:const InputDecoration(labelText:'Compte rendu / observations'),maxLines:3)]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Enregistrer'))])));
    if(ok!=true)return;try{await _service.updateTaskProgress(task['id'] as String,progress,status,report.text);await _load();}catch(e){_errorSnack(e);}
  }

  @override
  Widget build(BuildContext context) {
    if(_loading)return const Center(child:CircularProgressIndicator());
    if(_error!=null)return SafeArea(child:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Text(_error!),const SizedBox(height:12),FilledButton(onPressed:_load,child:const Text('Réessayer')),TextButton(onPressed:_goBack,child:const Text('Retour aux projets'))]))));
    final p=_project!; final progress=(p['progress_percent'] as num?)?.toDouble()??0;
    return Scaffold(body:SafeArea(top:_fullscreen,bottom:_fullscreen,child:Column(children:[
      if(_fullscreen)Padding(padding:const EdgeInsets.fromLTRB(8,4,8,0),child:Column(children:[Row(children:[IconButton(onPressed:_goBack,icon:const Icon(Icons.arrow_back)),Expanded(child:Text('${p['code']} • ${p['name']}',style:Theme.of(context).textTheme.titleMedium,maxLines:1,overflow:TextOverflow.ellipsis)),IconButton(onPressed:_editProject,tooltip:'Modifier les paramètres du projet',icon:const Icon(Icons.edit_outlined)),IconButton(onPressed:_load,tooltip:'Actualiser',icon:const Icon(Icons.refresh)),IconButton(onPressed:_toggleFullscreen,tooltip:'Afficher les informations du projet',icon:const Icon(Icons.fullscreen_exit))]),LinearProgressIndicator(value:progress/100,minHeight:3)]))
      else Padding(padding:const EdgeInsets.fromLTRB(16,12,16,8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[IconButton(onPressed:_goBack,icon:const Icon(Icons.arrow_back)),Expanded(child:Text('${p['code']} • ${p['name']}',style:Theme.of(context).textTheme.titleLarge,maxLines:2,overflow:TextOverflow.ellipsis)),IconButton(onPressed:_editProject,tooltip:'Modifier les paramètres du projet',icon:const Icon(Icons.edit_outlined)),IconButton(onPressed:_load,icon:const Icon(Icons.refresh)),IconButton(onPressed:_toggleFullscreen,tooltip:'Plein écran',icon:const Icon(Icons.fullscreen))]),Wrap(spacing:6,runSpacing:4,children:[Chip(label:Text(p['status'].toString().replaceAll('_',' '))),Chip(label:Text('Priorité ${p['priority']}')),]),LinearProgressIndicator(value:progress/100,minHeight:8),const SizedBox(height:4),Text('Responsable : ${_projectResponsibleLabel()}'),Text('Avancement global : ${progress.toStringAsFixed(1)} % • Début ${_date(p['planned_start'])} • Fin contractuelle ${_date(p['planned_end'])}'),if(p['forecast_end']!=null)Text('Fin prévisionnelle recalculée : ${_date(p['forecast_end'])} • Écart ${p['forecast_delay_days']} jour(s)',style:Theme.of(context).textTheme.bodySmall),if(_sectors.isNotEmpty)Wrap(spacing:6,children:_sectors.map((s)=>Chip(label:Text('${(s['sectors'] as Map?)?['name'] ?? 'Secteur'}${s['is_primary']==true?' • Principal':''}'))).toList())])),
      Material(color:Theme.of(context).colorScheme.surface,child:TabBar(controller:_tabs,isScrollable:true,tabs:const [Tab(text:'Cycle de vie'),Tab(text:'Étude'),Tab(text:'Exécution'),Tab(text:'Lots'),Tab(text:'Phases'),Tab(text:'Tâches'),Tab(text:'Planning Gantt'),Tab(text:'Chemin critique'),Tab(text:'Budget'),Tab(text:'Équipe'),Tab(text:'Calendrier & ressources'),Tab(text:'Avancement')])),
      Expanded(child:TabBarView(controller:_tabs,children:[
        LifecycleTab(projectId:widget.projectId,onChanged:_load),
        StudyTab(projectId:widget.projectId,organizationId:p['organization_id'] as String,currency:(p['currency']??'XAF').toString(),onChanged:_load),
        ExecutionTab(projectId:widget.projectId,currency:(p['currency']??'XAF').toString()),
        _listTab('Lots de travaux',_lots,(x)=>'${x['code']??''} ${x['name']}',(x)=>'${x['status']} • ${_date(x['planned_start'])} → ${_date(x['planned_end'])}',_addLot,Icons.layers_outlined),
        _listTab('Phases du projet',_phases,(x)=>x['name'] as String,(x)=>'${x['status']} • ${_date(x['planned_start'])} → ${_date(x['planned_end'])} • ${x['progress_percent']} %',_addPhase,Icons.timeline),
        _tasksTab(), _ganttTab(), _criticalPathTab(), _budgetTab(), _teamTab(), ResourcePlanningTab(projectId:widget.projectId), _progressTab(),
      ])),
    ])));
  }

  Widget _listTab(String title,List<Map<String,dynamic>> rows,String Function(Map<String,dynamic>) headline,String Function(Map<String,dynamic>) subtitle,VoidCallback add,IconData icon)=>ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:Text('$title (${rows.length})',style:Theme.of(context).textTheme.titleMedium)),FilledButton.tonalIcon(onPressed:add,icon:const Icon(Icons.add),label:const Text('Ajouter'))]),if(rows.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Text('Aucun élément enregistré.')),...rows.map((x)=>Card(child:ListTile(leading:Icon(icon),title:Text(headline(x)),subtitle:Text(subtitle(x)),isThreeLine:true)))]);

  Widget _tasksTab()=>ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:Text('Tâches (${_tasks.length})',style:Theme.of(context).textTheme.titleMedium)),FilledButton.tonalIcon(onPressed:_addTask,icon:const Icon(Icons.add),label:const Text('Ajouter'))]),if(_tasks.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Text('Aucune tâche. Créez les tâches et affectez-les à une phase, un lot et un responsable.')),..._tasks.map((t){final v=(t['progress_percent'] as num?)?.toDouble()??0;return Card(child:ListTile(leading:CircleAvatar(child:Text('${v.toInt()}')),title:Text(t['name'] as String),subtitle:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${(t['project_phases'] as Map?)?['name']??'Sans phase'} • ${(t['work_packages'] as Map?)?['name']??'Sans lot'}'),Text('${t['status']} • ${t['priority']} • ${_date(t['planned_start'])} → ${_date(t['planned_end'])}'),LinearProgressIndicator(value:v/100)]),isThreeLine:true,trailing:IconButton(tooltip:'Déclarer l’avancement',onPressed:()=>_reportTask(t),icon:const Icon(Icons.edit_note))));})]);


  Future<void> _editTaskSchedule(Map<String,dynamic> task) async {
    DateTime? start = task['planned_start'] == null ? null : DateTime.tryParse(task['planned_start'].toString());
    DateTime? end = task['planned_end'] == null ? null : DateTime.tryParse(task['planned_end'].toString());
    start ??= DateTime.now(); end ??= start;
    final ok = await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(
      title:Text('Planning : ${task['name']}'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        ListTile(title:const Text('Début prévu'),subtitle:Text(_date(start)),trailing:const Icon(Icons.calendar_today),onTap:() async {final d=await showDatePicker(context:c,initialDate:start!,firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>start=d);}),
        ListTile(title:const Text('Fin prévue'),subtitle:Text(_date(end)),trailing:const Icon(Icons.event),onTap:() async {final d=await showDatePicker(context:c,initialDate:end!,firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setD(()=>end=d);}),
        const Text('La modification des dates est contrôlée par les permissions de planning.'),
      ]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Enregistrer'))],
    )));
    if(ok!=true)return;
    if(start==null||end==null||end!.isBefore(start!)){_errorSnack('Dates de planning invalides.');return;}
    try{await _service.updateTaskSchedule(task['id'] as String,start!,end!);await _load();}catch(e){_errorSnack(e);}
  }

  Future<void> _manageDependencies(Map<String,dynamic> task) async {
    final taskId=task['id'] as String;
    final current=_dependencies.where((d)=>d['task_id']==taskId).toList();
    final candidates=_tasks.where((t)=>t['id']!=taskId).toList();
    if(candidates.isEmpty){_errorSnack('Ajoutez au moins deux tâches pour définir une dépendance.');return;}
    String? predecessor; String type='finish_to_start';
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(
      title:Text('Dépendances : ${task['name']}'),
      content:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Cette tâche dépend de :'),
        if(current.isEmpty)const Text('Aucun prédécesseur enregistré.'),
        ...current.map((d){final matches=_tasks.where((x)=>x['id']==d['depends_on_task_id']);final t=matches.isEmpty?null:matches.first;return ListTile(dense:true,title:Text(t?['name']?.toString()??'Tâche inconnue'),subtitle:Text((d['dependency_type']??'finish_to_start').toString()),trailing:IconButton(icon:const Icon(Icons.remove_circle_outline),onPressed:() async {try{await _service.removeTaskDependency(taskId,d['depends_on_task_id'] as String);if(c.mounted)Navigator.pop(c,true);}catch(e){_errorSnack(e);}}));}),
        const Divider(),
        DropdownButtonFormField<String>(value:predecessor,decoration:const InputDecoration(labelText:'Ajouter un prédécesseur'),items:candidates.map((t)=>DropdownMenuItem(value:t['id'] as String,child:Text(t['name'] as String,overflow:TextOverflow.ellipsis))).toList(),onChanged:(v)=>setD(()=>predecessor=v)),
        DropdownButtonFormField<String>(value:type,decoration:const InputDecoration(labelText:'Type de liaison'),items:const [DropdownMenuItem(value:'finish_to_start',child:Text('Fin → Début (FS)')),DropdownMenuItem(value:'start_to_start',child:Text('Début → Début (SS)')),DropdownMenuItem(value:'finish_to_finish',child:Text('Fin → Fin (FF)')),DropdownMenuItem(value:'start_to_finish',child:Text('Début → Fin (SF)'))],onChanged:(v)=>setD(()=>type=v??type)),
      ]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Fermer')),FilledButton(onPressed:()=>Navigator.pop(c,predecessor!=null),child:const Text('Ajouter la liaison'))],
    )));
    if(ok==true&&predecessor!=null){try{await _service.addTaskDependency(taskId,predecessor!,type);await _load();}catch(e){_errorSnack(e);}}
    else if(ok==true){await _load();}
  }

  Widget _ganttTab(){
    if(_tasks.isEmpty)return const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('Aucune tâche à planifier. Créez d’abord des tâches avec des dates de début et de fin.')));
    final dated=_tasks.where((t)=>t['planned_start']!=null&&t['planned_end']!=null).toList();
    if(dated.isEmpty)return ListView(padding:const EdgeInsets.all(20),children:[const Text('Le diagramme de Gantt nécessite des dates prévisionnelles pour les tâches.'),const SizedBox(height:12),..._tasks.map((t)=>ListTile(title:Text(t['name'] as String),subtitle:const Text('Dates non définies'),trailing:IconButton(icon:const Icon(Icons.edit_calendar),onPressed:()=>_editTaskSchedule(t))))]);
    final starts=dated.map((t)=>DateTime.parse(t['planned_start'].toString())).toList();
    final ends=dated.map((t)=>DateTime.parse(t['planned_end'].toString())).toList();
    DateTime minDate=starts.reduce((a,b)=>a.isBefore(b)?a:b); DateTime maxDate=ends.reduce((a,b)=>a.isAfter(b)?a:b);
    minDate=DateTime(minDate.year,minDate.month,minDate.day).subtract(const Duration(days:7));
    maxDate=DateTime(maxDate.year,maxDate.month,maxDate.day).add(const Duration(days:8));
    final days=maxDate.difference(minDate).inDays.clamp(1,730).toInt();
    const scale=22.0; final timelineWidth=days*scale; final totalWidth=210+timelineWidth;
    final today=DateTime.now(); final todayOffset=today.difference(minDate).inDays*scale;
    final weekTicks=<Widget>[];
    for(int i=0;i<days;i+=7){final d=minDate.add(Duration(days:i));weekTicks.add(SizedBox(width:(7*scale).clamp(0,timelineWidth-i*scale).toDouble(),child:Container(alignment:Alignment.centerLeft,padding:const EdgeInsets.only(left:4),decoration:BoxDecoration(border:Border(left:BorderSide(color:Theme.of(context).dividerColor))),child:Text('${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}',style:Theme.of(context).textTheme.labelSmall))));}
    return Column(children:[
      Padding(padding:const EdgeInsets.all(10),child:Wrap(spacing:12,runSpacing:6,alignment:WrapAlignment.spaceBetween,children:[Text('Planning détaillé • ${_tasks.length} tâches • ${_tasks.where((t)=>t['planned_end']!=null&&DateTime.parse(t['planned_end'].toString()).isBefore(DateTime(DateTime.now().year,DateTime.now().month,DateTime.now().day))&&(t['progress_percent'] as num? ?? 0)<100).length} en retard',style:Theme.of(context).textTheme.titleMedium),Text('Échelle : 1 jour = ${scale.toInt()} px',style:Theme.of(context).textTheme.bodySmall),Text('Aujourd’hui : ${_date(today)}',style:Theme.of(context).textTheme.bodySmall)])),
      Expanded(child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:SizedBox(width:totalWidth,child:Column(children:[
        SizedBox(height:38,child:Row(children:[SizedBox(width:210,child:Padding(padding:const EdgeInsets.all(8),child:Text('TÂCHE / RESPONSABLE',style:Theme.of(context).textTheme.labelSmall))),...weekTicks])),
        Expanded(child:ListView.builder(itemCount:_tasks.length,itemBuilder:(context,index){final t=_tasks[index];final hasDates=t['planned_start']!=null&&t['planned_end']!=null;final st=hasDates?DateTime.parse(t['planned_start'].toString()):minDate;final en=hasDates?DateTime.parse(t['planned_end'].toString()):st;final offset=(st.difference(minDate).inDays*scale).clamp(0.0,timelineWidth).toDouble();final duration=((en.difference(st).inDays+1)*scale).clamp(8.0,(timelineWidth-offset)<8.0?8.0:(timelineWidth-offset)).toDouble();final pct=((t['progress_percent'] as num?)?.toDouble()??0).clamp(0,100);final todayDate=DateTime(today.year,today.month,today.day);final overdue=hasDates&&en.isBefore(todayDate)&&pct<100&&t['status']!='cancelled';final color=t['status']=='completed'?Colors.green:t['status']=='blocked'?Colors.red:t['status']=='on_hold'?Colors.orange:overdue?Colors.deepOrange:Theme.of(context).colorScheme.primary;final deps=_dependencies.where((d)=>d['task_id']==t['id']).length;return SizedBox(height:66,child:Stack(children:[Positioned(left:0,top:0,bottom:0,width:205,child:InkWell(onTap:()=>_editTaskSchedule(t),child:Padding(padding:const EdgeInsets.symmetric(horizontal:8,vertical:5),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(t['name'] as String,maxLines:1,overflow:TextOverflow.ellipsis,style:Theme.of(context).textTheme.bodyMedium),Text('${_taskResponsibleLabel(t)} • ${t['status']} • ${hasDates?'${_date(st)} → ${_date(en)}':'Dates à définir'}',maxLines:1,overflow:TextOverflow.ellipsis,style:Theme.of(context).textTheme.labelSmall)])))),Positioned(left:210,top:0,bottom:0,width:timelineWidth,child:Stack(children:[Positioned.fill(child:Row(children:List.generate(days,(_)=>SizedBox(width:scale,child:Container(decoration:BoxDecoration(border:Border(left:BorderSide(color:Theme.of(context).dividerColor.withOpacity(.35))))))))),if(todayOffset>=0&&todayOffset<=timelineWidth)Positioned(left:todayOffset,top:0,bottom:0,child:Container(width:1,color:Colors.red.withOpacity(.65))),if(hasDates)Positioned(left:offset,top:20,width:duration,height:26,child:Tooltip(message:'${t['name']} • ${pct.toStringAsFixed(0)} % • ${deps} dépendance(s)',child:InkWell(onTap:()=>_editTaskSchedule(t),onLongPress:()=>_manageDependencies(t),child:ClipRRect(borderRadius:BorderRadius.circular(5),child:Stack(children:[Container(color:color.withOpacity(.25)),Align(alignment:Alignment.centerLeft,child:FractionallySizedBox(widthFactor:(pct/100).toDouble(),child:Container(color:color))),Center(child:Text('${pct.toStringAsFixed(0)} %',style:Theme.of(context).textTheme.labelSmall?.copyWith(color:Theme.of(context).colorScheme.onSurface)))])))))])),Positioned(right:2,top:20,child:IconButton(visualDensity:VisualDensity.compact,tooltip:'Dates et dépendances',onPressed:()=>_manageDependencies(t),icon:const Icon(Icons.account_tree_outlined,size:18)))]));})),
      ])))),
      Padding(padding:const EdgeInsets.all(8),child:Wrap(spacing:14,children:[_legend(Theme.of(context).colorScheme.primary,'En cours'),_legend(Colors.green,'Terminée'),_legend(Colors.red,'Bloquée'),_legend(Colors.orange,'En pause'),_legend(Colors.deepOrange,'En retard')])),
      const Padding(padding:EdgeInsets.fromLTRB(12,0,12,8),child:Text('Touchez une barre pour modifier ses dates. Utilisez l’icône de dépendances pour définir les liens entre tâches. Le contrôle anti-boucle est assuré par la base Supabase.',style:TextStyle(fontSize:12))),
    ]);
  }

  Future<void> _simulateAndApplyReschedule() async {
    ResourceScheduleResult proposal;
    Map<String,dynamic>? calendar;
    try {
      calendar = await _service.getWorkCalendar(widget.projectId);
      if (calendar == null) throw Exception('Aucun calendrier de chantier. Ouvrez Calendrier & ressources pour initialiser le calendrier.');
      final holidays = await _service.listCalendarHolidays(calendar['id'] as String);
      final resources = await _service.listProjectResources(widget.projectId);
      final allocations = await _service.listTaskResourceAllocations(widget.projectId);
      final unavailable = <String,List<DateRange>>{};
      for (final r in resources) {
        final rows = await _service.listResourceUnavailability(r['id'] as String);
        unavailable[r['id'] as String] = rows.map((x)=>DateRange(DateTime.parse(x['unavailable_start'].toString()),DateTime.parse(x['unavailable_end'].toString()))).toList();
      }
      final resourceMap = {for(final r in resources) r['id'].toString():ResourceCapacity(id:r['id'].toString(),capacity:(r['capacity'] as num).toDouble(),unavailable:unavailable[r['id'].toString()]??const [])};
      final requirements = <String,List<ResourceRequirement>>{};
      for(final a in allocations){requirements.putIfAbsent(a['task_id'].toString(),()=>[]).add(ResourceRequirement(resourceId:a['resource_id'].toString(),quantity:(a['allocated_capacity'] as num).toDouble()));}
      final workingDays = (calendar['working_days'] as List).map((x)=>(x as num).toInt()).toSet();
      final holidayDates = holidays.where((h)=>h['is_working_day_override']!=true && (calendar!['exclude_public_holidays']==true || h['holiday_type']!='public')).map((h){final d=DateTime.parse(h['holiday_date'].toString());return DateTime(d.year,d.month,d.day);}).toSet();
      final workingOverrides = holidays.where((h)=>h['is_working_day_override']==true).map((h){final d=DateTime.parse(h['holiday_date'].toString());return DateTime(d.year,d.month,d.day);}).toSet();
      proposal = ResourceAwareScheduler.simulate(tasks:_tasks,dependencies:_dependencies,calendar:WorkCalendarConfig(workingDays:workingDays,holidays:holidayDates,workingOverrides:workingOverrides,hoursPerDay:(calendar['hours_per_day'] as num).toDouble()),resources:resourceMap,requirementsByTask:requirements);
    } catch (e) { _errorSnack(e); return; }
    final changed = proposal.changedIds.toList()..sort((a,b) => proposal.start[a]!.compareTo(proposal.start[b]!));
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Simulation de reprogrammation'),
      content: SizedBox(width: 520, child: SingleChildScrollView(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text('${changed.length} tâche(s) seront modifiées.'),
          const SizedBox(height: 6),
          Text('Nouvelle fin prévisionnelle : ${_date(proposal.finish)}', style: Theme.of(context).textTheme.titleMedium),
          Text(_project?['planned_end'] == null ? 'Date de fin recalculée selon les ressources disponibles.' : (proposal.finish.isAfter(DateTime.parse(_project!['planned_end'].toString())) ? 'Retard prévisionnel : ${proposal.finish.difference(DateTime.parse(_project!['planned_end'].toString())).inDays} jour(s).' : 'La date contractuelle est respectée selon les ressources disponibles.')),
          const SizedBox(height: 12),
          if (changed.isEmpty) const Text('Aucune date ne nécessite de modification.'),
          ...changed.map((id) {
            final task = _tasks.firstWhere((t) => t['id'].toString() == id);
            return ListTile(dense: true, contentPadding: EdgeInsets.zero,
              title: Text(task['name'].toString()),
              subtitle: Text('${_date(task['planned_start'])} → ${_date(task['planned_end'])}'),
              trailing: SizedBox(width: 112, child: Text('${_date(proposal.start[id])}\n→ ${_date(proposal.end[id])}', textAlign: TextAlign.end, style: Theme.of(context).textTheme.labelSmall)),
            );
          }),
          const SizedBox(height: 8),
          const Text('Hypothèses : jours ouvrés selon le calendrier du chantier, jours fériés exclus (sauf exception travaillée), durée restante estimée à partir de l’avancement. Les capacités d’équipes et d’engins affectées sont contrôlées. Les tâches terminées restent fixes.'),
        ],
      ))),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Appliquer les dates'))],
    ));
    if (ok != true || changed.isEmpty) return;
    try {
      final updates = changed.map((id) => <String, dynamic>{
        'task_id': id,
        'planned_start': DateTime(proposal.start[id]!.year,proposal.start[id]!.month,proposal.start[id]!.day).toIso8601String().substring(0, 10),
        'planned_end': DateTime(proposal.end[id]!.year,proposal.end[id]!.month,proposal.end[id]!.day).toIso8601String().substring(0, 10),
      }).toList();
      final baseline = _project?['planned_end'] == null ? proposal.finish : DateTime.parse(_project!['planned_end'].toString());
      await _service.applyScheduleProposal(projectId: widget.projectId, updates: updates, forecastEnd: proposal.finish, delayDays: proposal.finish.difference(baseline).inDays);
      await _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reprogrammation appliquée et prévision de livraison enregistrée.')));
    } catch (e) { _errorSnack(e); }
  }

  Widget _criticalPathTab() {
    if (_tasks.isEmpty) return const Center(child: Text('Ajoutez des tâches pour calculer le chemin critique.'));
    CriticalPathResult? result;
    String? problem;
    try { result = CriticalPathEngine.analyze(_tasks, _dependencies); } catch (e) { problem = e.toString(); }
    if (result == null) return ListView(padding: const EdgeInsets.all(16), children: [
      const Icon(Icons.account_tree_outlined, size: 42), const SizedBox(height: 12),
      Text('Calcul impossible', style: Theme.of(context).textTheme.titleLarge),
      Text(problem ?? 'Vérifiez les dates et les dépendances.'),
      const SizedBox(height: 12),
      const Text('Pour calculer le chemin critique, les tâches actives doivent avoir une date de début et une date de fin. Le réseau de dépendances doit être sans boucle.'),
    ]);
    final r = result;
    final criticalTasks = r.orderedIds.where(r.criticalIds.contains).toList();
    final sorted = r.orderedIds.toList()..sort((a,b) => (r.slackDays[a] ?? 0).compareTo(r.slackDays[b] ?? 0));
    final contractualEnd = _project?['planned_end'] == null ? null : DateTime.tryParse(_project!['planned_end'].toString());
    final riskDays = contractualEnd == null ? null : r.projectFinish.difference(CriticalPathEngine.day(contractualEnd)).inDays;
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (riskDays != null && riskDays > 0) Card(color: Theme.of(context).colorScheme.errorContainer, child: ListTile(
        leading: const Icon(Icons.warning_amber_rounded),
        title: const Text('Risque de dépassement de la livraison'),
        subtitle: Text('Le réseau de tâches prévoit une fin au ${_date(r.projectFinish)}, soit $riskDays jour(s) après la date contractuelle du ${_date(contractualEnd)}.'),
      )),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Analyse du calendrier', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        Wrap(spacing: 18, runSpacing: 12, children: [
          _metric('Durée calculée', '${r.totalDurationDays} j'),
          _metric('Fin calculée', _date(r.projectFinish)),
          _metric('Tâches critiques', '${criticalTasks.length}'),
          _metric('Tâches analysées', '${r.orderedIds.length}'),
        ]),
        const SizedBox(height: 8),
        const Text('Une tâche critique possède une marge totale nulle ou négative : un retard sur cette tâche menace la date de fin du projet.'),
      ]))),
      const SizedBox(height: 8),
      Row(children: [Expanded(child: Text('Chemin critique', style: Theme.of(context).textTheme.titleMedium)),
        FilledButton.tonalIcon(onPressed: _simulateAndApplyReschedule, icon: const Icon(Icons.auto_fix_high), label: const Text('Reprogrammer'))]),
      if (criticalTasks.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Aucune tâche critique détectée avec les contraintes actuelles.')),
      ...criticalTasks.map((id) {
        final t = _tasks.firstWhere((x) => x['id'].toString() == id);
        return Card(color: Theme.of(context).colorScheme.errorContainer.withOpacity(.35), child: ListTile(
          leading: const Icon(Icons.warning_amber_rounded), title: Text(t['name'].toString()),
          subtitle: Text('${_date(r.earlyStart[id])} • ${r.durationDays[id]} jour(s)'),
          trailing: const Chip(label: Text('CRITIQUE')),
        ));
      }),
      const SizedBox(height: 12),
      Text('Marges de chaque tâche', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 4),
      ...sorted.map((id) {
        final t = _tasks.firstWhere((x) => x['id'].toString() == id);
        final slack = r.slackDays[id] ?? 0;
        return ListTile(dense: true, contentPadding: EdgeInsets.zero,
          leading: Icon(slack == 0 ? Icons.warning_amber_rounded : Icons.schedule, color: slack == 0 ? Theme.of(context).colorScheme.error : null),
          title: Text(t['name'].toString()),
          subtitle: Text('Début au plus tôt : ${_date(r.earlyStart[id])} • au plus tard : ${_date(r.lateStart[id])}'),
          trailing: Text(slack == 0 ? '0 j' : '$slack j', style: TextStyle(fontWeight: FontWeight.bold, color: slack == 0 ? Theme.of(context).colorScheme.error : null)),
        );
      }),
      const SizedBox(height: 10),
      const Text('Important : le calcul utilise les dates planifiées comme contraintes minimales, les liens FS/SS/FF/SF et des jours calendaires. Les tâches sans dates et les jours non ouvrés ne sont pas intégrés. Le résultat doit être validé par le conducteur de travaux.'),
    ]);
  }

  Widget _metric(String label, String value) => SizedBox(width: 135, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: Theme.of(context).textTheme.labelSmall), Text(value, style: Theme.of(context).textTheme.titleMedium)]));

  Widget _legend(Color color,String label)=>Row(mainAxisSize:MainAxisSize.min,children:[Container(width:10,height:10,decoration:BoxDecoration(color:color,borderRadius:BorderRadius.circular(2))),const SizedBox(width:4),Text(label,style:const TextStyle(fontSize:11))]);

  Widget _budgetTab(){if(!_budgetAllowed)return const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('Accès au budget restreint. Votre rôle ne dispose pas de la permission de consultation financière.')));final estimate=_budgets.fold<double>(0,(s,x)=>s+((x['estimated_amount'] as num?)?.toDouble()??0));final actual=_budgets.fold<double>(0,(s,x)=>s+((x['actual_amount'] as num?)?.toDouble()??0));return ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:Text('Budget (${_budgets.length} lignes)',style:Theme.of(context).textTheme.titleMedium)),FilledButton.tonalIcon(onPressed:_budgetManageAllowed?_addBudget:null,icon:const Icon(Icons.add),label:const Text('Ajouter'))]),Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Prévision : ${estimate.toStringAsFixed(0)} ${_project?['currency']??'XAF'}'),Text('Réel : ${actual.toStringAsFixed(0)} ${_project?['currency']??'XAF'}'),Text('Écart : ${(estimate-actual).toStringAsFixed(0)} ${_project?['currency']??'XAF'}')]))),if(_budgets.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Text('Aucune ligne budgétaire.')),..._budgets.map((b)=>Card(child:ListTile(title:Text(b['designation'] as String),subtitle:Text('${b['category']} • ${b['quantity']} ${b['unit']??''} × ${b['unit_price']}'),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[Text('${b['estimated_amount']}'),Text('Réel ${b['actual_amount']}',style:Theme.of(context).textTheme.bodySmall)]))))]);}

  Widget _teamTab()=>ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:Text('Équipe projet (${_members.length})',style:Theme.of(context).textTheme.titleMedium)),FilledButton.tonalIcon(onPressed:_addMember,icon:const Icon(Icons.person_add_alt_1),label:const Text('Affecter'))]),if(_members.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Text('Aucun membre affecté.')),..._members.map((m)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(_personLabel(m)),subtitle:Text('${m['project_role']} • Affectation ${m['allocation_percent']} %${m['is_responsible']==true?' • Responsable':''}'))))]);

  Widget _progressTab()=>ListView(padding:const EdgeInsets.all(16),children:[Text('Historique des rapports (${_progress.length})',style:Theme.of(context).textTheme.titleMedium),if(_progress.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Text('Aucun rapport d’avancement enregistré. Déclarez la progression depuis l’onglet Tâches.')),..._progress.map((x)=>Card(child:ListTile(leading:const Icon(Icons.assessment_outlined),title:Text('${x['progress_percent']} %'),subtitle:Text('${x['report']??'Sans commentaire'}\n${x['reported_at']}'),isThreeLine:true))) ]);
}
