import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../data/project_service.dart';

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});
  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> {
  final _service = ProjectService.instance;
  List<Map<String, dynamic>> _organizations = [];
  List<Map<String, dynamic>> _projects = [];
  String? _organizationId;
  bool _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final orgs = await _service.listOrganizations();
      final selected = _organizationId != null && orgs.any((o) => o['id'] == _organizationId)
          ? _organizationId! : (orgs.isNotEmpty ? orgs.first['id'] as String : null);
      final projects = selected == null ? <Map<String, dynamic>>[] : await _service.listProjects(selected);
      if (!mounted) return;
      setState(() { _organizations = orgs; _organizationId = selected; _projects = projects; _loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _changeOrganization(String? id) async {
    if (id == null) return;
    setState(() { _organizationId = id; _loading = true; });
    try {
      final rows = await _service.listProjects(id);
      if (mounted) setState(() { _projects = rows; _loading = false; });
    } catch (e) { if (mounted) setState(() { _error = e.toString(); _loading = false; }); }
  }

  Future<void> _createProject() async {
    final orgId = _organizationId;
    if (orgId == null) return;
    final sectors = await _service.listSectors();
    final members = await _service.listOrganizationMembers(orgId);
    if (!mounted) return;
    final code = TextEditingController();
    final name = TextEditingController();
    final description = TextEditingController();
    final client = TextEditingController();
    final address = TextEditingController();
    final selectedSectors = <String>{};
    String? responsible;
    String currency = _organizations.firstWhere((o) => o['id'] == orgId)['default_currency'] as String? ?? 'XAF';
    String country = _organizations.firstWhere((o) => o['id'] == orgId)['country_code'] as String? ?? 'CM';
    String priority = 'normal';
    DateTime? start;
    DateTime? end;
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      title: const Text('Créer un projet'),
      content: SizedBox(width: 560, child: SingleChildScrollView(child: Form(key: formKey, child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextFormField(controller: code, decoration: const InputDecoration(labelText: 'Code du projet *', hintText: 'Ex. BTP-2026-001'), validator: (v) => v == null || v.trim().isEmpty ? 'Code obligatoire' : null),
        TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Nom du projet *'), validator: (v) => v == null || v.trim().isEmpty ? 'Nom obligatoire' : null),
        TextFormField(controller: description, decoration: const InputDecoration(labelText: 'Description'), maxLines: 2),
        TextFormField(controller: client, decoration: const InputDecoration(labelText: 'Client / maître d’ouvrage')),
        TextFormField(controller: address, decoration: const InputDecoration(labelText: 'Adresse / site du chantier')),
        const SizedBox(height: 12),
        Align(alignment: Alignment.centerLeft, child: Text('Classification multisectorielle', style: Theme.of(context).textTheme.titleSmall)),
        if (sectors.isEmpty) const Text('Aucun secteur disponible. Exécutez le catalogue de référence.'),
        ...sectors.map((s) => CheckboxListTile(dense: true, contentPadding: EdgeInsets.zero, value: selectedSectors.contains(s['id']), title: Text(s['name'] as String), onChanged: (v) => setDialogState(() { if (v == true) { selectedSectors.add(s['id'] as String); } else { selectedSectors.remove(s['id']); } }))),
        DropdownButtonFormField<String>(value: responsible, decoration: const InputDecoration(labelText: 'Responsable du projet'), items: members.map((m) { final p = m['profiles'] as Map<String, dynamic>? ?? {}; final label = (p['full_name'] ?? '${p['first_name'] ?? ''} ${p['last_name'] ?? ''}').toString().trim(); return DropdownMenuItem(value: m['user_id'] as String, child: Text(label.isEmpty ? (m['user_id'] as String).substring(0, 8) : label)); }).toList(), onChanged: (v) => setDialogState(() => responsible = v)),
        DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'Priorité'), items: const [DropdownMenuItem(value: 'low', child: Text('Basse')), DropdownMenuItem(value: 'normal', child: Text('Normale')), DropdownMenuItem(value: 'high', child: Text('Haute')), DropdownMenuItem(value: 'critical', child: Text('Critique'))], onChanged: (v) => setDialogState(() => priority = v ?? 'normal')),
        Row(children: [Expanded(child: TextButton.icon(onPressed: () async { final d = await showDatePicker(context: context, initialDate: start ?? DateTime.now(), firstDate: DateTime(2000), lastDate: DateTime(2100)); if (d != null) setDialogState(() => start = d); }, icon: const Icon(Icons.calendar_today), label: Text(start == null ? 'Début prévu' : 'Début : ${_fmtDate(start)}'))), Expanded(child: TextButton.icon(onPressed: () async { final d = await showDatePicker(context: context, initialDate: end ?? start ?? DateTime.now(), firstDate: DateTime(2000), lastDate: DateTime(2100)); if (d != null) setDialogState(() => end = d); }, icon: const Icon(Icons.event), label: Text(end == null ? 'Fin prévue' : 'Fin : ${_fmtDate(end)}')))]),
        TextFormField(initialValue: country, decoration: const InputDecoration(labelText: 'Pays (code ISO, ex. CM)'), onChanged: (v) => country = v),
        TextFormField(initialValue: currency, decoration: const InputDecoration(labelText: 'Devise (ex. XAF)'), onChanged: (v) => currency = v),
      ]))),),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Annuler')), FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(dialogContext, true); }, child: const Text('Créer le projet'))],
    )));
    if (result != true) return;
    if (start != null && end != null && end!.isBefore(start!)) { _showError('La date de fin doit être postérieure à la date de début.'); return; }
    try {
      final id = await _service.createProject(organizationId: orgId, code: code.text, name: name.text, description: description.text, clientName: client.text, siteAddress: address.text, countryCode: country, currency: currency, sectorIds: selectedSectors.toList(), responsibleUserId: responsible, plannedStart: start, plannedEnd: end, priority: priority);
      await _load();
      if (mounted) context.push('/projects/$id');
    } catch (e) { if (mounted) _showError(e); }
  }

  void _showError(Object e) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Opération impossible : $e')));
  String _fmtDate(DateTime? d) => d == null ? '' : '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  String _status(String s) => const {'draft':'Brouillon','study':'Étude','planned':'Planifié','in_progress':'En cours','on_hold':'En pause','completed':'Terminé','cancelled':'Annulé'}[s] ?? s;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: _organizations.isEmpty ? null : FloatingActionButton.extended(onPressed: _createProject, icon: const Icon(Icons.add), label: const Text('Nouveau projet')),
      body: RefreshIndicator(onRefresh: _load, child: _loading ? const Center(child: CircularProgressIndicator()) : _error != null ? ListView(children: [Padding(padding: const EdgeInsets.all(24), child: Text(_error!))]) : _organizations.isEmpty ? ListView(padding: const EdgeInsets.all(24), children: [const Icon(Icons.business_outlined, size: 48), const Text('Aucune organisation disponible', textAlign: TextAlign.center), const SizedBox(height: 8), const Text('Créez d’abord une organisation et vérifiez votre adhésion.', textAlign: TextAlign.center), Center(child: FilledButton(onPressed: () => context.go('/organizations'), child: const Text('Gérer les organisations')))]) : ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 100), children: [
        Text('Gestion des projets', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 4), const Text('Portefeuille multisectoriel : BTP, travaux publics, industrie, énergie et infrastructures.'),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(value: _organizationId, decoration: const InputDecoration(labelText: 'Organisation', border: OutlineInputBorder()), items: _organizations.map((o) => DropdownMenuItem(value: o['id'] as String, child: Text(o['name'] as String))).toList(), onChanged: _changeOrganization),
        const SizedBox(height: 16),
        Row(children: [Text('Projets (${_projects.length})', style: Theme.of(context).textTheme.titleLarge), const Spacer(), IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
        if (_projects.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(24), child: Column(children: [Icon(Icons.folder_open_outlined, size: 42), SizedBox(height: 8), Text('Aucun projet pour cette organisation'), Text('Créez un projet pour démarrer le suivi.', textAlign: TextAlign.center)]))),
        ..._projects.map((p) { final progress = (p['progress_percent'] as num?)?.toDouble() ?? 0;  return Card(child: InkWell(borderRadius: BorderRadius.circular(16), onTap: () => context.push('/projects/${p['id']}'), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text('${p['code']} • ${p['name']}', style: Theme.of(context).textTheme.titleMedium)), const Icon(Icons.chevron_right)]), const SizedBox(height: 6), Wrap(spacing: 8, children: [Chip(label: Text(_status(p['status'] as String))), Chip(label: Text((p['priority'] as String).toUpperCase()))]), if ((p['client_name'] ?? '').toString().isNotEmpty) Text('Client : ${p['client_name']}'), if ((p['site_address'] ?? '').toString().isNotEmpty) Text('Site : ${p['site_address']}'), const SizedBox(height: 10), Row(children: [Expanded(child: LinearProgressIndicator(value: progress / 100, minHeight: 7)), const SizedBox(width: 10), Text('${progress.toStringAsFixed(0)} %')]), const SizedBox(height: 6), if (p['planned_start'] != null || p['planned_end'] != null) Text('Période : ${p['planned_start'] ?? '—'} → ${p['planned_end'] ?? '—'}', style: Theme.of(context).textTheme.bodySmall)])))); }),
      ])),
    );
  }
}
