import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../data/study_service.dart';

/// Cycle de vie guidé d'un projet : Étude → Préparation → Exécution → Réception → Clôture.
/// Le passage à l'étape suivante exige que toutes les validations de l'étape en cours soient faites.
class LifecycleTab extends StatefulWidget {
  const LifecycleTab({super.key, required this.projectId, this.onChanged});

  final String projectId;
  final VoidCallback? onChanged;

  @override
  State<LifecycleTab> createState() => _LifecycleTabState();
}

class _LifecycleTabState extends State<LifecycleTab> {
  static const List<String> _stages = ['study', 'preparation', 'execution', 'reception', 'closure'];
  static const Map<String, String> _labels = {
    'study': 'ÉTUDE',
    'preparation': 'PRÉPARATION',
    'execution': 'EXÉCUTION',
    'reception': 'RÉCEPTION',
    'closure': 'CLÔTURE',
  };
  static const Map<String, IconData> _icons = {
    'study': Icons.travel_explore,
    'preparation': Icons.event_available,
    'execution': Icons.construction,
    'reception': Icons.fact_check_outlined,
    'closure': Icons.inventory_2_outlined,
  };

  final _service = StudyService.instance;
  bool _loading = true;
  bool _busy = false;
  String? _error;
  Map<String, dynamic>? _lifecycle;
  List<Map<String, dynamic>> _validations = [];
  String _selected = 'study';

  String get _current => (_lifecycle?['current_stage'] as String?) ?? 'study';
  bool get _closed => _lifecycle?['closed_at'] != null;

  @override
  void initState() {
    super.initState();
    _load(initial: true);
  }

  String _clean(Object e) => e is PostgrestException ? e.message : e.toString();

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _load({bool initial = false}) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final lifecycle = await _service.getLifecycle(widget.projectId);
      final validations = await _service.listValidations(widget.projectId);
      _lifecycle = lifecycle;
      _validations = validations;
      if (initial) _selected = _current;
    } catch (e) {
      _error = _clean(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  List<Map<String, dynamic>> _forStage(String stage) {
    return _validations.where((v) => v['stage'] == stage).toList();
  }

  Future<void> _toggle(Map<String, dynamic> validation, bool done) async {
    setState(() => _busy = true);
    try {
      await _service.setValidation(widget.projectId, validation['stage'] as String, validation['code'] as String, done);
      await _load();
    } catch (e) {
      _snack(_clean(e));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _advance() async {
    final isLast = _current == 'closure';
    final confirm = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(isLast ? 'Clôturer le projet ?' : 'Passer à l’étape suivante ?'),
        content: Text(isLast
            ? 'La clôture administrative et financière du projet sera enregistrée.'
            : 'L’étape ${_labels[_current]} sera marquée comme terminée. Cette action est tracée dans le journal.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Confirmer')),
        ],
      ),
    );
    if (confirm != true) return;
    setState(() => _busy = true);
    try {
      final next = await _service.advanceStage(widget.projectId);
      await _load();
      if (next != 'closed') _selected = next;
      _snack(next == 'closed' ? 'Projet clôturé' : 'Étape suivante : ${_labels[next] ?? next}');
      widget.onChanged?.call();
    } catch (e) {
      _snack(_clean(e));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _lifecycle == null) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_error!),
            const SizedBox(height: 12),
            FilledButton(onPressed: _load, child: const Text('Réessayer')),
          ]),
        ),
      );
    }
    final currentIndex = _stages.indexOf(_current);
    final list = _forStage(_selected);
    final done = list.where((v) => v['is_done'] == true).length;
    final isCurrent = _selected == _current && !_closed;
    final allDone = list.isNotEmpty && done == list.length;
    final scheme = Theme.of(context).colorScheme;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_closed)
            Card(
              color: scheme.primaryContainer,
              child: const ListTile(
                leading: Icon(Icons.verified_outlined),
                title: Text('Projet clôturé'),
                subtitle: Text('Toutes les étapes ont été validées.'),
              ),
            ),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: _stages.map((s) {
              final index = _stages.indexOf(s);
              final finished = index < currentIndex || (_closed && index == currentIndex);
              final isNow = index == currentIndex && !_closed;
              return ChoiceChip(
                avatar: Icon(
                  finished ? Icons.check_circle : (isNow ? _icons[s] : Icons.lock_outline),
                  size: 18,
                ),
                label: Text(_labels[s] ?? s),
                selected: _selected == s,
                onSelected: (_) => setState(() => _selected = s),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Text(
            'Étape ${_stages.indexOf(_selected) + 1} sur 5 : ${_labels[_selected]}',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          Text(
            _stages.indexOf(_selected) < currentIndex || (_closed && _selected == _current)
                ? 'Étape terminée.'
                : (isCurrent ? 'Étape en cours — cochez chaque validation.' : 'Étape à venir (consultation seulement).'),
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: list.isEmpty ? 0 : done / list.length),
          const SizedBox(height: 4),
          Text('$done / ${list.length} validations'),
          const SizedBox(height: 8),
          ...list.map((v) {
            final auto = v['is_auto'] == true;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 2),
              child: CheckboxListTile(
                value: v['is_done'] == true,
                onChanged: (isCurrent && !auto && !_busy) ? (value) => _toggle(v, value ?? false) : null,
                title: Text(v['label'].toString()),
                subtitle: auto ? const Text('Automatique (déclenchée par le module concerné)') : null,
                controlAffinity: ListTileControlAffinity.leading,
                dense: true,
              ),
            );
          }),
          if (isCurrent) ...[
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: (allDone && !_busy) ? _advance : null,
              icon: Icon(_current == 'closure' ? Icons.verified : Icons.arrow_forward),
              label: Text(_current == 'closure' ? 'Clôturer le projet' : 'Valider l’étape et passer à la suivante'),
            ),
            if (!allDone)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  'Toutes les validations sont obligatoires pour passer à l’étape suivante.',
                  style: TextStyle(fontSize: 12),
                ),
              ),
          ],
        ],
      ),
    );
  }
}
