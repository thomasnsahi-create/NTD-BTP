import 'package:supabase_flutter/supabase_flutter.dart';

/// Accès Supabase pour le cycle de vie du projet et le module Étude
/// (métrés, bibliothèque des prix, devis estimatif, budget initial).
class StudyService {
  StudyService._();
  static final instance = StudyService._();
  SupabaseClient get _db => Supabase.instance.client;

  // ---------------------------------------------------------------- Cycle de vie
  Future<Map<String, dynamic>?> getLifecycle(String projectId) async {
    final rows = await _db
        .from('project_lifecycle')
        .select('project_id,current_stage,stage_started_at,closed_at')
        .eq('project_id', projectId)
        .limit(1);
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first);
  }

  Future<List<Map<String, dynamic>>> listValidations(String projectId) async {
    final rows = await _db
        .from('lifecycle_validations')
        .select('id,stage,code,label,sort_order,is_auto,is_done,validated_at')
        .eq('project_id', projectId)
        .order('sort_order');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> setValidation(String projectId, String stage, String code, bool done) async {
    await _db.rpc('set_lifecycle_validation', params: {
      'p_project': projectId,
      'p_stage': stage,
      'p_code': code,
      'p_done': done,
    });
  }

  Future<String> advanceStage(String projectId) async {
    final result = await _db.rpc('advance_project_stage', params: {'p_project': projectId});
    return result.toString();
  }

  // ---------------------------------------------------------------- Lots
  Future<List<Map<String, dynamic>>> listLots(String projectId) async {
    final rows = await _db
        .from('work_packages')
        .select('id,code,name')
        .eq('project_id', projectId)
        .order('sort_order')
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  // ---------------------------------------------------------------- Devis
  Future<List<Map<String, dynamic>>> listEstimates(String projectId) async {
    final rows = await _db
        .from('estimates')
        .select('id,version,title,status,fees_percent,currency,subtotal,fees_amount,total_amount,approved_at,created_at')
        .eq('project_id', projectId)
        .order('version', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> listEstimateItems(String estimateId) async {
    final rows = await _db
        .from('estimate_items')
        .select('id,work_package_id,trade_id,line_no,kind,designation,unit,quantity,unit_price,total,price_id,work_packages(name)')
        .eq('estimate_id', estimateId)
        .order('line_no')
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<String> createEstimateVersion(String projectId, {String? title}) async {
    final result = await _db.rpc('create_estimate_version', params: {
      'p_project': projectId,
      'p_title': title,
    });
    return result.toString();
  }

  Future<void> addEstimateItem(String estimateId, Map<String, dynamic> values, int lineNo) async {
    await _db.from('estimate_items').insert({
      ...values,
      'estimate_id': estimateId,
      'line_no': lineNo,
    });
  }

  Future<void> updateEstimateItem(String itemId, Map<String, dynamic> values) async {
    await _db.from('estimate_items').update(values).eq('id', itemId);
  }

  Future<void> deleteEstimateItem(String itemId) async {
    await _db.from('estimate_items').delete().eq('id', itemId);
  }

  Future<void> setEstimateFees(String estimateId, double percent) async {
    await _db.from('estimates').update({'fees_percent': percent}).eq('id', estimateId);
  }

  Future<void> deleteEstimate(String estimateId) async {
    await _db.from('estimates').delete().eq('id', estimateId);
  }

  Future<int> approveEstimate(String estimateId) async {
    final result = await _db.rpc('approve_estimate', params: {'p_estimate': estimateId});
    return (result as num).toInt();
  }

  // ---------------------------------------------------------------- Métrés
  Future<List<Map<String, dynamic>>> listMeasurements(String projectId) async {
    final rows = await _db
        .from('measurements')
        .select('id,title,notes,work_package_id,created_at,work_packages(name)')
        .eq('project_id', projectId)
        .order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createMeasurement(String projectId, String title, String? workPackageId) async {
    await _db.from('measurements').insert({
      'project_id': projectId,
      'title': title.trim(),
      'work_package_id': workPackageId,
    });
  }

  Future<void> deleteMeasurement(String measurementId) async {
    await _db.from('measurements').delete().eq('id', measurementId);
  }

  Future<List<Map<String, dynamic>>> listMeasurementItems(String measurementId) async {
    final rows = await _db
        .from('measurement_items')
        .select('id,number,designation,location,length,width,height,thickness,count,unit,formula,quantity,plan_ref')
        .eq('measurement_id', measurementId)
        .order('number');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> addMeasurementItem(String measurementId, Map<String, dynamic> values) async {
    await _db.from('measurement_items').insert({...values, 'measurement_id': measurementId});
  }

  Future<void> deleteMeasurementItem(String itemId) async {
    await _db.from('measurement_items').delete().eq('id', itemId);
  }

  // ---------------------------------------------------------------- Prix
  Future<List<Map<String, dynamic>>> listPrices(String organizationId) async {
    final rows = await _db
        .from('price_library')
        .select('id,kind,code,designation,unit,unit_price,currency,region,supplier,valid_from')
        .eq('organization_id', organizationId)
        .eq('is_active', true)
        .order('designation');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> addPrice(String organizationId, Map<String, dynamic> values) async {
    await _db.from('price_library').insert({...values, 'organization_id': organizationId});
  }

  Future<void> updatePrice(String priceId, double unitPrice) async {
    await _db.from('price_library').update({'unit_price': unitPrice}).eq('id', priceId);
  }

  Future<void> archivePrice(String priceId) async {
    await _db.from('price_library').update({'is_active': false}).eq('id', priceId);
  }

  Future<List<Map<String, dynamic>>> listPriceHistory(String priceId) async {
    final rows = await _db
        .from('price_history')
        .select('unit_price,effective_date,changed_at')
        .eq('price_id', priceId)
        .order('changed_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }
}
