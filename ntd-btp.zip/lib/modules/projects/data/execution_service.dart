import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Accès Supabase pour le suivi d'exécution : journal, photos, incidents,
/// quantités exécutées, dépenses réelles, écarts et alertes.
class ExecutionService {
  ExecutionService._();
  static final instance = ExecutionService._();
  SupabaseClient get _db => Supabase.instance.client;
  static const String bucket = 'project-files';

  List<Map<String, dynamic>> _list(dynamic rows) => List<Map<String, dynamic>>.from(rows as List);

  // ------------------------------------------------------------ Écarts et alertes
  Future<Map<String, dynamic>> getVariance(String projectId) async {
    final result = await _db.rpc('get_project_variance', params: {'p_project': projectId});
    return Map<String, dynamic>.from(result as Map);
  }

  Future<void> refreshAlerts(String projectId) async {
    await _db.rpc('refresh_project_alerts', params: {'p_project': projectId});
  }

  Future<List<Map<String, dynamic>>> listAlerts(String projectId) async {
    final rows = await _db
        .from('project_alerts')
        .select('id,rule_key,severity,title,message,updated_at')
        .eq('project_id', projectId)
        .eq('is_active', true)
        .order('updated_at', ascending: false);
    return _list(rows);
  }

  // ------------------------------------------------------------ Journal
  Future<List<Map<String, dynamic>>> listDiaries(String projectId) async {
    final rows = await _db
        .from('site_diaries')
        .select('id,diary_date,weather,workforce_count,trades_mobilized,teams,equipment,work_done,materials_used,incidents_note,delays_note,observations')
        .eq('project_id', projectId)
        .order('diary_date', ascending: false)
        .limit(90);
    return _list(rows);
  }

  Future<void> saveDiary(String projectId, String date, Map<String, dynamic> values) async {
    await _db.from('site_diaries').upsert(
      {...values, 'project_id': projectId, 'diary_date': date},
      onConflict: 'project_id,diary_date',
    );
  }

  Future<void> deleteDiary(String id) async {
    await _db.from('site_diaries').delete().eq('id', id);
  }

  // ------------------------------------------------------------ Quantités exécutées
  Future<List<Map<String, dynamic>>> listBaselineLines(String projectId) async {
    final rows = await _db
        .from('project_budget_lines')
        .select('id,code,designation,unit,quantity,unit_price,work_package_id,work_packages(name)')
        .eq('project_id', projectId)
        .eq('is_baseline', true)
        .neq('category', 'fees')
        .order('code');
    return _list(rows);
  }

  Future<List<Map<String, dynamic>>> listProgressRecords(String projectId) async {
    final rows = await _db
        .from('progress_records')
        .select('id,budget_line_id,record_date,quantity,status,notes,project_budget_lines(designation,unit)')
        .eq('project_id', projectId)
        .order('created_at', ascending: false)
        .limit(200);
    return _list(rows);
  }

  Future<void> addProgressRecord(String projectId, String lineId, double quantity, String date, String? notes) async {
    await _db.from('progress_records').insert({
      'project_id': projectId,
      'budget_line_id': lineId,
      'quantity': quantity,
      'record_date': date,
      'notes': notes,
    });
  }

  Future<void> reviewProgress(String recordId, bool validate) async {
    await _db.rpc('review_progress_record', params: {'p_record': recordId, 'p_validate': validate});
  }

  Future<void> deleteProgress(String recordId) async {
    await _db.from('progress_records').delete().eq('id', recordId);
  }

  // ------------------------------------------------------------ Dépenses
  Future<List<Map<String, dynamic>>> listExpenses(String projectId) async {
    final rows = await _db
        .from('project_expenses')
        .select('id,expense_date,work_package_id,trade_id,designation,quantity,unit_price,amount,supplier,payment_method,paid_amount,remaining,payment_status,receipt_path,work_packages(name)')
        .eq('project_id', projectId)
        .order('expense_date', ascending: false)
        .order('created_at', ascending: false)
        .limit(300);
    return _list(rows);
  }

  Future<void> addExpense(String projectId, Map<String, dynamic> values) async {
    await _db.from('project_expenses').insert({...values, 'project_id': projectId});
  }

  Future<void> updateExpense(String id, Map<String, dynamic> values) async {
    await _db.from('project_expenses').update(values).eq('id', id);
  }

  Future<void> deleteExpense(String id) async {
    await _db.from('project_expenses').delete().eq('id', id);
  }

  Future<List<Map<String, dynamic>>> listTrades() async {
    final rows = await _db.from('trades').select('id,name').order('name');
    return _list(rows);
  }

  // ------------------------------------------------------------ Fichiers et photos
  Future<String> uploadFile(String projectId, String folder, Uint8List bytes, {String extension = 'jpg'}) async {
    final path = '$projectId/$folder/${DateTime.now().microsecondsSinceEpoch}.$extension';
    await _db.storage.from(bucket).uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: extension == 'png' ? 'image/png' : 'image/jpeg'),
        );
    return path;
  }

  Future<String> signedUrl(String path) async {
    return _db.storage.from(bucket).createSignedUrl(path, 3600);
  }

  Future<List<Map<String, dynamic>>> listPhotos(String projectId) async {
    final rows = await _db
        .from('site_photos')
        .select('id,category,caption,storage_path,taken_at,work_package_id,work_packages(name)')
        .eq('project_id', projectId)
        .order('taken_at', ascending: false)
        .limit(80);
    return _list(rows);
  }

  Future<void> addPhoto(String projectId, String path, String category, String? caption, String? workPackageId) async {
    await _db.from('site_photos').insert({
      'project_id': projectId,
      'storage_path': path,
      'category': category,
      'caption': caption,
      'work_package_id': workPackageId,
    });
  }

  Future<void> deletePhoto(String id, String path) async {
    await _db.from('site_photos').delete().eq('id', id);
    try {
      await _db.storage.from(bucket).remove([path]);
    } catch (_) {
      // le fichier sera ignoré s'il est déjà supprimé
    }
  }

  // ------------------------------------------------------------ Incidents
  Future<List<Map<String, dynamic>>> listIncidents(String projectId) async {
    final rows = await _db
        .from('site_incidents')
        .select('id,incident_date,title,description,severity,status,work_package_id,work_packages(name)')
        .eq('project_id', projectId)
        .order('incident_date', ascending: false)
        .order('created_at', ascending: false)
        .limit(200);
    return _list(rows);
  }

  Future<void> addIncident(String projectId, Map<String, dynamic> values) async {
    await _db.from('site_incidents').insert({...values, 'project_id': projectId});
  }

  Future<void> setIncidentStatus(String id, String status) async {
    await _db.from('site_incidents').update({'status': status}).eq('id', id);
  }
}
