import 'package:supabase_flutter/supabase_flutter.dart';

class ProjectService {
  ProjectService._();
  static final instance = ProjectService._();
  SupabaseClient get _db => Supabase.instance.client;

  Future<List<Map<String, dynamic>>> listOrganizations() async {
    final rows = await _db.from('organizations').select('id,name,default_currency,country_code').order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> listProjects(String organizationId) async {
    final rows = await _db.from('projects').select('id,organization_id,code,name,description,client_name,site_address,country_code,currency,status,planned_start,planned_end,progress_percent,priority,responsible_user_id,sector_id,created_at').eq('organization_id', organizationId).order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> listSectors() async {
    final rows = await _db.from('sectors').select('id,name,code').eq('is_active', true).order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> listOrganizationMembers(String organizationId) async {
    final rows = await _db.from('organization_memberships').select('user_id,role').eq('organization_id', organizationId).eq('status', 'active').order('created_at');
    final members = List<Map<String, dynamic>>.from(rows);
    if (members.isEmpty) return members;
    final ids = members.map((m) => m['user_id'] as String).toList();
    final profiles = await _db.from('profiles').select('id,full_name,first_name,last_name,phone,job_title').inFilter('id', ids);
    final byId = {for (final profile in profiles) profile['id']: profile};
    return members.map((m) => {...m, 'profiles': byId[m['user_id']]}).toList();
  }

  Future<String> createProject({
    required String organizationId,
    required String code,
    required String name,
    String? description,
    String? clientName,
    String? siteAddress,
    required String countryCode,
    required String currency,
    required List<String> sectorIds,
    String? responsibleUserId,
    DateTime? plannedStart,
    DateTime? plannedEnd,
    required String priority,
  }) async {
    final user = _db.auth.currentUser;
    if (user == null) throw Exception('Session expirée. Reconnectez-vous.');
    final primarySector = sectorIds.isEmpty ? null : sectorIds.first;
    final row = await _db.from('projects').insert({
      'organization_id': organizationId,
      'code': code.trim(),
      'name': name.trim(),
      'description': _nullable(description),
      'client_name': _nullable(clientName),
      'site_address': _nullable(siteAddress),
      'country_code': countryCode.toUpperCase(),
      'currency': currency.toUpperCase(),
      'sector_id': primarySector,
      'responsible_user_id': _nullable(responsibleUserId),
      'planned_start': _date(plannedStart),
      'planned_end': _date(plannedEnd),
      'priority': priority,
      'created_by': user.id,
      'updated_by': user.id,
    }).select('id').single();
    final projectId = row['id'] as String;
    if (sectorIds.isNotEmpty) {
      await _db.from('project_sectors').insert(sectorIds.toSet().map((id) => {
        'project_id': projectId, 'sector_id': id, 'is_primary': id == primarySector,
      }).toList());
    }
    return projectId;
  }

  Future<Map<String, dynamic>> getProject(String id) async {
    final row = await _db.from('projects').select('id,organization_id,code,name,description,client_name,site_address,country_code,currency,status,planned_start,planned_end,forecast_end,forecast_delay_days,forecast_calculated_at,progress_percent,priority,responsible_user_id,sector_id,created_at,organizations(name),sectors!projects_sector_id_fkey(name)').eq('id', id).single();
    return Map<String, dynamic>.from(row);
  }

  Future<List<Map<String, dynamic>>> listProjectSectors(String projectId) async {
    final rows = await _db.from('project_sectors').select('is_primary,sectors(id,name,code)').eq('project_id', projectId);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> listProjectMembers(String projectId) async {
    final rows = await _db.from('project_members').select('id,user_id,project_role,is_responsible,allocation_percent').eq('project_id', projectId).order('created_at');
    final members = List<Map<String, dynamic>>.from(rows);
    if (members.isEmpty) return members;
    final ids = members.map((m) => m['user_id'] as String).toList();
    final profiles = await _db.from('profiles').select('id,full_name,first_name,last_name,phone,job_title').inFilter('id', ids);
    final byId = {for (final profile in profiles) profile['id']: profile};
    return members.map((m) => {...m, 'profiles': byId[m['user_id']]}).toList();
  }

  Future<void> addProjectMember(String projectId, String userId, String role, double allocation) async {
    await _db.from('project_members').upsert({
      'project_id': projectId, 'user_id': userId, 'project_role': role,
      'allocation_percent': allocation,
    }, onConflict: 'project_id,user_id');
  }

  Future<void> updateProject({required String id, required String status, required String priority, required DateTime? start, required DateTime? end, required String? responsibleUserId}) async {
    final user = _db.auth.currentUser;
    await _db.from('projects').update({
      'status': status, 'priority': priority,
      'planned_start': _date(start), 'planned_end': _date(end),
      'responsible_user_id': _nullable(responsibleUserId),
      'updated_by': user?.id,
    }).eq('id', id);
  }

  Future<List<Map<String, dynamic>>> listLots(String projectId) async {
    final rows = await _db.from('work_packages').select('id,code,name,description,status,planned_start,planned_end,progress_percent,responsible_user_id,sort_order').eq('project_id', projectId).order('sort_order');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createLot(String projectId, String name, String? code, String? description, DateTime? start, DateTime? end, String? responsibleUserId) async {
    await _db.from('work_packages').insert({
      'project_id': projectId, 'name': name.trim(), 'code': _nullable(code),
      'description': _nullable(description), 'planned_start': _date(start),
      'planned_end': _date(end),
      'responsible_user_id': _nullable(responsibleUserId),
    });
  }

  Future<List<Map<String, dynamic>>> listPhases(String projectId) async {
    final rows = await _db.from('project_phases').select('id,name,description,phase_order,status,planned_start,planned_end,actual_start,actual_end,progress_percent,responsible_user_id').eq('project_id', projectId).order('phase_order');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createPhase(String projectId, String name, String? description, DateTime? start, DateTime? end, String? responsibleUserId) async {
    await _db.from('project_phases').insert({
      'project_id': projectId, 'name': name.trim(), 'description': _nullable(description),
      'planned_start': _date(start), 'planned_end': _date(end),
      'responsible_user_id': _nullable(responsibleUserId),
    });
  }

  Future<List<Map<String, dynamic>>> listTasks(String projectId) async {
    final rows = await _db.from('project_tasks').select('id,phase_id,work_package_id,code,name,description,status,priority,planned_start,planned_end,actual_start,actual_end,progress_percent,weight,responsible_user_id,project_phases(name),work_packages(name)').eq('project_id', projectId).order('planned_start');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createTask({required String projectId, required String name, String? description, String? phaseId, String? lotId, String? responsibleUserId, DateTime? start, DateTime? end, required String priority, required double weight}) async {
    final user = _db.auth.currentUser;
    await _db.from('project_tasks').insert({
      'project_id': projectId, 'name': name.trim(), 'description': _nullable(description),
      'phase_id': _nullable(phaseId), 'work_package_id': _nullable(lotId),
      'responsible_user_id': _nullable(responsibleUserId),
      'planned_start': _date(start), 'planned_end': _date(end),
      'priority': priority, 'weight': weight,
      'created_by': user?.id,
    });
  }


  Future<List<Map<String, dynamic>>> listTaskDependencies(String projectId) async {
    final tasks = await listTasks(projectId);
    if (tasks.isEmpty) return <Map<String, dynamic>>[];
    final rows = await _db.from('project_task_dependencies').select('task_id,depends_on_task_id,dependency_type').inFilter('task_id', tasks.map((t) => t['id'] as String).toList());
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> updateTaskSchedule(String taskId, DateTime start, DateTime end) async {
    if (end.isBefore(start)) throw Exception('La fin doit être postérieure ou égale au début.');
    await _db.from('project_tasks').update({
      'planned_start': _date(start), 'planned_end': _date(end),
    }).eq('id', taskId);
  }

  Future<void> addTaskDependency(String taskId, String predecessorId, String type) async {
    await _db.from('project_task_dependencies').upsert({
      'task_id': taskId, 'depends_on_task_id': predecessorId,
      'dependency_type': type,
    }, onConflict: 'task_id,depends_on_task_id');
  }

  Future<void> removeTaskDependency(String taskId, String predecessorId) async {
    await _db.from('project_task_dependencies').delete()
      .eq('task_id', taskId).eq('depends_on_task_id', predecessorId);
  }

  Future<int> applyScheduleProposal({required String projectId, required List<Map<String, dynamic>> updates, required DateTime forecastEnd, required int delayDays}) async {
    final result = await _db.rpc('apply_project_schedule_proposal', params: {
      'p_project': projectId,
      'p_updates': updates,
      'p_forecast_end': _date(forecastEnd),
      'p_delay_days': delayDays,
    });
    return (result as num).toInt();
  }

  // Calendrier, jours fériés, équipes et engins (V7).
  Future<Map<String,dynamic>?> getWorkCalendar(String projectId) async {
    final rows=await _db.from('project_work_calendars').select('id,project_id,name,working_days,hours_per_day,start_time,end_time,exclude_public_holidays,country_code').eq('project_id',projectId).limit(1);
    return rows.isEmpty?null:Map<String,dynamic>.from(rows.first);
  }
  Future<void> saveWorkCalendar({required String projectId,required String name,required List<int> workingDays,required double hoursPerDay,required String startTime,required String endTime,required bool excludePublicHolidays,required String countryCode}) async {
    await _db.from('project_work_calendars').upsert({'project_id':projectId,'name':name.trim(),'working_days':workingDays,'hours_per_day':hoursPerDay,'start_time':startTime,'end_time':endTime,'exclude_public_holidays':excludePublicHolidays,'country_code':countryCode.toUpperCase()},onConflict:'project_id');
  }
  Future<List<Map<String,dynamic>>> listCalendarHolidays(String calendarId) async {
    final rows=await _db.from('project_calendar_holidays').select('id,holiday_date,name,holiday_type,is_working_day_override').eq('calendar_id',calendarId).order('holiday_date');
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<void> addCalendarHoliday({required String calendarId,required DateTime date,required String name,required String type,required bool workingOverride}) async {
    await _db.from('project_calendar_holidays').upsert({'calendar_id':calendarId,'holiday_date':_date(date),'name':name.trim(),'holiday_type':type,'is_working_day_override':workingOverride},onConflict:'calendar_id,holiday_date');
  }
  Future<void> deleteCalendarHoliday(String id) async { await _db.from('project_calendar_holidays').delete().eq('id',id); }
  Future<List<Map<String,dynamic>>> listProjectResources(String projectId) async {
    final rows=await _db.from('project_resources').select('id,resource_type,name,description,capacity,capacity_unit,is_active').eq('project_id',projectId).order('resource_type').order('name');
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<void> addProjectResource({required String projectId,required String type,required String name,required double capacity,required String unit,String? description}) async {
    await _db.from('project_resources').insert({'project_id':projectId,'resource_type':type,'name':name.trim(),'capacity':capacity,'capacity_unit':unit.trim().isEmpty?'unité':unit.trim(),'description':_nullable(description)});
  }
  Future<void> setResourceActive(String id,bool active) async { await _db.from('project_resources').update({'is_active':active}).eq('id',id); }
  Future<void> addResourceUnavailability({required String resourceId,required DateTime start,required DateTime end,required String reason,required String type}) async {
    if(end.isBefore(start))throw Exception('La fin doit être postérieure au début.');
    await _db.from('project_resource_unavailability').insert({'resource_id':resourceId,'unavailable_start':_date(start),'unavailable_end':_date(end),'reason':reason.trim(),'unavailability_type':type});
  }
  Future<List<Map<String,dynamic>>> listResourceUnavailability(String resourceId) async {
    final rows=await _db.from('project_resource_unavailability').select('id,unavailable_start,unavailable_end,reason,unavailability_type').eq('resource_id',resourceId).order('unavailable_start');
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<List<Map<String,dynamic>>> listTaskResourceAllocations(String projectId) async {
    final rows=await _db.from('project_task_resource_allocations').select('id,task_id,resource_id,allocated_capacity,allocation_start,allocation_end,notes,project_tasks(name),project_resources(name,resource_type,capacity_unit)').eq('project_id',projectId).order('allocation_start');
    return List<Map<String,dynamic>>.from(rows);
  }
  Future<void> allocateResource({required String projectId,required String taskId,required String resourceId,required double quantity,required DateTime start,required DateTime end,String? notes}) async {
    if(end.isBefore(start))throw Exception('La fin doit être postérieure au début.');
    await _db.from('project_task_resource_allocations').upsert({'project_id':projectId,'task_id':taskId,'resource_id':resourceId,'allocated_capacity':quantity,'allocation_start':_date(start),'allocation_end':_date(end),'notes':_nullable(notes)},onConflict:'task_id,resource_id');
  }
  Future<void> removeResourceAllocation(String id) async { await _db.from('project_task_resource_allocations').delete().eq('id',id); }

  Future<void> updateTaskProgress(String taskId, double progress, String status, String report) async {
    await _db.rpc('report_project_task_progress', params: {
      'p_task_id': taskId, 'p_progress': progress, 'p_status': status,
      'p_report': _nullable(report),
    });
  }


  Future<bool> canViewProjectBudget(String projectId) async {
    final value = await _db.rpc('can_view_project_budget', params: {'p_project': projectId});
    return value == true;
  }

  Future<bool> canEditProjectBudget(String projectId) async {
    final value = await _db.rpc('can_edit_project_budget', params: {'p_project': projectId});
    return value == true;
  }

  Future<List<Map<String, dynamic>>> listBudgetLines(String projectId) async {
    final rows = await _db.from('project_budget_lines').select('id,code,category,designation,unit,quantity,unit_price,estimated_amount,actual_amount,currency,notes').eq('project_id', projectId).order('created_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createBudgetLine({required String projectId, required String designation, required String category, required String? code, required String? unit, String? phaseId, String? lotId, required double quantity, required double unitPrice, required double actualAmount, required String currency, String? notes}) async {
    final user = _db.auth.currentUser;
    await _db.from('project_budget_lines').insert({
      'project_id': projectId, 'designation': designation.trim(), 'category': category,
      'phase_id': _nullable(phaseId), 'work_package_id': _nullable(lotId),
      'code': _nullable(code), 'unit': _nullable(unit), 'quantity': quantity,
      'unit_price': unitPrice, 'actual_amount': actualAmount,
      'currency': currency.toUpperCase(), 'notes': _nullable(notes), 'created_by': user?.id,
    });
  }

  Future<List<Map<String, dynamic>>> listProgress(String projectId) async {
    final rows = await _db.from('project_progress_updates').select('id,progress_percent,report,blockers,reported_at,reported_by').eq('project_id', projectId).order('reported_at', ascending: false).limit(50);
    final updates = List<Map<String, dynamic>>.from(rows);
    if (updates.isEmpty) return updates;
    final ids = updates.map((m) => m['reported_by'] as String).toSet().toList();
    final profiles = await _db.from('profiles').select('id,full_name').inFilter('id', ids);
    final byId = {for (final profile in profiles) profile['id']: profile};
    return updates.map((m) => {...m, 'profile': byId[m['reported_by']]}).toList();
  }

  String? _nullable(String? value) => value == null || value.trim().isEmpty ? null : value.trim();
  String? _date(DateTime? value) => value?.toIso8601String().substring(0, 10);
}
