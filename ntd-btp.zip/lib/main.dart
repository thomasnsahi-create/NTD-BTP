import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env');

  final url = dotenv.env['SUPABASE_URL'];
  final anonKey = dotenv.env['SUPABASE_ANON_KEY'];
  if (url == null || anonKey == null ||
      url.contains('YOUR_PROJECT') || anonKey.contains('YOUR_SUPABASE')) {
    runApp(const ProviderScope(child: ConfigurationErrorApp()));
    return;
  }

  await Supabase.initialize(url: url, anonKey: anonKey);
  runApp(const ProviderScope(child: BtpManagerApp()));
}

class ConfigurationErrorApp extends StatelessWidget {
  const ConfigurationErrorApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'Configuration Supabase manquante. Copiez .env.example vers .env '
                'et renseignez SUPABASE_URL et SUPABASE_ANON_KEY.',
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      );
}
