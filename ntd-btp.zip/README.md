# BTP MANAGER — Socle initial

Socle de démarrage Flutter + Supabase pour une application de gestion multisectorielle
des projets BTP, travaux publics, industrie, énergie et infrastructures.

## Contenu
- Application Flutter organisée par modules.
- Connexion Supabase (email/mot de passe).
- Écrans de base : connexion, tableau de bord, projets, référentiel des métiers.
- Migration SQL initiale : organisations, profils, membres, rôles, secteurs, métiers,
  spécialités, activités, projets, membres de projets, lots et affectations métiers.
- Politiques RLS et données de référence initiales.
- Configuration d'environnement via `.env`.

## Prérequis
- Flutter SDK stable installé.
- Un projet Supabase.
- Android Studio ou VS Code avec les extensions Flutter/Dart.

## Installation
1. Décompresser l'archive.
2. Ouvrir le dossier `btp_manager_socle`.
3. Créer un projet Supabase.
4. Dans Supabase > SQL Editor, exécuter dans l'ordre :
   - `supabase/migrations/0001_initial_schema.sql`
   - `supabase/seed/0001_reference_catalog.sql`
5. Copier `.env.example` vers `.env` et renseigner :
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
6. Depuis le dossier du projet :
   ```bash
   flutter pub get
   flutter run
   ```

## Première utilisation
- Créer un compte avec l'écran Connexion / Inscription.
- Après création du compte, créer la première organisation et son adhésion
  administrateur. Pour ce socle, cette opération d'amorçage est volontairement
  documentée ci-dessous plutôt qu'automatisée avec des privilèges élevés.

### Amorçage de la première organisation
Après inscription, récupérer l'UUID de l'utilisateur dans Supabase > Authentication > Users.
Puis exécuter dans SQL Editor en remplaçant les valeurs :

```sql
insert into public.organizations (name, country_code, default_currency)
values ('Mon entreprise BTP', 'CM', 'XAF')
returning id;
```

Utiliser l'UUID de l'organisation retourné :

```sql
insert into public.organization_memberships
  (organization_id, user_id, role, status)
values
  ('UUID_ORGANISATION', 'UUID_UTILISATEUR', 'owner', 'active');
```

L'utilisateur pourra ensuite créer des projets et gérer les membres selon ses droits.

## Important — limites du socle
Ce livrable est une fondation technique, pas encore un logiciel BTP complet.
Les calculs de métrés, devis, facturation, comptabilité, paie, planning avancé,
stocks, synchronisation hors ligne, IA, signature et publication APK ne sont pas
implémentés dans cette étape.

Les politiques RLS protègent les données d'organisation. Les fonctions sensibles
doivent être testées sur un vrai projet Supabase avant production. Ne jamais placer
la clé `service_role` dans l'application Flutter.

## Architecture
- `lib/core` : configuration et services transversaux.
- `lib/modules` : fonctionnalités métier séparées.
- `lib/shared` : composants réutilisables.
- `supabase/migrations` : structure et sécurité SQL.
- `supabase/seed` : catalogue initial des secteurs et métiers.

## Incrément 2 — Administration des organisations

Fichiers ajoutés :
- `supabase/migrations/0002_organization_administration.sql` : catalogue des permissions, modèles de rôles, permissions personnalisables par organisation, création atomique d'une organisation avec son propriétaire, contrôle des changements de rôles et politiques RLS fondées sur les permissions.
- `lib/modules/organizations/data/organization_service.dart` : accès Supabase aux organisations, membres et permissions.
- `lib/modules/organizations/presentation/organizations_page.dart` : création d'organisation, consultation des membres, changement de rôle et configuration des permissions par rôle.

### Installation / mise à jour
1. Conservez une copie de votre projet et de votre base Supabase.
2. Dans Supabase > SQL Editor, exécutez **0002_organization_administration.sql après 0001_initial_schema.sql**. Ne réexécutez pas 0001 sur une base déjà initialisée.
3. Remplacez/ajoutez les fichiers Flutter du ZIP en conservant votre `.env` réel.
4. Dans le terminal du projet : `flutter pub get`, puis `flutter analyze`, puis `flutter run`.
5. Connectez-vous, ouvrez **Organisations**, créez une organisation et vérifiez que votre compte apparaît comme `owner`.
6. Sélectionnez l'organisation pour consulter les membres et ajuster les permissions d'un rôle.

### Limites actuelles
- L'ajout/invitation d'un nouvel utilisateur par adresse e-mail n'est pas encore activé. L'invitation Supabase doit être faite côté serveur (Edge Function avec secret serveur), jamais avec une clé `service_role` dans l'application Flutter.
- Le changement de rôle concerne les membres déjà présents dans `organization_memberships`.
- Le catalogue des permissions et les politiques RLS de base sont en place ; toutes les futures fonctions métier devront appeler `has_org_permission(...)` dans leurs politiques RLS pour respecter les permissions configurées.
- Ce livrable est un incrément de développement. Il n'a pas été compilé ni testé sur votre projet Supabase réel dans cet environnement.

## Incrément 3 — Administration sécurisée des utilisateurs

Cette version ajoute :
- invitations par e-mail via une Supabase Edge Function (le secret `service_role` reste côté serveur) ;
- invitation valable 7 jours et acceptation uniquement par le compte connecté avec la même adresse e-mail ;
- invitation des comptes déjà existants : elle apparaît dans leur espace « Invitations reçues » après connexion ;
- profil professionnel modifiable par son titulaire (prénom, nom, téléphone, fonction) ;
- suspension/réactivation d'un membre dans une organisation sans supprimer son compte ni ses données ;
- journal serveur des invitations, changements de rôle/statut, mises à jour de profil et ouvertures de session via l'application.

### Mise à jour Supabase
1. Sauvegarder la base avant la mise à jour.
2. Dans Supabase > SQL Editor, exécuter `supabase/migrations/0003_secure_user_administration.sql` après les migrations 0001 et 0002.
3. Ne pas réexécuter les migrations déjà appliquées.

### Déployer l'envoi d'invitations
Prérequis : Supabase CLI connecté au bon projet et modèle d'e-mail d'invitation configuré dans Supabase Authentication.

Depuis la racine du projet :

```bash
supabase functions deploy invite-organization-member
supabase secrets set APP_INVITE_REDIRECT_URL=https://VOTRE-DOMAINE/chemin-retour SUPABASE_ANON_KEY=VOTRE_CLE_ANON
```

`SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY` sont des secrets système fournis à l'environnement Edge Function Supabase. Si votre environnement ne les expose pas automatiquement, les configurer dans les secrets du projet. Ne jamais copier la clé `service_role` dans `.env` Flutter, dans Git ou dans l'application Android.

Dans Supabase > Authentication > URL Configuration, ajouter l'URL de retour utilisée ci-dessus aux Redirect URLs autorisées. Configurer le SMTP / modèle d'e-mail d'invitation pour que les messages puissent être délivrés.

### Parcours de vérification
1. Se connecter avec un compte propriétaire ou administrateur disposant de `members.manage`.
2. Ouvrir Organisations, sélectionner une organisation puis « Inviter ».
3. Envoyer une invitation à une adresse qui ne possède pas encore de compte. Vérifier la réception du message et la validité de l'expiration à 7 jours.
4. Ouvrir le lien sur l'appareil, finaliser l'authentification avec la même adresse, puis consulter « Invitations reçues » et accepter.
5. Pour une adresse qui possède déjà un compte, se connecter avec ce compte : l'invitation doit apparaître dans « Invitations reçues ».
6. Modifier son propre profil, puis vérifier l'entrée `profile.updated` dans le journal.
7. Suspendre un membre depuis la liste. Vérifier qu'il ne peut plus accéder aux données de cette organisation. Réactiver ensuite le membre.
8. Vérifier les événements `member.invited`, `member.added`, `member.updated`, `profile.updated` et `session.started` dans le journal.

### Précisions de sécurité et limites
- La suspension concerne l'adhésion à l'organisation sélectionnée. Elle ne bannit pas le compte Supabase de toutes les autres organisations auxquelles la personne pourrait appartenir.
- Un compte suspendu conserve son profil et son historique ; aucune donnée métier n'est supprimée.
- Les invitations à des adresses déjà inscrites ne déclenchent pas un nouvel e-mail automatique : elles sont visibles dans l'application du destinataire connecté avec cette adresse.
- Le journal couvre les événements administratifs et les connexions effectuées via le parcours de connexion de l'application. Il ne remplace pas les journaux d'audit Supabase au niveau de l'infrastructure et ne journalise pas encore chaque modification métier.
- L'envoi réel dépend de la configuration de la fonction Edge, des URL de retour et du service e-mail Supabase.
- Le code n'a pas été compilé ni exécuté contre votre projet Supabase dans cet environnement. Effectuer les vérifications ci-dessus avant usage en production.

## Incrément 4 — Gestion complète des projets

Cette version ajoute le premier module opérationnel de gestion des projets multisectoriels :
- portefeuille des projets par organisation, création et classification sur plusieurs secteurs ;
- code, description, client/maître d'ouvrage, adresse du site, pays, devise, priorité, statut, dates prévisionnelles et responsable ;
- affectation des membres de l'organisation au projet avec rôle et taux d'affectation ;
- lots de travaux, phases et tâches avec responsables, dates, statuts, pondération et coûts estimés ;
- lignes budgétaires détaillées (catégorie, unité, quantité, prix unitaire, montant réel), avec droits financiers distincts ;
- déclarations d'avancement et calcul automatique de l'avancement global pondéré des tâches ;
- dépendances entre tâches dans la base, avec contrôle des liens entre projets et prévention des cycles ;
- journalisation serveur des créations et modifications des projets, lots, phases, tâches, membres, budgets et rapports ;
- politiques RLS et permissions configurables au niveau de chaque organisation.

### Mise à jour Supabase V4
1. Faites une sauvegarde de votre base.
2. Vérifiez que les migrations `0001`, `0002` et `0003` ont déjà été exécutées.
3. Dans Supabase > SQL Editor, exécutez une seule fois `supabase/migrations/0004_project_management.sql`.
4. Ne réexécutez pas les migrations antérieures et ne lancez pas `0004` une deuxième fois.

### Mise à jour Flutter
Les nouveaux fichiers sont :
- `lib/modules/projects/data/project_service.dart`
- `lib/modules/projects/presentation/projects_page.dart` (remplace la page provisoire)
- `lib/modules/projects/presentation/project_detail_page.dart`

Le routeur ajoute la fiche détaillée `/projects/:projectId`. Depuis le dossier du projet :
```bash
flutter pub get
flutter analyze
flutter run
```

### Droits d'accès
- Création et modification générale des projets : `projects.manage`.
- Gestion des lots, phases et tâches : `projects.schedule.manage`.
- Affectation de l'équipe : `projects.team.manage`.
- Déclaration de l'avancement : `projects.progress.report`.
- Lecture et gestion des budgets : `projects.budget.view` et `projects.budget.manage`.
- Les budgets détaillés sont stockés séparément et protégés par des politiques RLS financières ; ils ne sont pas exposés dans la liste générale des projets.

### Limites à connaître
Cette V4 constitue le socle fonctionnel de gestion des projets, pas encore un ERP BTP finalisé. Les dépendances de tâches sont structurées et sécurisées en base, mais leur écran de planification graphique reste à réaliser. Le diagramme de Gantt, chemin critique, alertes automatiques, pièces jointes, édition/suppression avancée des lignes, métrés, devis, achats et facturation feront l'objet d'incréments dédiés. Les dates et budgets saisis restent des données de gestion et ne remplacent pas une validation technique ou financière.

Le ZIP n'a pas été compilé avec Flutter ni exécuté sur une instance Supabase réelle dans cet environnement. Exécutez les commandes de vérification et testez les permissions avec plusieurs comptes/rôles avant toute utilisation en production.


## Incrément 5 — Planning détaillé et diagramme de Gantt

Ajouts de cette version :
- Onglet **Planning Gantt** dans la fiche projet ; affichage chronologique des tâches, dates de début/fin, progression, statut et repère du jour courant.
- Mise en évidence des tâches en retard (date de fin dépassée et progression inférieure à 100 %).
- Modification des dates prévisionnelles directement depuis le planning.
- Définition des dépendances entre tâches : Fin-Début (FS), Début-Début (SS), Fin-Fin (FF) et Début-Fin (SF).
- La migration 0004 contient déjà la table des dépendances et le contrôle anti-cycle ; cette version n'ajoute donc pas de migration obligatoire.
- Vérifications SQL complémentaires : `supabase/verification/0005_gantt_planning_checks.sql`.

### Mise à jour V5
1. Sauvegarder le projet Flutter et la base Supabase.
2. Remplacer les fichiers par ceux de cette archive en conservant votre `.env`.
3. Aucune nouvelle migration n'est nécessaire si `0004_project_management.sql` a déjà été exécutée.
4. Exécuter `flutter pub get`, `flutter analyze`, puis `flutter run`.
5. Ouvrir un projet, créer des tâches avec dates, puis ouvrir l'onglet **Planning Gantt**.
6. Toucher une barre pour ajuster ses dates ; utiliser l'icône d'arbre pour ajouter ou retirer des dépendances.

### Limites de cette étape
- Le Gantt est un affichage de pilotage interactif, avec défilement horizontal et vertical. Il ne propose pas encore le déplacement des barres par glisser-déposer.
- Les dépendances sont enregistrées et les cycles sont bloqués en base ; le recalcul automatique des dates des successeurs, le chemin critique CPM, les calendriers ouvrés/jours fériés et le nivellement des ressources seront des évolutions ultérieures.
- Les règles de décalage (lag/lead) ne sont pas encore proposées dans l'interface.
- La compilation Flutter et les tests sur Supabase réel restent à effectuer dans votre environnement.

## Incrément 6 — Chemin critique et reprogrammation automatique

La V6 ajoute un moteur CPM (Critical Path Method) et une reprogrammation avec prévisualisation et validation :
- calcul du début au plus tôt, du début au plus tard et de la marge totale de chaque tâche ;
- identification du chemin critique (marge nulle ou négative) ;
- prise en compte des quatre liens de dépendance existants : FS, SS, FF et SF ;
- alerte visuelle lorsque la fin calculée par le CPM dépasse la date contractuelle du projet ;
- simulation de la durée restante à partir du pourcentage d'avancement déclaré ;
- tâches non terminées proposées au plus tôt à partir de la date du jour, puis propagation des contraintes vers les successeurs ;
- tâches terminées conservées ; si une tâche terminée rend une dépendance impossible à respecter, la simulation s'arrête et demande une correction manuelle ;
- écran de comparaison avant/après ; aucune date n'est modifiée avant confirmation ;
- application de toutes les dates proposées dans une seule transaction SQL ;
- stockage séparé de la date de fin recalculée (`forecast_end`) et de l'écart en jours (`forecast_delay_days`), comparé à la date contractuelle. La date contractuelle `planned_end` du projet n'est pas écrasée.

### Mise à jour Supabase V6
1. Faire une sauvegarde de la base.
2. Vérifier que les migrations `0001` à `0005` nécessaires à votre version sont déjà appliquées (en particulier `0004_project_management.sql`).
3. Dans Supabase > SQL Editor, exécuter une seule fois `supabase/migrations/0006_critical_path_rescheduling.sql`.
4. Pour contrôler les prévisions et les dates, exécuter `supabase/verification/0006_critical_path_checks.sql`.

La fonction RPC `apply_project_schedule_proposal` vérifie l'utilisateur connecté et la permission `projects.schedule.manage` (ou `projects.manage`), contrôle que toutes les tâches appartiennent au projet et applique les modifications de façon atomique. Ne désactivez pas ces contrôles.

### Mise à jour Flutter
1. Remplacer les fichiers du projet par ceux de cette archive en conservant votre `.env`.
2. Exécuter `flutter pub get` puis `flutter analyze`.
3. Exécuter les tests : `flutter test test/modules/projects/domain/critical_path_engine_test.dart`.
4. Ouvrir une fiche projet puis l'onglet **Chemin critique**. Contrôler les marges, puis utiliser **Reprogrammer** pour examiner la simulation.
5. Appliquer seulement après vérification des nouvelles dates et de la disponibilité réelle des équipes.

### Hypothèses et limites du calcul V6
- Le moteur travaille en jours calendaires inclusifs : samedis, dimanches et jours fériés sont comptés comme des jours normaux.
- Les durées restantes sont estimées proportionnellement à l'avancement saisi ; elles ne constituent pas une mesure automatique de productivité.
- Le modèle ne gère pas encore les décalages (lag/lead), calendriers de travail par équipe, météo, disponibilité des engins, contraintes de livraison, nivellement des ressources ni optimisation multi-équipes.
- Les tâches sans dates et les tâches annulées ne sont pas intégrées au CPM.
- Le calcul doit être validé par le conducteur de travaux avant application, particulièrement lorsque des tâches sont déjà terminées ou bloquées. Les alertes sont recalculées lorsque l'utilisateur consulte l'onglet ; les notifications push et le recalcul planifié en arrière-plan ne sont pas encore inclus.
- La compilation Flutter, les tests automatisés et l'exécution des migrations sur votre instance Supabase n'ont pas pu être réalisés dans cet environnement ; ils restent obligatoires avant une utilisation en production.

## Incrément 7 — Calendriers de travail et ressources de chantier

La V7 ajoute un onglet **Calendrier & ressources** dans chaque projet :
- calendrier de chantier configurable : jours travaillés (lundi à dimanche), heures/jour et horaires de début/fin ;
- jours fériés nationaux, régionaux, d'entreprise et exceptions travaillées, saisis et modifiables par le gestionnaire ;
- équipes (capacité exprimée en personnes ou unités) et engins (capacité généralement égale à 1) ;
- périodes d'indisponibilité : maintenance, réparation, congé ou autre motif ;
- affectation d'une capacité d'équipe ou d'engin à une tâche et à une période ;
- contrôle côté PostgreSQL des réservations qui dépassent la capacité ou chevauchent une indisponibilité ;
- simulation de reprogrammation utilisant les jours ouvrés, les jours fériés, les dépendances et les ressources affectées ;
- lors de l'application d'une proposition, les dates des réservations liées aux tâches sont mises à jour dans la même transaction.

### Mise à jour Supabase V7
1. Faire une sauvegarde de la base.
2. Exécuter `supabase/migrations/0007_resource_calendars.sql` après les migrations 0001 à 0006 déjà appliquées.
3. La migration crée un calendrier par défaut lundi-samedi, 8 h/jour pour les projets existants et crée automatiquement ce calendrier pour les nouveaux projets.
4. Les jours fériés sont configurables par projet. La liste n'est pas importée automatiquement depuis une source officielle : le gestionnaire doit vérifier et saisir les dates applicables au pays, à la région et à l'entreprise.
5. Remplacer les fichiers de l'archive V7 en conservant le fichier `.env` réel, puis lancer `flutter pub get`, `flutter analyze` et les tests.

### Utilisation
1. Ouvrir un projet puis **Calendrier & ressources**.
2. Configurer les jours et heures travaillés.
3. Ajouter les jours fériés et les éventuelles journées exceptionnelles travaillées.
4. Déclarer les équipes et les engins avec leur capacité réelle.
5. Déclarer les maintenances et indisponibilités.
6. Affecter les ressources aux tâches avec les quantités nécessaires.
7. Ouvrir **Chemin critique > Reprogrammer** : la simulation tient compte des contraintes enregistrées et affiche les dates proposées avant validation.

### Règles et limites
- Les durées restantes sont estimées à partir du taux d'avancement déclaré. Les tâches terminées restent fixes.
- Une ressource non affectée à une tâche n'est pas supposée nécessaire : il faut enregistrer les affectations pour que le moteur contrôle sa disponibilité.
- Les équipes sont modélisées par une capacité numérique (par exemple 6 personnes). Le système contrôle les chevauchements de capacité, mais ne fait pas encore de nivellement individuel nominatif de chaque ouvrier.
- Les jours fériés ne sont pas préchargés automatiquement : cette précaution évite d'imposer un calendrier national incorrect aux projets hors Cameroun.
- Les horaires sont enregistrés dans le calendrier ; le calcul actuel travaille en journées ouvrées, pas encore en quarts d'heure ou en équipes de nuit.
- Le calcul CPM d'analyse initiale reste basé sur les dates/durées calendaires V6 ; la simulation de reprogrammation V7 utilise le calendrier ouvré et les capacités de ressources. Une prochaine amélioration devra harmoniser aussi les marges CPM sur ce calendrier.
- La compilation Flutter et les tests sur une instance Supabase réelle doivent être exécutés avant mise en production. Les contrôles SQL se trouvent dans `supabase/verification/0007_resource_planning_checks.sql`.
