# Feuille de route après le socle

## Incrément 1 — Organisation et projets
- Création d'organisation guidée et sécurisée.
- Invitations des collaborateurs.
- CRUD projets connecté à Supabase.
- Affectation des membres et des métiers aux projets.

## Incrément 2 — Référentiel dynamique
- Interface d'administration des secteurs, familles, métiers, spécialités et activités.
- Champs techniques configurables par spécialité.
- Historique des versions du référentiel.

## Incrément 3 — Lots, phases et tâches
- Arborescence des lots.
- Dépendances et jalons.
- Responsables et validations.

## Incréments suivants
Études et métrés, devis, achats, stocks, ressources, exécution, finances,
qualité/QHSE, réception, documents, mode hors ligne et IA.

## Incrément 2 — livré dans le ZIP
- Administration des organisations : création et liste selon les droits RLS.
- Création atomique de l'organisation et rattachement du créateur en tant que propriétaire.
- Consultation des membres et modification de leurs rôles/statuts via RPC contrôlée.
- Catalogue de permissions et personnalisation des permissions par organisation et par rôle.
- Écran Organisations ajouté à la navigation.

## Prochain incrément
- Invitations sécurisées par e-mail via Supabase Edge Function.
- Gestion du profil utilisateur, activation/suspension et journal des changements.
- Écran de sélection de l'organisation active et gestion des accès projet par projet.
- Tests SQL/RLS automatisés avant d'étendre les modules métier.

## V4 — Gestion des projets
- Portefeuille de projets par organisation et classification multisectorielle.
- Responsables, membres, lots, phases, tâches et dates prévisionnelles.
- Budgets détaillés protégés par permissions financières.
- Déclarations d'avancement et progression pondérée calculée côté base.
- Dépendances de tâches en base, garde-fous RLS et audit serveur.

## Prochain incrément recommandé
- Édition/suppression contrôlée des lots, phases, tâches, membres et lignes budgétaires.
- Diagramme de Gantt interactif, dépendances visuelles, chemin critique et alertes de retard.
- Tableau de bord de portefeuille : coûts, délais, avancement, risques et écarts.
- Pièces jointes, documents et comptes rendus de chantier.
