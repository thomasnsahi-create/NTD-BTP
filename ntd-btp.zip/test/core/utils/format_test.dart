import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/core/utils/format.dart';

void main() {
  test('formatAmount ajoute les séparateurs de milliers', () {
    expect(formatAmount(1250000), '1 250 000');
    expect(formatAmount(-4500), '-4 500');
    expect(formatAmount(null), '0');
  });

  test('formatQuantity supprime les décimales inutiles', () {
    expect(formatQuantity(100), '100');
    expect(formatQuantity(9.6), '9,6');
  });

  test('parseNumber accepte la virgule et les espaces', () {
    expect(parseNumber('1 250,5'), 1250.5);
    expect(parseNumber('abc'), 0);
    expect(parseOptionalNumber('  '), isNull);
  });
}
