import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/projects/domain/critical_path_engine.dart';

void main() {
  final tasks = [
    {'id': 'a', 'name': 'Fondations', 'planned_start': '2026-01-01', 'planned_end': '2026-01-03', 'progress_percent': 0, 'status': 'not_started'},
    {'id': 'b', 'name': 'Élévation', 'planned_start': '2026-01-04', 'planned_end': '2026-01-08', 'progress_percent': 0, 'status': 'not_started'},
    {'id': 'c', 'name': 'Peinture', 'planned_start': '2026-01-04', 'planned_end': '2026-01-05', 'progress_percent': 0, 'status': 'not_started'},
  ];

  test('identifie la chaîne FS la plus longue comme chemin critique', () {
    final result = CriticalPathEngine.analyze(tasks, [
      {'task_id': 'b', 'depends_on_task_id': 'a', 'dependency_type': 'finish_to_start'},
      {'task_id': 'c', 'depends_on_task_id': 'a', 'dependency_type': 'finish_to_start'},
    ]);
    expect(result.criticalIds, containsAll(['a', 'b']));
    expect(result.slackDays['a'], 0);
    expect(result.slackDays['b'], 0);
    expect(result.slackDays['c'], greaterThan(0));
  });

  test('propose une reprogrammation à partir de la date du jour', () {
    final result = CriticalPathEngine.simulate(tasks, [
      {'task_id': 'b', 'depends_on_task_id': 'a', 'dependency_type': 'finish_to_start'},
    ], today: DateTime(2026, 1, 10));
    expect(result.start['a'], DateTime(2026, 1, 10));
    expect(result.start['b'], DateTime(2026, 1, 13));
    expect(result.changedIds, containsAll(['a', 'b']));
  });
}
