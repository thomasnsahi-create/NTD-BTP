import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/projects/domain/resource_aware_scheduler.dart';

void main(){
  group('WorkCalendarConfig',(){
    test('exclut dimanche et jours fériés',(){
      final cal=WorkCalendarConfig(workingDays:{1,2,3,4,5,6},holidays:{DateTime(2026,12,1)});
      expect(cal.isWorkingDay(DateTime(2026,11,29)),false);
      expect(cal.isWorkingDay(DateTime(2026,12,1)),false);
      expect(cal.addWorkingDays(DateTime(2026,11,30),2),DateTime(2026,12,2));
    });
  });
  group('ResourceAwareScheduler',(){
    final baseTasks=[{'id':'t1','name':'Fondations','status':'not_started','planned_start':'2026-11-30','planned_end':'2026-12-01','progress_percent':0},{'id':'t2','name':'Élévation','status':'not_started','planned_start':'2026-11-30','planned_end':'2026-12-01','progress_percent':0}];
    test('décale une tâche lorsque la capacité d’équipe est déjà réservée par la première',(){
      final result=ResourceAwareScheduler.simulate(tasks:baseTasks,dependencies:[],calendar:const WorkCalendarConfig(workingDays:{1,2,3,4,5}),resources:const {'crew':ResourceCapacity(id:'crew',capacity:1)},requirementsByTask:const {'t1':[ResourceRequirement(resourceId:'crew',quantity:1)],'t2':[ResourceRequirement(resourceId:'crew',quantity:1)]},today:DateTime(2026,11,30));
      expect(result.start['t1'],DateTime(2026,11,30));
      expect(result.start['t2'],DateTime(2026,12,2));
    });
    test('respecte une indisponibilité de l’engin',(){
      final result=ResourceAwareScheduler.simulate(tasks:[baseTasks.first],dependencies:[],calendar:const WorkCalendarConfig(workingDays:{1,2,3,4,5}),resources: {'crane':ResourceCapacity(id:'crane',capacity:1,unavailable:[DateRange(DateTime(2026,11,30),DateTime(2026,11,30))])},requirementsByTask:const {'t1':[ResourceRequirement(resourceId:'crane',quantity:1)]},today:DateTime(2026,11,30));
      expect(result.start['t1'],DateTime(2026,12,1));
    });
  });
}
