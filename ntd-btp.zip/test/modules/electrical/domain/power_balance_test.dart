import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/power_balance.dart';
import 'package:btp_manager/modules/electrical/domain/validation.dart';

PowerItem item(String id, String cat, double? p, {double? pf, String room = 'r1'}) => PowerItem(
      id: id, label: id, roomId: room, roomName: room, category: cat, powerW: p, powerFactor: pf,
    );

void main() {
  const lighting = DiversityRule(category: 'lighting', isConfirmed: true);
  const socket = DiversityRule(category: 'socket', ksBase: 0.1, ksPerN: 0.9, isConfirmed: true);

  test('Ks des prises : 0,1 + 0,9 / n, borné à 1', () {
    expect(socket.ks(1), closeTo(1.0, 1e-9));
    expect(socket.ks(5), closeTo(0.28, 1e-9));
    expect(socket.ks(10), closeTo(0.19, 1e-9));
    const bad = DiversityRule(category: 'x', ksBase: 0.9, ksPerN: 0.9);
    expect(bad.ks(1), 1.0);
  });

  test('bilan : installé × Ku × Ks par catégorie, puis coefficient général et réserve', () {
    final items = [
      for (var i = 0; i < 10; i++) item('l$i', 'lighting', 100),
      for (var i = 0; i < 5; i++) item('s$i', 'socket', 2000),
    ];
    final b = computePowerBalance(items: items, rules: const [lighting, socket], usage: 'dwelling');
    expect(b.installedW, 11000);
    expect(b.demandBeforeFactorsW, closeTo(1000 + 10000 * 0.28, 1e-9));
    expect(b.demandW, closeTo(3800, 1e-9));
    final c = computePowerBalance(
      items: items, rules: const [lighting, socket], usage: 'dwelling', overallSimultaneity: 0.9, reserveFactor: 1.2,
    );
    expect(c.demandW, closeTo(3800 * 0.9 * 1.2, 1e-9));
  });

  test('catégorie sans règle : Ku = Ks = 1 et avertissement, jamais de coefficient inventé', () {
    final b = computePowerBalance(items: [item('c1', 'hvac', 3000)], rules: const [lighting], usage: 'dwelling');
    expect(b.demandW, 3000);
    expect(b.categories.single.ruleFound, isFalse);
    expect(b.issues.any((i) => i.message.contains('Aucun coefficient')), isTrue);
  });

  test('la règle de la destination l\'emporte sur la règle générale', () {
    const generic = DiversityRule(category: 'lighting', ku: 1);
    const office = DiversityRule(category: 'lighting', buildingUsage: 'office', ku: 0.8);
    expect(pickRule(const [generic, office], 'lighting', 'office')!.ku, 0.8);
    expect(pickRule(const [generic, office], 'lighting', 'dwelling')!.ku, 1);
    expect(pickRule(const [office], 'lighting', 'dwelling'), isNull);
    expect(pickRule(const [generic, office], 'lighting', null)!.ku, 1);
  });

  test('équipements sans puissance : exclus, listés, jamais estimés', () {
    final b = computePowerBalance(
      items: [item('a', 'lighting', 100), item('b', 'lighting', null), item('c', 'lighting', 0)],
      rules: const [lighting],
      usage: 'dwelling',
    );
    expect(b.installedW, 100);
    expect(b.itemsWithPower, 1);
    expect(b.itemsWithoutPower.length, 2);
    expect(b.categories.single.count, 1);
  });

  test('puissance apparente : calculée seulement si tous les cos φ sont connus', () {
    final ok = computePowerBalance(
      items: [item('a', 'lighting', 800, pf: 0.8), item('b', 'lighting', 200, pf: 1)],
      rules: const [lighting], usage: 'dwelling',
    );
    expect(ok.apparentDemandVA, closeTo(800 / 0.8 + 200, 1e-9));
    final partial = computePowerBalance(
      items: [item('a', 'lighting', 800, pf: 0.8), item('b', 'lighting', 200)],
      rules: const [lighting], usage: 'dwelling',
    );
    expect(partial.apparentDemandVA, isNull);
    expect(partial.issues.any((i) => i.message.contains('Facteur de puissance')), isTrue);
  });

  test('coefficients invalides = erreurs', () {
    final b = computePowerBalance(items: const [], rules: const [], usage: 'dwelling', overallSimultaneity: 1.2, reserveFactor: 0.9);
    expect(b.issues.where((i) => i.isError).length, 2);
  });

  test('puissance installée par pièce', () {
    final m = installedByRoom([item('a', 'lighting', 100, room: 'r1'), item('b', 'socket', 300, room: 'r1'), item('c', 'socket', 50, room: 'r2'), item('d', 'socket', null, room: 'r2')]);
    expect(m, {'r1': 400.0, 'r2': 50.0});
  });

  test('export JSON pour la traçabilité', () {
    final b = computePowerBalance(items: [item('a', 'lighting', 100)], rules: const [lighting], usage: 'dwelling');
    final j = b.toJson();
    expect(j['installed_w'], 100);
    expect((j['categories'] as List).length, 1);
  });

  test('puissance absorbée : utile / rendement, sinon valeur saisie', () {
    expect(absorbedPower(900, 0.9), closeTo(1000, 1e-9));
    expect(absorbedPower(900, null), 900);
    expect(absorbedPower(null, 0.9), isNull);
    expect(absorbedPower(900, 1.5), 900); // rendement invalide ignoré (signalé à la saisie)
  });
}
