import 'dart:math' as math;
import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/current_calc.dart';

void main() {
  const mono = InstallationSupply(id: 'm', name: 'Mono 230', phases: 1, nominalV: 230);
  const tri = InstallationSupply(id: 't', name: 'Tri 400', phases: 3, nominalV: 400, phaseToPhaseV: 400, phaseToNeutralV: 230);
  const triDerived = InstallationSupply(id: 'd', name: 'Tri dérivée', phases: 3, phaseToPhaseV: 400);
  const dc = InstallationSupply(id: 'c', name: 'PV', dc: true, nominalV: 100);

  test('monophasé : I = P / (U × cos φ)', () {
    final r = computeLoadCurrent(powerW: 2300, installation: mono, cosPhi: 1);
    expect(r.currentA, closeTo(10, 1e-9));
    expect(r.supply!.phases, 1);
  });

  test('triphasé : I = P / (√3 × U × cos φ)', () {
    final r = computeLoadCurrent(powerW: 9000, installation: tri, connection: 'three', cosPhi: 0.8);
    expect(r.currentA, closeTo(9000 / (math.sqrt(3) * 400 * 0.8), 1e-9));
    expect(r.currentA, closeTo(16.238, 1e-3));
  });

  test('rendement : P utile → courant plus élevé', () {
    final r = computeLoadCurrent(powerW: 9000, installation: tri, connection: 'three', cosPhi: 0.8, efficiency: 0.9);
    expect(r.currentA, closeTo(9000 / (math.sqrt(3) * 400 * 0.8 * 0.9), 1e-9));
    expect(r.assumptions, isEmpty);
  });

  test('rendement absent : hypothèse signalée, pas silencieuse', () {
    final r = computeLoadCurrent(powerW: 2300, installation: mono, cosPhi: 1);
    expect(r.assumptions.single, contains('Rendement non renseigné'));
  });

  test('charge monophasée sur installation triphasée : tension phase-neutre', () {
    final r = computeLoadCurrent(powerW: 2300, installation: tri, connection: 'single', cosPhi: 1);
    expect(r.supply!.voltageV, 230);
    expect(r.currentA, closeTo(10, 1e-9));
  });

  test('tension phase-neutre déduite de U/√3, avec hypothèse signalée', () {
    final r = computeLoadCurrent(powerW: 2000, installation: triDerived, connection: 'single', cosPhi: 1);
    expect(r.supply!.voltageV, closeTo(400 / math.sqrt(3), 1e-9));
    expect(r.assumptions.any((a) => a.contains('U/√3')), isTrue);
  });

  test('courant continu : I = P / U', () {
    final r = computeLoadCurrent(powerW: 1000, installation: dc);
    expect(r.currentA, closeTo(10, 1e-9));
    expect(r.supply!.label, contains('c.c.'));
  });

  test('données manquantes : demandées, jamais inventées', () {
    expect(computeLoadCurrent(powerW: null, installation: mono, cosPhi: 1).missing, contains('puissance'));
    expect(computeLoadCurrent(powerW: 1000, installation: null, cosPhi: 1).currentA, isNull);
    expect(computeLoadCurrent(powerW: 1000, installation: mono).missing.any((m) => m.contains('facteur de puissance')), isTrue);
    final noConn = computeLoadCurrent(powerW: 1000, installation: tri, cosPhi: 1);
    expect(noConn.currentA, isNull);
    expect(noConn.missing.any((m) => m.contains('raccordement')), isTrue);
    const noPhases = InstallationSupply(id: 'x', name: 'X', nominalV: 230);
    expect(computeLoadCurrent(powerW: 1000, installation: noPhases, cosPhi: 1).currentA, isNull);
  });

  test('rendement ou cos φ hors bornes = refus', () {
    expect(computeLoadCurrent(powerW: 1000, installation: mono, cosPhi: 1.2).currentA, isNull);
    expect(computeLoadCurrent(powerW: 1000, installation: mono, cosPhi: 1, efficiency: 0).currentA, isNull);
  });

  test('courant d\'appel d\'une installation triphasée : S / (√3 U), charges équilibrées', () {
    final r = computeInstallationCurrent(tri, apparentVA: 20000);
    expect(r.currentA, closeTo(20000 / (math.sqrt(3) * 400), 1e-9));
    expect(r.assumptions.single, contains('équilibrées'));
    expect(computeInstallationCurrent(mono, apparentVA: 4600).currentA, closeTo(20, 1e-9));
    expect(computeInstallationCurrent(mono).currentA, isNull);
    expect(computeInstallationCurrent(dc, activeW: 2000).currentA, closeTo(20, 1e-9));
  });
}
