import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/cable_library.dart';
import 'package:btp_manager/modules/electrical/domain/validation.dart';

void main() {
  const h07vu = CableType(
    code: 'H07V-U', label: 'Rigide PVC', category: 'power', conductorMaterials: ['cu'], ratedUV: 750,
    allowedLaying: ['conduit', 'flush'], allowedEnvironments: ['dry'], availableSections: [1.5, 2.5, 4, 6, 10],
  );
  const r2v = CableType(
    code: 'U-1000 R2V', label: 'R2V', category: 'power', conductorMaterials: ['cu'], ratedUV: 1000,
    allowedLaying: ['conduit', 'tray', 'buried'], allowedEnvironments: ['dry', 'humid', 'outdoor', 'buried'],
    availableSections: [1.5, 2.5, 4, 6, 10, 16],
  );
  const pv = CableType(
    code: 'H1Z2Z2-K', label: 'PV', category: 'photovoltaic', conductorMaterials: ['cu'], ratedUV: 1500,
    currentType: 'dc', allowedLaying: ['apparent'], allowedEnvironments: ['outdoor', 'uv'], availableSections: [4, 6],
  );

  test('H07V-U convient en local sec sous conduit', () {
    final issues = checkCableSuitability(h07vu, const CableUsage(voltageV: 230, conductor: 'cu', laying: 'conduit', environments: ['dry']));
    expect(issues, isEmpty);
  });

  test('H07V-U refusé en pose enterrée et en extérieur', () {
    final issues = checkCableSuitability(h07vu, const CableUsage(voltageV: 230, laying: 'buried', environments: ['outdoor']));
    expect(hasErrors(issues), isTrue);
    expect(issues.length, 2);
  });

  test('tension supérieure à la tension assignée = refus', () {
    final issues = checkCableSuitability(h07vu, const CableUsage(voltageV: 1000));
    expect(hasErrors(issues), isTrue);
  });

  test('courant continu : câble alternatif refusé, câble PV accepté', () {
    expect(hasErrors(checkCableSuitability(r2v, const CableUsage(voltageV: 800, dc: true, laying: 'tray'))), isTrue);
    expect(hasErrors(checkCableSuitability(pv, const CableUsage(voltageV: 800, dc: true, laying: 'apparent'))), isFalse);
    expect(hasErrors(checkCableSuitability(pv, const CableUsage(voltageV: 230))), isTrue);
  });

  test('matériau absent de la référence = refus', () {
    final issues = checkCableSuitability(h07vu, const CableUsage(voltageV: 230, conductor: 'al'));
    expect(hasErrors(issues), isTrue);
  });

  test('filtrage de la bibliothèque', () {
    final res = suitableCables(const [h07vu, r2v, pv], const CableUsage(voltageV: 230, conductor: 'cu', laying: 'buried', environments: ['buried']));
    expect(res.map((c) => c.code), ['U-1000 R2V']);
  });

  test('section normalisée disponible la plus proche (arrondi supérieur)', () {
    expect(nextAvailableSection(r2v, 3.1), 4);
    expect(nextAvailableSection(r2v, 16), 16);
    expect(nextAvailableSection(h07vu, 16), isNull);
  });
}
