import 'dart:math' as math;
import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/circuit_calc.dart';
import 'package:btp_manager/modules/electrical/domain/current_calc.dart';
import 'package:btp_manager/modules/electrical/domain/validation.dart';

void main() {
  const mono = InstallationSupply(id: 'm', name: 'Mono 230', phases: 1, nominalV: 230);
  const tri = InstallationSupply(id: 't', name: 'Tri 400', phases: 3, nominalV: 400, phaseToPhaseV: 400, phaseToNeutralV: 230);
  const dc = InstallationSupply(id: 'c', name: 'PV', dc: true, nominalV: 100);
  List<CircuitLoad> loads(int n, double p, double? pf) => [for (var i = 0; i < n; i++) CircuitLoad(id: 'l$i', label: 'L$i', powerW: p, powerFactor: pf)];

  test('circuit monophasé : Ib = S / U', () {
    final c = computeCircuitCurrent(installation: mono, connection: 'single', loads: loads(3, 2300, 1));
    // 3 charges de 2300 W : S = 6900 VA → 30 A
    expect(c.ibA, closeTo(6900 / 230, 1e-9));
  });

  test('circuit triphasé : Ib = S / (√3 U), charges équilibrées signalé', () {
    final c = computeCircuitCurrent(installation: tri, connection: 'three', loads: loads(3, 3000, 0.8));
    expect(c.apparentVA, closeTo(3 * 3000 / 0.8, 1e-9));
    expect(c.ibA, closeTo(3 * 3000 / 0.8 / (math.sqrt(3) * 400), 1e-9));
    expect(c.assumptions.any((a) => a.contains('équilibrées')), isTrue);
  });

  test('circuit monophasé sur installation triphasée : tension phase-neutre', () {
    final c = computeCircuitCurrent(installation: tri, connection: 'single', loads: loads(1, 2300, 1));
    expect(c.supply!.voltageV, 230);
    expect(c.ibA, closeTo(10, 1e-9));
  });

  test('coefficient de simultanéité du circuit', () {
    final c = computeCircuitCurrent(installation: mono, connection: 'single', loads: loads(2, 2300, 1), demandCoefficient: 0.5);
    expect(c.ibA, closeTo(10, 1e-9));
    expect(c.assumptions.any((a) => a.contains('simultanéité')), isTrue);
  });

  test('circuit en courant continu : Ib = P / U', () {
    final c = computeCircuitCurrent(installation: dc, connection: null, loads: loads(2, 500, null));
    expect(c.ibA, closeTo(10, 1e-9));
  });

  test('charges inconnues : aucun courant, données demandées', () {
    expect(computeCircuitCurrent(installation: mono, connection: 'single', loads: const []).ibA, isNull);
    final noPower = computeCircuitCurrent(installation: mono, connection: 'single', loads: const [CircuitLoad(id: 'a', label: 'A', powerFactor: 1)]);
    expect(noPower.ibA, isNull);
    expect(noPower.missing.any((m) => m.contains('puissance')), isTrue);
    final noCos = computeCircuitCurrent(installation: mono, connection: 'single', loads: loads(2, 1000, null));
    expect(noCos.ibA, isNull);
    expect(noCos.missing.any((m) => m.contains('cos φ')), isTrue);
    final noInst = computeCircuitCurrent(installation: null, connection: 'single', loads: loads(1, 1000, 1));
    expect(noInst.ibA, isNull);
    final noConn = computeCircuitCurrent(installation: tri, connection: null, loads: loads(1, 1000, 1));
    expect(noConn.missing.any((m) => m.contains('raccordement')), isTrue);
  });

  test('coefficient de simultanéité invalide = refus', () {
    expect(computeCircuitCurrent(installation: mono, connection: 'single', loads: loads(1, 1000, 1), demandCoefficient: 1.5).ibA, isNull);
  });

  test('validation d\'un circuit', () {
    expect(hasErrors(validateCircuit(number: 'C1', demandCoefficient: 1, lengthM: 12, groupedCircuits: 2, maxDropPct: 3, iccKa: 6, ambientTempC: 30)), isFalse);
    expect(hasErrors(validateCircuit(number: ' ')), isTrue);
    expect(hasErrors(validateCircuit(number: 'C1', lengthM: 0)), isTrue);
    expect(hasErrors(validateCircuit(number: 'C1', groupedCircuits: 0)), isTrue);
    expect(hasErrors(validateCircuit(number: 'C1', maxDropPct: 120)), isTrue);
    expect(hasErrors(validateCircuit(number: 'C1', iccKa: -1)), isTrue);
    expect(hasErrors(validateCircuit(number: 'C1', ambientTempC: 400)), isTrue);
    expect(hasErrors(validateCircuit(number: 'C1', demandCoefficient: 0)), isTrue);
  });

  test('préparation au dimensionnement : liste des données manquantes', () {
    final cur = computeCircuitCurrent(installation: mono, connection: 'single', loads: loads(1, 2300, 1));
    expect(sizingMissingData(current: cur).length, 8);
    expect(sizingMissingData(
      current: cur, conductorMaterial: 'cu', layingMode: 'conduit', ambientTempC: 30, groupedCircuits: 1,
      lengthM: 15, maxDropPct: 3, iccKa: 6, protectionType: 'Disjoncteur',
    ), isEmpty);
  });
}
