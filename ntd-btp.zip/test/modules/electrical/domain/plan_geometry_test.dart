import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/plan_geometry.dart';
import 'package:btp_manager/modules/electrical/domain/room_geometry.dart';
import 'package:btp_manager/modules/electrical/domain/validation.dart';

void main() {
  const room = RoomGeometry(lengthM: 6, widthM: 5, heightM: 2.5);

  test('longueur d\'un tracé = somme des segments dessinés (pas le périmètre)', () {
    // 3 m vers l'est, puis 4 m vers le sud : 7 m, et non 22 m de périmètre.
    expect(polylineLength(const [PlanPoint(0, 0), PlanPoint(3, 0), PlanPoint(3, 4)]), 7);
    // diagonale 3-4-5
    expect(polylineLength(const [PlanPoint(1, 1), PlanPoint(4, 5)]), 5);
    expect(polylineLength(const [PlanPoint(1, 1)]), 0);
  });

  test('arrondi au millimètre comme la base', () {
    final l = polylineLength(const [PlanPoint(0, 0), PlanPoint(1, 1)]);
    expect(l, 1.414);
  });

  test('aimantage sur la grille', () {
    expect(snapValue(1.26, 0.1), closeTo(1.3, 1e-9));
    expect(snapValue(1.26, 0), 1.26);
    expect(snapPoint(const PlanPoint(1.24, 2.76), 0.1), const PlanPoint(1.2, 2.8));
  });

  test('point dans la pièce et recadrage', () {
    expect(insideRoom(room, const PlanPoint(6, 5)), isTrue);
    expect(insideRoom(room, const PlanPoint(6.01, 1)), isFalse);
    expect(clampToRoom(room, const PlanPoint(-1, 9)), const PlanPoint(0, 5));
  });

  test('point le plus proche dans un rayon', () {
    const pts = [PlanPoint(1, 1), PlanPoint(3, 3)];
    expect(nearestIndex(pts, const PlanPoint(1.1, 1.1), 0.3), 0);
    expect(nearestIndex(pts, const PlanPoint(2, 2), 0.3), -1);
  });

  test('hauteur de pose : issue des hauteurs de la pièce, sinon à saisir', () {
    expect(defaultMountHeight('socket', socketM: 0.3, switchM: 1.1), 0.3);
    expect(defaultMountHeight('switch', socketM: 0.3, switchM: 1.1), 1.1);
    expect(defaultMountHeight('none', socketM: 0.3), isNull);
    expect(defaultMountHeight('luminaire'), isNull);
  });

  test('validation d\'implantation', () {
    expect(validatePlacement(room, const PlanPoint(2, 2), zM: 1.1), isEmpty);
    expect(hasErrors(validatePlacement(room, const PlanPoint(7, 2))), isTrue);
    expect(hasErrors(validatePlacement(room, const PlanPoint(2, 2), zM: 3)), isTrue);
  });

  test('validation d\'un cheminement', () {
    expect(validateRoute(room, const [PlanPoint(0, 0)]).isNotEmpty, isTrue);
    expect(hasErrors(validateRoute(room, const [PlanPoint(0, 0), PlanPoint(9, 0)])), isTrue);
    expect(hasErrors(validateRoute(room, const [PlanPoint(1, 1), PlanPoint(1, 1)])), isTrue);
    final ok = validateRoute(room, const [PlanPoint(1, 1), PlanPoint(1, 1), PlanPoint(3, 1)]);
    expect(hasErrors(ok), isFalse);
    expect(ok.length, 1); // point confondu : simple avertissement
  });
}
