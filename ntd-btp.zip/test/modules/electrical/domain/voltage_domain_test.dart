import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/validation.dart';
import 'package:btp_manager/modules/electrical/domain/voltage_domain.dart';

void main() {
  const bt = VoltageDomain(code: 'BT', label: 'Basse Tension', minAcV: 50, maxAcV: 1000, minDcV: 120, maxDcV: 1500, isConfirmed: true);
  const tbt = VoltageDomain(code: 'TBT', label: 'Très Basse Tension', minAcV: 0, maxAcV: 50, minDcV: 0, maxDcV: 120, isConfirmed: true);
  const mta = VoltageDomain(code: 'MTA', label: 'Moyenne Tension A');

  test('appartenance à un domaine : borne basse exclue, borne haute incluse', () {
    expect(bt.contains(230), isTrue);
    expect(bt.contains(1000), isTrue);
    expect(bt.contains(50), isFalse);
    expect(tbt.contains(50), isTrue);
    expect(tbt.contains(24), isTrue);
    expect(bt.contains(48, dc: true), isFalse);
  });

  test('limites non définies : aucun contrôle inventé', () {
    expect(mta.contains(20000), isNull);
  });

  test('installation BT triphasée cohérente', () {
    final issues = validateInstallation(const InstallationData(
      domain: bt, nominalV: 400, phaseToPhaseV: 400, phaseToNeutralV: 230, frequencyHz: 50, phases: 3, neutralRegime: 'TT',
    ));
    expect(issues, isEmpty);
  });

  test('tension nominale hors domaine = erreur', () {
    final issues = validateInstallation(const InstallationData(domain: tbt, nominalV: 230, frequencyHz: 50, phases: 1, neutralRegime: 'TT'));
    expect(hasErrors(issues), isTrue);
  });

  test('données manquantes : avertissements, jamais de valeur supposée', () {
    final issues = validateInstallation(const InstallationData(domain: bt, nominalV: 230));
    expect(hasErrors(issues), isFalse);
    expect(issues.length, 3); // fréquence, phases, régime de neutre
  });

  test('domaine MTA sans limites : avertissement explicite', () {
    final issues = validateInstallation(const InstallationData(domain: mta, nominalV: 20000, frequencyHz: 50, phases: 3, phaseToPhaseV: 20000, neutralRegime: 'IT'));
    expect(hasErrors(issues), isFalse);
    expect(issues.map((i) => i.message), contains(contains('limites')));
  });

  test('tension maximale inférieure à la nominale = erreur', () {
    final issues = validateInstallation(const InstallationData(domain: bt, nominalV: 400, maxV: 230, frequencyHz: 50, phases: 3, phaseToPhaseV: 400, neutralRegime: 'TT'));
    expect(hasErrors(issues), isTrue);
  });
}
