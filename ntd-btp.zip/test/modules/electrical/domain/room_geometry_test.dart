import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/room_geometry.dart';

void main() {
  test('surface, périmètre et volume : exemple de la maison (section 29)', () {
    const salon = RoomGeometry(lengthM: 6, widthM: 5, heightM: 2.5);
    expect(salon.areaM2, 30);
    expect(salon.perimeterM, 22);
    expect(salon.volumeM3, 75);

    const sdb = RoomGeometry(lengthM: 3, widthM: 2, heightM: 2.5);
    expect(sdb.areaM2, 6);
    expect(sdb.perimeterM, 10);
  });

  test('totaux de plusieurs pièces', () {
    final t = totalsOf(const [
      RoomGeometry(lengthM: 6, widthM: 5, heightM: 2.5),
      RoomGeometry(lengthM: 4, widthM: 3.5, heightM: 2.5),
      RoomGeometry(lengthM: 4, widthM: 3, heightM: 2.5),
      RoomGeometry(lengthM: 4, widthM: 3, heightM: 2.5),
      RoomGeometry(lengthM: 3, widthM: 2, heightM: 2.5),
      RoomGeometry(lengthM: 5, widthM: 1.5, heightM: 2.5),
    ]);
    expect(t.count, 6);
    expect(t.areaM2, closeTo(30 + 14 + 12 + 12 + 6 + 7.5, 1e-9));
  });

  test('validation : champs obligatoires et valeurs positives', () {
    final issues = validateRoom(const RoomInput(name: ' ', lengthM: 0, widthM: null, heightM: 2.5));
    expect(issues.where((i) => i.isError).length, 3);
  });

  test('validation : hauteurs d\'équipements et position du tableau', () {
    final issues = validateRoom(const RoomInput(
      name: 'Salon', lengthM: 6, widthM: 5, heightM: 2.5, socketHeightM: 3, panelXM: 7,
    ));
    expect(issues.map((i) => i.message), contains(contains('prises')));
    expect(issues.map((i) => i.message), contains(contains('position X')));
  });

  test('une ouverture doit tenir dans son mur', () {
    const room = RoomGeometry(lengthM: 6, widthM: 5, heightM: 2.5);
    expect(validateOpening(room, wall: 'north', offsetM: 1, widthM: 0.9), isEmpty);
    expect(validateOpening(room, wall: 'east', offsetM: 4.5, widthM: 1), isNotEmpty);
    expect(validateOpening(room, wall: 'north', offsetM: 5.5, widthM: 1), isNotEmpty);
  });
}
