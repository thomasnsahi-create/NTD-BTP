import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/power_balance.dart';
import 'package:btp_manager/modules/electrical/domain/requirements_engine.dart';
import 'package:btp_manager/modules/electrical/domain/rule_validation.dart';
import 'package:btp_manager/modules/electrical/domain/validation.dart';

void main() {
  test('une règle de l\'organisation remplace le défaut de même clé (besoins)', () {
    const defCuisinePetite = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'CUISINE', equipmentCode: 'PC', minCount: 3, areaMaxM2: 4);
    const defCuisineGrande = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'CUISINE', equipmentCode: 'PC', minCount: 6, areaMinM2: 4);
    const defLum = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'CUISINE', equipmentCode: 'LUM', minCount: 1);
    const mine = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'CUISINE', equipmentCode: 'PC', minCount: 4, isOrg: true);
    final eff = effectiveRequirementRules(const [defCuisinePetite, defCuisineGrande, defLum, mine]);
    expect(eff.length, 2); // les deux règles PC par défaut disparaissent, LUM reste
    final r = computeNeeds(usage: 'dwelling', roomTypeCode: 'CUISINE', areaM2: 12, rules: eff);
    expect(r.lines.firstWhere((l) => l.equipmentCode == 'PC').regulatoryMin, 4);
  });

  test('sans règle de l\'organisation, les défauts restent', () {
    const d = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'SEJOUR', equipmentCode: 'PC', minCount: 5);
    expect(effectiveRequirementRules(const [d]).length, 1);
  });

  test('une règle de coefficients de l\'organisation remplace le défaut', () {
    const def = DiversityRule(category: 'lighting');
    const mine = DiversityRule(category: 'lighting', ku: 0.8, isOrg: true);
    const other = DiversityRule(category: 'socket', ksBase: 0.1, ksPerN: 0.9);
    final eff = effectiveDiversityRules(const [def, mine, other]);
    expect(eff.length, 2);
    expect(eff.firstWhere((r) => r.category == 'lighting').ku, 0.8);
  });

  test('validation d\'une règle de besoin', () {
    expect(hasErrors(validateRequirementRule(
      buildingUsage: 'office', roomTypeCode: 'BUREAU', equipmentCode: 'PC', kind: 'regulatory', perAreaM2: 10, minCount: 2, reference: 'Référentiel X art. 12',
    )), isFalse);
    // référence obligatoire pour une règle réglementaire
    expect(hasErrors(validateRequirementRule(
      buildingUsage: 'office', roomTypeCode: 'BUREAU', equipmentCode: 'PC', kind: 'regulatory', minCount: 2,
    )), isTrue);
    // une proposition de conception n'exige pas de référence
    expect(hasErrors(validateRequirementRule(
      buildingUsage: 'office', roomTypeCode: 'BUREAU', equipmentCode: 'INT', kind: 'design', minCount: 1,
    )), isFalse);
    expect(hasErrors(validateRequirementRule(
      buildingUsage: 'office', roomTypeCode: 'BUREAU', equipmentCode: 'PC', kind: 'design', minCount: 5, maxCount: 3,
    )), isTrue);
    expect(hasErrors(validateRequirementRule(
      buildingUsage: 'office', roomTypeCode: 'BUREAU', equipmentCode: 'PC', kind: 'design', minCount: 1, areaMinM2: 10, areaMaxM2: 5,
    )), isTrue);
    expect(hasErrors(validateRequirementRule(
      buildingUsage: null, roomTypeCode: null, equipmentCode: null, kind: 'design', minCount: 1,
    )), isTrue);
  });

  test('validation d\'une règle de coefficients', () {
    expect(hasErrors(validateDiversityRule(category: 'socket', ku: 1, ksBase: 0.1, ksPerN: 0.9, reference: 'UTE C 15-105')), isFalse);
    expect(hasErrors(validateDiversityRule(category: 'socket', ku: 1.5, ksBase: 0.1, ksPerN: 0.9, reference: 'x')), isTrue);
    expect(hasErrors(validateDiversityRule(category: 'socket', ku: 1, ksBase: 1.2, ksPerN: 0, reference: 'x')), isTrue);
    expect(hasErrors(validateDiversityRule(category: 'socket', ku: 1, ksBase: 0.5, ksPerN: 0)), isTrue); // référence manquante
    expect(hasErrors(validateDiversityRule(category: 'inconnue', ku: 1, ksBase: 1, ksPerN: 0, reference: 'x')), isTrue);
  });
}
