import 'package:flutter_test/flutter_test.dart';
import 'package:btp_manager/modules/electrical/domain/requirements_engine.dart';
import 'package:btp_manager/modules/electrical/domain/validation.dart';

void main() {
  const sejourPc = RequirementRule(
    buildingUsage: 'dwelling', roomTypeCode: 'SEJOUR', equipmentCode: 'PC', perAreaM2: 4, minCount: 5, reference: 'Réf. A',
  );
  const sejourLum = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'SEJOUR', equipmentCode: 'LUM', minCount: 1);
  const sejourInt = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'SEJOUR', equipmentCode: 'INT', kind: 'design', minCount: 1);
  const cuisinePetite = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'CUISINE', equipmentCode: 'PC', minCount: 3, areaMaxM2: 4);
  const cuisineGrande = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'CUISINE', equipmentCode: 'PC', minCount: 6, areaMinM2: 4);

  test('1 prise par tranche de 4 m², minimum 5 : séjour de 30 m² = 8, de 12 m² = 5', () {
    expect(sejourPc.countFor(30), 8);
    expect(sejourPc.countFor(12), 5);
    expect(sejourPc.countFor(20), 5);
    expect(sejourPc.countFor(20.5), 6);
  });

  test('plafond maximum', () {
    const capped = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'X', equipmentCode: 'PC', perAreaM2: 1, minCount: 1, maxCount: 4);
    expect(capped.countFor(50), 4);
  });

  test('règles par surface : borne basse exclue, borne haute incluse', () {
    expect(cuisinePetite.appliesTo('dwelling', 'CUISINE', 4), isTrue);
    expect(cuisineGrande.appliesTo('dwelling', 'CUISINE', 4), isFalse);
    expect(cuisineGrande.appliesTo('dwelling', 'CUISINE', 4.1), isTrue);
    expect(cuisinePetite.appliesTo('dwelling', 'CUISINE', 4.1), isFalse);
  });

  test('proposition d\'un séjour : minimum réglementaire + proposition de conception', () {
    final r = computeNeeds(usage: 'dwelling', roomTypeCode: 'SEJOUR', areaM2: 30, rules: const [sejourPc, sejourLum, sejourInt]);
    final byCode = {for (final l in r.lines) l.equipmentCode: l};
    expect(byCode['PC']!.regulatoryMin, 8);
    expect(byCode['PC']!.proposed, 8);
    expect(byCode['LUM']!.regulatoryMin, 1);
    expect(byCode['INT']!.regulatoryMin, 0); // conception : pas un minimum réglementaire
    expect(byCode['INT']!.proposed, 1);
    expect(byCode['PC']!.references, ['Réf. A']);
    expect(r.issues.any((i) => i.message.contains('à confirmer')), isTrue);
  });

  test('cuisine : la règle dépend de la surface', () {
    final petite = computeNeeds(usage: 'dwelling', roomTypeCode: 'CUISINE', areaM2: 3.5, rules: const [cuisinePetite, cuisineGrande]);
    final grande = computeNeeds(usage: 'dwelling', roomTypeCode: 'CUISINE', areaM2: 12, rules: const [cuisinePetite, cuisineGrande]);
    expect(petite.lines.single.regulatoryMin, 3);
    expect(grande.lines.single.regulatoryMin, 6);
  });

  test('les règles d\'un logement ne s\'appliquent pas à un bâtiment industriel', () {
    final r = computeNeeds(usage: 'industrial', roomTypeCode: 'SEJOUR', areaM2: 30, rules: const [sejourPc, sejourLum]);
    expect(r.lines, isEmpty);
    expect(r.issues.single.severity, IssueSeverity.warning);
  });

  test('destination ou type de pièce manquants : aucune quantité inventée', () {
    expect(computeNeeds(usage: null, roomTypeCode: 'SEJOUR', areaM2: 30, rules: const [sejourPc]).lines, isEmpty);
    expect(hasErrors(computeNeeds(usage: null, roomTypeCode: 'SEJOUR', areaM2: 30, rules: const [sejourPc]).issues), isTrue);
    expect(hasErrors(computeNeeds(usage: 'dwelling', roomTypeCode: null, areaM2: 30, rules: const [sejourPc]).issues), isTrue);
  });

  test('règle confirmée : plus d\'avertissement « à confirmer »', () {
    const ok = RequirementRule(buildingUsage: 'dwelling', roomTypeCode: 'SEJOUR', equipmentCode: 'LUM', minCount: 1, isConfirmed: true);
    final r = computeNeeds(usage: 'dwelling', roomTypeCode: 'SEJOUR', areaM2: 30, rules: const [ok]);
    expect(r.issues, isEmpty);
    expect(r.lines.single.allConfirmed, isTrue);
  });

  test('sous le minimum réglementaire : justification obligatoire', () {
    expect(hasErrors(validateNeedQuantity(quantity: 4, regulatoryMin: 5)), isTrue);
    expect(hasErrors(validateNeedQuantity(quantity: 4, regulatoryMin: 5, justification: '  ')), isTrue);
    expect(hasErrors(validateNeedQuantity(quantity: 4, regulatoryMin: 5, justification: 'Dérogation validée par le BET')), isFalse);
    expect(hasErrors(validateNeedQuantity(quantity: 5, regulatoryMin: 5)), isFalse);
    expect(hasErrors(validateNeedQuantity(quantity: -1, regulatoryMin: 0)), isTrue);
  });

  test('reste à implanter', () {
    expect(remainingToPlace(8, 5), 3);
    expect(remainingToPlace(8, 9), -1);
  });
}
